/*
 * Copyright Amadeus
 */
//***MULTI-PART
//HEKmulelOe
//LOGICAL-PATH:aria/resources/CalendarRes_pt_PT.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.CalendarRes",$resources:{today:"Hoje",selectedDate:"Data seleccionada"}});
//HEKmulelOe
//LOGICAL-PATH:aria/resources/DateRes_pt_PT.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.DateRes",$resources:{firstDayOfWeek:0,day:["Domingo","Segunda-feira","Ter\u00e7a-feira","Quarta-feira","Quinta-feira","Sexta-feira","S\u00e1bado"],month:["Janeiro","Fevereiro","Mar\u00e7o","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"]}});