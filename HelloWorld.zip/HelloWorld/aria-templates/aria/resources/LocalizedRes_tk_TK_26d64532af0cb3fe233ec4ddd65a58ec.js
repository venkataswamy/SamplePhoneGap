/*
 * Copyright Amadeus
 */
//***MULTI-PART
//HEKmulelOe
//LOGICAL-PATH:aria/resources/DateRes_tk_TK.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.DateRes",$resources:{firstDayOfWeek:0,day:["Pazar","Pazartesi","Sal\u00fd","\u00c7ar\u00feamba","Per\u00feembe","Cuma","Cumartesi"],month:["Ocak","\u00deubat","Mart","Nisan","May\u00fds","Haziran","Temmuz","A\u00f0ustos","Eyl\u00fcl","Ekim","Kas\u00fdm","Aral\u00fdk"]}});