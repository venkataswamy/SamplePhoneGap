/*
 * Copyright Amadeus
 */
//***MULTI-PART
//HEKmulelOe
//LOGICAL-PATH:aria/resources/CalendarRes_fr_FR.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.CalendarRes",$resources:{today:"Aujourd'hui",selectedDate:"Date s\u00e9lectionn\u00e9e"}});
//HEKmulelOe
//LOGICAL-PATH:aria/resources/DateRes_fr_FR.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.DateRes",$resources:{firstDayOfWeek:1,day:["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"],month:["Janvier","F\u00e9vrier","Mars","Avril","Mai","Juin","Juillet","Ao\u00fbt","Septembre","Octobre","Novembre","D\u00e9cembre"]}});