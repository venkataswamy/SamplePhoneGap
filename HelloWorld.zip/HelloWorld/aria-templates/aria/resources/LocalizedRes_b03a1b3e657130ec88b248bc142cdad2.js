/*
 * Copyright Amadeus
 */
//***MULTI-PART
//HEKmulelOe
//LOGICAL-PATH:aria/resources/DateRes.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.DateRes",$resources:{firstDayOfWeek:0,day:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],month:["January","February","March","April","May","June","July","August","September","October","November","December"]}});
//HEKmulelOe
//LOGICAL-PATH:aria/resources/CalendarRes.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.CalendarRes",$resources:{today:"Today",selectedDate:"Selected date"}});