/*
 * Copyright Amadeus
 */
//***MULTI-PART
//HEKmulelOe
//LOGICAL-PATH:aria/resources/CalendarRes_sv_SE.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.CalendarRes",$resources:{today:"Idag",selectedDate:"Valt datum"}});
//HEKmulelOe
//LOGICAL-PATH:aria/resources/DateRes_sv_SE.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.DateRes",$resources:{firstDayOfWeek:0,day:["s\u00f6ndag","m\u00e5ndag","tisdag","onsdag","torsdag","fredag","l\u00f6rdag"],month:["januari","februari","mars","april","maj","juni","juli","augusti","september","oktober","november","december"]}});