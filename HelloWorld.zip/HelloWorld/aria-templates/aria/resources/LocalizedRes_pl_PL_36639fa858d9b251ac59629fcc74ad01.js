/*
 * Copyright Amadeus
 */
//***MULTI-PART
//HEKmulelOe
//LOGICAL-PATH:aria/resources/CalendarRes_pl_PL.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.CalendarRes",$resources:{today:"Dzi\u015b",selectedDate:"Wybrana data"}});
//HEKmulelOe
//LOGICAL-PATH:aria/resources/DateRes_pl_PL.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.DateRes",$resources:{firstDayOfWeek:0,day:["Niedziela","Poniedzialek","Wtorek","Sroda","Czwartek","Piatek","Sobota"],month:["Styczen","Luty","Marzec","Kwiecien","Maj","Czerwiec","Lipiec","Sierpien","Wrzesien","Pazdziernik","Listopad","Grudzien"]}});