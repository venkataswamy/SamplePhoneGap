/*
 * Copyright Amadeus
 */
//***MULTI-PART
//HEKmulelOe
//LOGICAL-PATH:aria/resources/CalendarRes_no_NO.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.CalendarRes",$resources:{today:"I dag",selectedDate:"Valgt dato"}});
//HEKmulelOe
//LOGICAL-PATH:aria/resources/DateRes_no_NO.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.DateRes",$resources:{firstDayOfWeek:0,day:["s\u00f8ndag","mandag","tirsdag","onsdag","torsdag","fredag","l\u00f8rdag"],month:["januar","februar","mars","april","mai","juni","juli","august","september","oktober","november","desember"]}});