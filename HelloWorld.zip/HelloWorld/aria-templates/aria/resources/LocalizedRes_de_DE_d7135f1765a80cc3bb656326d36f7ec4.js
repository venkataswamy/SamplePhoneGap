/*
 * Copyright Amadeus
 */
//***MULTI-PART
//HEKmulelOe
//LOGICAL-PATH:aria/resources/CalendarRes_de_DE.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.CalendarRes",$resources:{today:"Heute",selectedDate:"Ausgew\u00e4hltes Datum"}});
//HEKmulelOe
//LOGICAL-PATH:aria/resources/DateRes_de_DE.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.DateRes",$resources:{firstDayOfWeek:0,day:["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"],month:["Januar","Februar","M\u00e4rz","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"]}});