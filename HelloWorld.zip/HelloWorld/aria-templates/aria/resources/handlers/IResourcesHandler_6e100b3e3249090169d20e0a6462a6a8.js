/*
 * Copyright Amadeus
 */
Aria.interfaceDefinition({$classpath:"aria.resources.handlers.IResourcesHandler",$interface:{getSuggestions:{$type:"Function"},getDefaultTemplate:{$type:"Function"},suggestionToLabel:{$type:"Function"},getAllSuggestions:{$type:"Function"}}});