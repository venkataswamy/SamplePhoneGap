/*
 * Copyright Amadeus
 */
//***MULTI-PART
//HEKmulelOe
//LOGICAL-PATH:aria/resources/CalendarRes_es_ES.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.CalendarRes",$resources:{today:"Hoy",selectedDate:"Fecha seleccionada"}});
//HEKmulelOe
//LOGICAL-PATH:aria/resources/DateRes_es_ES.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.DateRes",$resources:{firstDayOfWeek:0,day:["Domingo","Lunes","Martes","Mi\u00e9rcoles","Jueves","Viernes","S\u00e1bado"],month:["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"]}});