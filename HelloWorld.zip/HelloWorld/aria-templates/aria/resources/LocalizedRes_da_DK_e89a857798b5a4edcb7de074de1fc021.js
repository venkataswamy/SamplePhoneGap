/*
 * Copyright Amadeus
 */
//***MULTI-PART
//HEKmulelOe
//LOGICAL-PATH:aria/resources/CalendarRes_da_DK.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.CalendarRes",$resources:{today:"I dag",selectedDate:"Valgt dato"}});
//HEKmulelOe
//LOGICAL-PATH:aria/resources/DateRes_da_DK.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.DateRes",$resources:{firstDayOfWeek:0,day:["S\u00f8ndag","Mandag","Tirsdag","Onsdag","Torsdag","Fredag","L\u00f8rdag"],month:["Januar","Februar","Marts","April","Maj","Juni","Juli","August","September","Oktober","November","December"]}});