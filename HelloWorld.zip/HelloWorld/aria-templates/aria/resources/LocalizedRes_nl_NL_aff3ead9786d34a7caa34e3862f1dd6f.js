/*
 * Copyright Amadeus
 */
//***MULTI-PART
//HEKmulelOe
//LOGICAL-PATH:aria/resources/CalendarRes_nl_NL.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.CalendarRes",$resources:{today:"Vandaag",selectedDate:"Geselecteerde datum"}});
//HEKmulelOe
//LOGICAL-PATH:aria/resources/DateRes_nl_NL.js
//HEKmulelOe
Aria.resourcesDefinition({$classpath:"aria.resources.DateRes",$resources:{firstDayOfWeek:0,day:["zondag","maandag","dinsdag","woensdag","donderdag","vrijdag","zaterdag"],month:["januari","februari","maart","april","mei","juni","juli","augustus","september","oktober","november","December"]}});