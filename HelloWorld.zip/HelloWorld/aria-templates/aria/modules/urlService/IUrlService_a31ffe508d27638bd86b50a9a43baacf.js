/*
 * Copyright Amadeus
 */
Aria.interfaceDefinition({$classpath:"aria.modules.urlService.IUrlService",$interface:{createActionUrl:function(){},createI18nUrl:function(){}}});