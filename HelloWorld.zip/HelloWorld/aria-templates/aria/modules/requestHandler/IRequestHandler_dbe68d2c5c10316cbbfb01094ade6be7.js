/*
 * Copyright Amadeus
 */
Aria.interfaceDefinition({$classpath:"aria.modules.requestHandler.IRequestHandler",$interface:{processSuccess:function(){},processFailure:function(){},prepareRequestBody:function(){},serializeRequestData:function(){}}});