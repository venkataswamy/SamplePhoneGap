/*
 * Copyright Amadeus
 */
/**
 * Template script definition for aria.tester.runner.view.Report
 */
Aria.tplScriptDefinition({
    $classpath : 'aria.tester.runner.view.popup.PopupScript',
    $dependencies : ['aria.tester.runner.utils.TestUtils'],
    $prototype : {
        
        
        
    }
});