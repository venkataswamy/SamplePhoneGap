/*
 * Copyright Amadeus
 */
Aria.interfaceDefinition({$classpath:"aria.utils.json.ISerializer",$interface:{serialize:function(){},parse:function(){}}});