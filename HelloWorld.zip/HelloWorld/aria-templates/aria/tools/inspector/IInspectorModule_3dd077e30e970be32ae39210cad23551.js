/*
 * Copyright Amadeus
 */
Aria.interfaceDefinition({$classpath:"aria.tools.inspector.IInspectorModule",$extends:"aria.templates.IModuleCtrl",$interface:{displayHighlight:function(){},reloadTemplate:function(){},refreshTemplate:function(){},reloadModule:function(){},getSource:function(){}},$events:{contentChanged:{description:"Raised when application content has changed"}}});