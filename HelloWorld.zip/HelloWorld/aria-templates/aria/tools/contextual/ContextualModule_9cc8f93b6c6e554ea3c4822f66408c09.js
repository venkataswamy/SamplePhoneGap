/*
 * Copyright Amadeus
 */
Aria.classDefinition({$classpath:"aria.tools.contextual.ContextualModule",$extends:"aria.templates.ModuleCtrl",$constructor:function(){this.$ModuleCtrl.constructor.call(this)},$prototype:{init:function(a,b){this._data=a;this.$callback(b)}}});