/*
 * Copyright Amadeus
 */
Aria.interfaceDefinition({$classpath:"aria.tools.contextual.IContextualMenu",$interface:{close:"Function",open:"Function",openTools:"Function"}});