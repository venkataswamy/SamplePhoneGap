/*
 * Copyright Amadeus
 */
Aria.interfaceDefinition({$classpath:"aria.tools.IToolsModule",$extends:"aria.templates.IModuleCtrl",$interface:{subModulesList:[]},$events:{bridgeReady:{description:"Raised when the bridge to the main window is available"},modulesReady:{description:"Raised when the debug submodules are ready"}}});