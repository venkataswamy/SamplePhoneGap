/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({$classpath:"aria.tools.logger.LoggerDisplayScript",$prototype:{onModuleEvent:function(){this.$refresh()}}});