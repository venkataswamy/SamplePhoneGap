/*
 * Copyright Amadeus
 */
Aria.interfaceDefinition({$classpath:"aria.tools.logger.ILoggerModule",$extends:"aria.templates.IModuleCtrl",$interface:{clean:function(){}},$events:{newLog:{description:"Raised when a new log is to be displayed"}}});