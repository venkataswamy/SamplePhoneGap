/*
 * Copyright Amadeus
 */
/**
 * @class tutorials.controlflow.step3.ControlFlowStep3Data
 */
Aria.classDefinition({
	$classpath : 'tutorials.controlflow.step3.ControlFlowStep3Data',
	$constructor : function () {},
	$prototype : {

		data : {
			name : 'John',
			age : 19,
			myArray : ["a", "b", "c", "d", "e"]
		}

	}
});