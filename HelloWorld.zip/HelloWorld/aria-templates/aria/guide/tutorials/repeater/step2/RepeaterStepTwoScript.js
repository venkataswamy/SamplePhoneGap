/*
 * Copyright Amadeus
 */
/**
 * TODOC
 * @class tutorials.repeater.step2.RepeaterStepTwoScript
 */
Aria.tplScriptDefinition({
	$classpath : 'tutorials.repeater.step2.RepeaterStepTwoScript',
	$prototype : {
		/**
		 * Updates the number of times the section has been refreshed
		 * @param {Object} item
		 * @return {Number} refresh count
		 */
		updateRefreshCountOf : function (item) {
			var sectionId = item.sectionId;
			if (!this.myData.refCount[sectionId]) {
				this.myData.refCount[sectionId] = 1;
			} else {
				this.myData.refCount[sectionId]++;
			}
			return this.myData.refCount[sectionId];
		},

		/**
		 * Adds an entry at the end of the array
		 * @param {Event} evt
		 * @param {Object} param contains the new entry
		 */
		addEntry : function (evt) {
			this.$json.add(this.myData.myArray, this.myData.newDestination);
		},

		/**
		 * Remoce entry in the initial array corresponding to the current item Notice that the position in the initial
		 * array has to be found in the info.initIndex value of the view Item
		 * @param {Event} evt
		 * @param {Object} param View Item at position 0
		 */
		removeThis : function (evt, param) {
			var item = param[0];
			this.$json.removeAt(this.myData.myArray, item.info.initIndex);
		},

		/**
		 * Sort the view in ascending order of destination
		 */
		destAsc : function () {
			this.myView.setSort('A', 'sortByDest', this.destinationGetter);
		},

		/**
		 * Sort the view in descending order of destination
		 */
		destDesc : function () {
			this.myView.setSort('D', 'sortByDest', this.destinationGetter);
		},

		/**
		 * Sort the view in ascending order of price
		 */
		priceAsc : function () {
			this.myView.setSort('A', 'sortByPrice', this.priceGetter);
		},

		/**
		 * Sort the view in descending order of price
		 */
		priceDesc : function () {
			this.myView.setSort('D', 'sortByPrice', this.priceGetter);
		},
		
		destinationGetter : function (o) {
			return o.value.destination;
		},
		priceGetter : function (o) {
			return o.value.price;
		},

		initializeView : function () {
			this.myView.setSort('D', 'sortByDest', this.destinationGetter);
			this.myView.filterIn(this.myView.FILTER_SET, function (o) {
				return (o.value.price <= 300);
			});
			this.myView.setPageSize(3);
		},
		
		setPage : function (ev, pageIdx) {
			this.myView.currentPageIndex = pageIdx;
		}
	}
});