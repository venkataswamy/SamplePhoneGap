/*
 * Copyright Amadeus
 */
Aria.classDefinition({
	$classpath : 'tutorials.module.step2.PersonAddModule',
	$extends : 'aria.templates.ModuleCtrl',
	$implements : ['tutorials.module.step2.IPersonAddModule'],
	$constructor : function () {
		this.$ModuleCtrl.constructor.call(this);

		this.setData({
			person : {
				firstName : "",
				lastName : ""
			}
		});
	},
	$destructor : function () {
		this.$ModuleCtrl.$destructor.call(this);
	},
	$prototype : {
		$publicInterfaceName : "tutorials.module.step2.IPersonAddModule",

		addPerson : function () {
			if (this._data.person.firstName && this._data.person.lastName) {
				this.$raiseEvent({
					name : "personAdded",
					newPerson : {
						firstName : this._data.person.firstName,
						lastName : this._data.person.lastName
					}
				});
			}
		}
	}
});