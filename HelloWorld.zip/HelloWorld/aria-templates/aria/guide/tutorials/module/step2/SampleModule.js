/*
 * Copyright Amadeus
 */
Aria.classDefinition({
	$classpath : "tutorials.module.step2.SampleModule",
	$extends : "aria.templates.ModuleCtrl",
	$implements : ["tutorials.module.step2.ISampleModule"],
	$constructor : function () {
		this.$ModuleCtrl.constructor.call(this);
	},
	$prototype : {

		$publicInterfaceName : 'tutorials.module.step2.ISampleModule',

		/**
		 * Init method. It loads the subModules
		 * @param {Object} args init arguments (unused)
		 * @param {aria.core.JsObject.Callback} cb init callback (optional). Has to be called when initialization is
		 * ready.
		 */
		init : function (args, cb) {

			this.loadSubModules([{
						refpath : "personSearch",
						classpath : "tutorials.module.step2.PersonSearchModule"
					}, {
						refpath : "personAdd",
						classpath : "tutorials.module.step2.PersonAddModule"
					}], {
				fn : "_completeInit",
				scope : this,
				args : cb
			});

		},

		/**
		 * Calls the callback and sets the datamodel
		 * @param {Object} args not used
		 * @param {aria.core.JsObject.Callback} cb
		 * @protected
		 */
		_completeInit : function (args, cb) {

			this.setData({
				searchResults : []
			});

			if (cb) {
				this.$callback(cb);
			}
		},
		
		/**
		 * React to events raised by submodules
		 * @param {Object} evt
		 */
		onSubModuleEvent : function (evt) {
			if (evt.name == "personAdded") {
				this.personSearch.addPerson(evt.newPerson);
			} else if (evt.name == "searchComplete") {
				this._data.searchResults = evt.searchResults;
				this.$raiseEvent("resultsUpdated");
			}
		}
	}
});