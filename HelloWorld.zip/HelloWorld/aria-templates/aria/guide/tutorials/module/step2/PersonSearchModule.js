/*
 * Copyright Amadeus
 */
Aria.classDefinition({
	$classpath : 'tutorials.module.step2.PersonSearchModule',
	$extends : 'aria.templates.ModuleCtrl',
	$implements : ['tutorials.module.step2.IPersonSearchModule'],
	$constructor : function () {
		this.$ModuleCtrl.constructor.call(this);
	},
	$destructor : function () {
		this.$ModuleCtrl.$destructor.call(this);
	},
	$prototype : {
		$publicInterfaceName : "tutorials.module.step2.IPersonSearchModule",

		init : function (args, cb) {

			/**
			 * Initialize the data model of the module controller
			 */
			this.setData({
				firstName : "",
				lastName : "",
				persons : [{
							firstName : 'John',
							lastName : 'Smith'
						}, {
							firstName : 'Peter',
							lastName : 'Smith'
						}, {
							firstName : 'Rickard',
							lastName : 'Winberg'
						}],

				searchResult : []
			});

			if (cb) {
				this.$callback(cb);
			}
		},

		/**
		 * Simple search function called when clicking the search button. In a normal case this search would be done
		 * asynchronously, but in this tutorial, the search is done directly.
		 */
		search : function () {
			var firstName = this._data.firstName;
			var lastName = this._data.lastName;

			this._data.searchResult = [];
			for (var personidx in this._data.persons) {
				var person = this._data.persons[personidx];
				var match = !!(firstName) || !!(lastName);
				if (firstName) {
					match = match && (person.firstName == firstName);
				}
				if (lastName) {
					match = match && (person.lastName == lastName);
				}
				if (match) {
					this._data.searchResult.push(person);
				}
			}
			this.$raiseEvent({
				name : "searchComplete",
				searchResults : this._data.searchResult
			});
		},

		addPerson : function (newPerson) {
			aria.utils.Json.add(this._data.persons, newPerson);
		}
	}
});