/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath:  'tutorials.module.step2.SampleTemplateScript',
	$prototype:{
		
		onModuleEvent : function (evt) {
			if (evt.name == "resultsUpdated") {
				this.$refresh({
					outputSection : "searchResults"
				});
			}
		}
	}
});
