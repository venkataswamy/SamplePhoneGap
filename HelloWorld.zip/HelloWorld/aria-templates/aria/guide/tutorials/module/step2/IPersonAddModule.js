/*
 * Copyright Amadeus
 */
Aria.interfaceDefinition({
	$classpath : "tutorials.module.step2.IPersonAddModule",
	$extends : "aria.templates.IModuleCtrl",
	$events : {
		"personAdded" : {
			description : "Raised when a person is added.",
			properties : {
				"newPerson" : "Object with firstName and lastName of the added person."
			}
		}
	},
	$interface : {
		addPerson : {
			$type : "Function"
		}
	}
});