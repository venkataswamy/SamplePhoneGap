/*
 * Copyright Amadeus
 */
Aria.interfaceDefinition({
	$classpath : "tutorials.module.step2.IPersonSearchModule",
	$extends : "aria.templates.IModuleCtrl",
	$events : {
		"searchComplete" : {
			description : "Raised when the search is complete.",
			properties : {
				"searchResults" : "Results of the search."
			}
		}
	},
	$interface : {
		init : {
			$type : "Function",
			$callbackParam : 1
		},
		search : {
			$type : "Function"
		},
		addPerson : {
			$type : "Function"
		}
	}
});