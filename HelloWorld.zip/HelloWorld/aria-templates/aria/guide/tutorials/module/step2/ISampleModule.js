/*
 * Copyright Amadeus
 */
Aria.interfaceDefinition({
	$classpath : "tutorials.module.step2.ISampleModule",
	$extends : "aria.templates.IModuleCtrl",
	$events : {
		"resultsUpdated" : "Raised when the search reaults are updated."
	},
	$interface : {
		init : {
			$type : "Function",
			$callbackParam : 1
		}
	}
});