/*
 * Copyright Amadeus
 */
/**
* Public interface for the PersonSearchTemplateController.
* @classpath: tutorials.module.step1.IPersonSearchTemplateController
*/
Aria.interfaceDefinition ({
	$classpath : 'tutorials.module.step1.IPersonSearchTemplateController',
	$extends : 'aria.templates.IModuleCtrl',
	$events : {		
		"searchResultChanged" : "Raised when a new search result is available."
	},
	$interface : {
		/**
		 * Simple search function called when clicking the search button. In a normal case this search would be done
		 * asynchronously, but in this tutorial, the search is done directly and the event is triggered before returning
		 * from this method.
		 */		
		search : function () {},
		
		raiseSearchResultChangedEvent : function () {}
	}
});
