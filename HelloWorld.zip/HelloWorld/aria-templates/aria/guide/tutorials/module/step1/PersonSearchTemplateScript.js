/*
 * Copyright Amadeus
 */
/**
 * Template script for module tutorial. Needed to listen to events from the module controller.
 * @class tutorials.module.step1.PersonSearchTemplateScript
 */
Aria.tplScriptDefinition({
	$classpath : 'tutorials.module.step1.PersonSearchTemplateScript',
	$prototype : {

		/**
		 * This method is automatically called if the module controller raises an event
		 */
		onModuleEvent : function (evt) {
			if (evt.name === "searchResultChanged") {
				this.$refresh();
			}
		}

	}
});