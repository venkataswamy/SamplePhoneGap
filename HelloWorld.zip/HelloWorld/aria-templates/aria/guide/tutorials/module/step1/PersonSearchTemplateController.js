/*
 * Copyright Amadeus
 */
/**
 * Module controller for person search example in module tutorial
 * @class tutorials.module.step1.PersonSearchTemplateController
 */
Aria.classDefinition({
	$classpath : 'tutorials.module.step1.PersonSearchTemplateController',
	$extends : 'aria.templates.ModuleCtrl',
	$implements : ['tutorials.module.step1.IPersonSearchTemplateController'],	
	$dependencies : [],
	$constructor : function () {
		this.$ModuleCtrl.constructor.call(this);		
		/**
		 * Initializes the datamodel with some static data. The _data property is automatically set to null in the
		 * destructor of the base class.
		 */
		this._data = {
			firstName:"",
			lastName:"Doe",
			persons : [{
						firstName : 'John',
						lastName : 'Smith'
					}, {
						firstName : 'Peter',
						lastName : 'Smith'
					}, {
						firstName : 'Rickard',
						lastName : 'Winberg'
					}],

			searchResult : []
		};
	},
	$destructor : function () {
		this.$ModuleCtrl.$destructor.call(this);
	},	
	$prototype : {
		$publicInterfaceName : "tutorials.module.step1.IPersonSearchTemplateController",	
		/**
		 * Simple search function called when clicking the search button. In a normal case this search would be done
		 * asynchronously, but in this tutorial, the search is done directly and the event is triggered before returning
		 * from this method.
		 */
		search : function () {
			var firstName = this._data.firstName;
			var lastName = this._data.lastName;

			this._data.searchResult = [];
			for (var personidx in this._data.persons) {
				var person = this._data.persons[personidx];
				var match = true;
				if (firstName) {
					match = match && (person.firstName == firstName);
				}
				if (lastName) {
					match = match && (person.lastName == lastName);
				}
				if (match) {
					this._data.searchResult.push(person);
				}
			}
			this.raiseSearchResultChangedEvent();
		},
		raiseSearchResultChangedEvent : function () {
			this.$raiseEvent("searchResultChanged");
		}
	}
});