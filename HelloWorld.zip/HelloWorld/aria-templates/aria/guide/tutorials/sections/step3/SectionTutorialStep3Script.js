/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'tutorials.sections.step3.SectionTutorialStep3Script',
	$prototype : {

		$dataReady : function () {
			if (!this.data.section1lines) {
				this.data.section1lines = 3;
			}
			if (!this.data.section2lines) {
				this.data.section2lines = 3;
			}
		},

		/**
		 * Simply increase the value this.data.section2lines. Listeners are not notified
		 */
		addLineToSectionOne : function () {
			this.data.section1lines++;
		},

		/**
		 * Increase the value this.data.section2lines by using the aria.utils.Json methods that allow to notify changes
		 */
		addLineToSectionTwo : function () {
			this.$json.setValue(this.data, "section2lines", this.data["section2lines"] + 1);
		},

		/**
		 * Refresh the section with id "section1".
		 */
		refreshSectionOne : function () {
			this.$refresh({
				outputSection : "section1"
			});
		}

	}
});