/*
 * Copyright Amadeus
 */
Aria.classDefinition({
	$classpath : 'tutorials.basictemplate.step3.TemplateStep3Data',
	$constructor : function () {},
	$prototype : {

		data : {
			planet : "Earth",
			continents : ["Asia", "Africa", "North America", "South America", "Antarctica", "Europe", "Australia"]
		}

	}
});