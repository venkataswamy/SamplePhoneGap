/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'tutorials.macrolibs.step3.Lib1Script',
	$prototype : {
		update : function(res, holder) {
			aria.utils.Json.setValue(holder, "count", holder.count + 1);
		}
	}
});