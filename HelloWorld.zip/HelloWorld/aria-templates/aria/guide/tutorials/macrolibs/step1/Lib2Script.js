/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'tutorials.macrolibs.step1.Lib2Script',
	$prototype : {
		shout : function(word) {
			return word.toUpperCase();
		}
	}
});