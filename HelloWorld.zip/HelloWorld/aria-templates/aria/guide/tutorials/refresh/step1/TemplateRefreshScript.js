/*
 * Copyright Amadeus
 */
/**
 * The template script referred by the TemplateRefresh template to update counter and to perform refresh.
 * @class tutorials.refresh.step1.TemplateRefreshScript
 */
Aria.tplScriptDefinition({
	$classpath : 'tutorials.refresh.step1.TemplateRefreshScript',
	$prototype : {

		/**
		 * Add the counter meta data if not already existing in data model.
		 */
		initCountIfNeeded : function () {
			var data = this.data;
			if (!data["view:count"]) {
				// count doesn't exist
				this.$json.setValue(data, "view:count", "1");
			}
			data = null;
		},

		/**
		 * Update the count meta-data used to get different values each time a refresh is made
		 */
		updateCount : function () {
			var data = this.data;
			if (isNaN(data["view:count"])) {
				this.$json.setValue(data, "view:count", "1");
			} else {
				this.$json.setValue(data, "view:count", parseInt(data["view:count"], 10) + 1);
			}
		},

		/**
		 * Event handler called when pressing a button
		 */
		updateCountAndRefresh : function () {
			this.updateCount();
			this.$refresh();
		}

	}
});