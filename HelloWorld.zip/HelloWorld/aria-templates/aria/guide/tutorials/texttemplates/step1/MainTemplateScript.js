/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'tutorials.texttemplates.step1.MainTemplateScript',
	$texts : {
		scriptText : 'tutorials.texttemplates.step1.ScriptText'
	},
	$prototype : {

		myScriptFunction : function () {
			var out = [];
			
			if (this.dataForText.$hasScript == "true") {
				out.push("<pre style='font-size: 10pt'>");
				out.push(this.scriptText.processTextTemplate(this.dataForText));
				out.push("</pre>");
			}
			return out.join("");
		}
	}
});