/*
 * Copyright Amadeus
 */
/**
 * @class tutorials.helloworld.step2.TemplateStep2Data
 */
Aria.classDefinition({
	$classpath : 'tutorials.helloworld.step2.TemplateStep2Data',
	$constructor : function () {},
	$prototype : {

		data : {
			myObject : {
				myString : 'This is a sample string'
			}
		}

	}
});