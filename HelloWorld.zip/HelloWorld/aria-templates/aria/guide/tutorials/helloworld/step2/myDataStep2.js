/*
 * Copyright Amadeus
 */
var myData = {
	myObject:{
		myString:'This is a sample string'
	}
}