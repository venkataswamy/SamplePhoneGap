/*
 * Copyright Amadeus
 */
/**
 * @class tutorials.helloworld.step3.TemplateStep3Data
 */
Aria.classDefinition({
	$classpath : 'tutorials.helloworld.step3.TemplateStep3Data',
	$constructor : function () {},
	$prototype : {

		data : {
			planet : "Earth",
			continents : ["Asia", "Africa", "North America", "South America", "Antarctica", "Europe", "Australia"]
		}

	}
});