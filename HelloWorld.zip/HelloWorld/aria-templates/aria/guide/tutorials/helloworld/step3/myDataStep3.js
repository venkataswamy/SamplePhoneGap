/*
 * Copyright Amadeus
 */
var myData = {
	planet:"Earth",
	continents:[
		"Asia",
		"Africa",
		"North America",
		"South America",
		"Antarctica",
		"Europe",
		"Australia"
	]
}