/*
 * Copyright Amadeus
 */
/**
 * @class tutorials.view.step1.ViewData
 */
Aria.classDefinition({
	$classpath : 'tutorials.view.step1.ViewData',
	$constructor : function () {},
	$prototype : {

		data : {
			articles : [{
						"name" : "Dictionary",
						"price" : {
							"currency" : "EUR",
							"value" : 30
						}
					}, {
						"name" : "Key ring",
						"price" : {
							"currency" : "USD",
							"value" : 2
						}
					}, {
						"name" : "Washing machine",
						"price" : {
							"currency" : "EUR",
							"value" : 300
						}
					}, {
						"name" : "Laptop",
						"price" : {
							"currency" : "USD",
							"value" : 500
						}
					}, {
						"name" : "Pen",
						"price" : {
							"currency" : "USD",
							"value" : 1
						}
					}, {
						"name" : "Telephone",
						"price" : {
							"currency" : "USD",
							"value" : 30
						}
					}, {
						"name" : "USB Key 10G",
						"price" : {
							"currency" : "USD",
							"value" : 30
						}
					}, {
						"name" : "Key ring",
						"price" : {
							"currency" : "EUR",
							"value" : 1
						}
					}, {
						"name" : "Wireless access point",
						"price" : {
							"currency" : "EUR",
							"value" : 100
						}
					}]
		}

	}
});