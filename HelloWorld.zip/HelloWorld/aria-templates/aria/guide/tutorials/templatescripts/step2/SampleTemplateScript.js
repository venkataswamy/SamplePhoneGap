/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'tutorials.templatescripts.step2.SampleTemplateScript',
	$prototype : {

		$dataReady : function () {
			if (!this.data.linesCount) {
				this.data.linesCount = 3;
			}
		},

		increaseLinesCount : function () {
			this.data.linesCount++;
		},

		globalRefresh : function () {
			this.$refresh();
		}

	}
});