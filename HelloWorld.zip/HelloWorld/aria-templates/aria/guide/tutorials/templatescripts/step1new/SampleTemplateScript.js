/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'tutorials.templatescripts.step1new.SampleTemplateScript',
	$prototype : {

		$viewReady : function () {
			alert('The template is ready to be displayed!');
		},

		getTagFromAge : function (age) {
			if (age < 13) {
				return "child";
			} else if (age < 20) {
				return "teenager";
			} else {
				return "adult";
			}
		}
	}
});