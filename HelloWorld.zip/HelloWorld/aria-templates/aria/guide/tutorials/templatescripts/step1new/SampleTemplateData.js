/*
 * Copyright Amadeus
 */
Aria.classDefinition({
	$classpath : 'tutorials.templatescripts.step1new.SampleTemplateData',
	$constructor : function () {},
	$prototype : {

		data : {
			people : [{
						name : 'John',
						age : 19,
						livesIn : "Europe"
					}, {
						name : 'Francis',
						age : 25,
						livesIn : "Europe"
					}, {
						name : 'Jean',
						age : 70,
						livesIn : "North America"
					}, {
						name : 'Pedro',
						age : 35,
						livesIn : "South America"
					}, {
						name : 'Luca',
						age : 2,
						livesIn : "Asia"
					}]
		}

	}
});