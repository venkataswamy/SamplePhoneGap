/*
 * Copyright Amadeus
 */
/**
 * Tutorial for template scripts
 * @class tutorials.templatescripts.step1.SampleTemplateScript
 */
Aria.tplScriptDefinition({
	$classpath : 'tutorials.templatescripts.step1.SampleTemplateScript',
	$prototype : {
				
		showAlert: function() {
			alert('Alert!');			
		},	
		
		getContent: function() {
			return '[Some content from the script]'
		}
	}
}); 