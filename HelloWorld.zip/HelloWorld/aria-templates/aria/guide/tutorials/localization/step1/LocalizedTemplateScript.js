/*
 * Copyright Amadeus
 */
/**
 * Tutorial template script for localization
 * @class tutorials.localization.step1.LocalizedTemplateScript
 */
Aria.tplScriptDefinition({
	$classpath : 'tutorials.localization.step1.LocalizedTemplateScript',
	$prototype : {
		clickOK : function () {
			alert(this.res.hello.label.clickOK);
		}
	}
});