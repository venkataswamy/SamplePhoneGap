/*
 * Copyright Amadeus
 */
Aria.beanDefinitions({
	$package : "tutorials.datamodel.step1.DataBean",
	$description : "Definition of the Data Model for our Module Controller",
	$namespaces : {
		"json" : "aria.core.JsonTypes"
	},
	$beans : {
		"Root" : {
			$type : "json:Object",
			$description : "Base bean definition",
			$mandatory : true,
			$properties : {
				"name" : {
					$type : "json:String",
					$description : "Full name of the user",
					$default : "John Doe"
				},
				"notes" : {
					$type : "json:Array",
					$description : "List of notes.",
					$contentType : {
						$type : "Note",
						$description : "A single note."
					},
					$default : [{
						"text" : "Create a new note",
						"createdOn" : "28 Oct 2011"
					}]
				}
			}
		},

		"Note" : {
			$type : "json:Object",
			$description : "A single note.",
			$properties : {
				"text" : {
					$type : "json:String",
					$description : "Content of the note."
				},
				"createdOn" : {
					$type : "json:String",
					$description : "Creation date."
				}
			}
		}
	}
});