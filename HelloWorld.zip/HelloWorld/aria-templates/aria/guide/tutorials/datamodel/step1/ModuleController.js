/*
 * Copyright Amadeus
 */
Aria.classDefinition({
	$classpath : "tutorials.datamodel.step1.ModuleController",
	$extends : "aria.templates.ModuleCtrl",
	$implements : ["aria.templates.IModuleCtrl"],
	$dependencies : ["tutorials.datamodel.step1.DataBean"],
	$constructor : function () {
		this.$ModuleCtrl.constructor.call(this);
	},
	$desctructor : function () {
		this.$ModuleCtrl.$destructor.call(this);
	},
	$prototype : {
		$publicInterfaceName : "aria.templates.IModuleCtrl",

		/**
		 * Override the init function of ModuleCtrl.
		 * This function is asynchronous
		 * @override
		 * @param {Object} args Init arguments
		 * @param {aria.utils.Callback} cb Asynchronous callback
		 */
		init : function (args, cb) {
			// Note that the datamodel bean is loaded as a dependency
			var datamodel = {};

			// Normalize the datamodel, in this simple example we don't need to check the return value
			aria.core.JsonValidator.normalize({
				json : datamodel,
				beanName : "tutorials.datamodel.step1.DataBean.Root"
			});

			// Set the datamodel
			this._data = datamodel;

			this.$callback(cb);
		}
	}
});