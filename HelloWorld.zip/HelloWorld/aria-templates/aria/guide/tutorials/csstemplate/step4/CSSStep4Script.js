/*
 * Copyright Amadeus
 */
/**
 * TODOC
 * @class tutorials.csstemplate.step4.CSSStep4Script
 */
Aria.tplScriptDefinition({
	$classpath : 'tutorials.csstemplate.step4.CSSStep4Script',
	$prototype : {

		/**
		 * TODOC
		 */
		printFontProperties : function (font) {
			var stringToReturn = [];
			var randomColor = Math.floor(Math.random() * 16777216);
			stringToReturn.push("color: #",randomColor.toString(16),";");

			for (var property in font) {
				if (font.hasOwnProperty(property)) {
					stringToReturn.push("\nfont-",property,": ",font[property],";");
				}
			}
			return stringToReturn.join("");
		}
	}
});
