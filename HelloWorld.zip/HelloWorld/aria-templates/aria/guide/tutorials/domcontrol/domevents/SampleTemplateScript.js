/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath:  'tutorials.domcontrol.domevents.SampleTemplateScript',
	$prototype:{
		
		$dataReady : function () {
			this.data["view:dropDownCollapsed"] = true;
		},
		
		clickHandler : function (evt,args) {
			alert(args.myArg);
		},
		
		dropDownHandler : function (evt) {
			if (evt.type == "mouseover") {
				this.$json.setValue(this.data, "view:dropDownCollapsed", false);
			} else if (evt.type == "mouseout") {
				this.$json.setValue(this.data, "view:dropDownCollapsed", true);
			} 
		}
	}
});