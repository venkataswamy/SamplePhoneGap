/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'tutorials.domcontrol.domaccess.SampleTemplateScript',
	$prototype : {

		__procIndVisible : false,

		setProcInd : function () {
			this.__procIndVisible = !this.__procIndVisible;
			var mySpan = this.$getElementById("mySpan");
			mySpan.setProcessingIndicator(this.__procIndVisible);
		},

		giveFocus : function () {
			this.$focus("myTextField");
		},

		changeClass : function () {
			var mySection = this.$getElementById("mySection");
			var oldClass = mySection.classList.getClassName();
			var newClass = (oldClass == "mySectionClassOne") ? "mySectionClassTwo" : "mySectionClassOne";
			mySection.classList.setClassName(newClass);
		}
	}
});