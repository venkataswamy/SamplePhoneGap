/*
 * Copyright Amadeus
 */
aria.core.DownloadMgr.updateUrlMap({"apps": {"guide":     {
        "lib":         {
            "lang-scala": "apps/guide/lib/lang-scala.js",
            "lang-proto": "apps/guide/lib/lang-proto.js",
            "lang-go": "apps/guide/lib/lang-go.js",
            "lang-clj": "apps/guide/lib/lang-clj.js",
            "lang-vhdl": "apps/guide/lib/lang-vhdl.js",
            "lang-wiki": "apps/guide/lib/lang-wiki.js",
            "lang-n": "apps/guide/lib/lang-n.js",
            "lang-hs": "apps/guide/lib/lang-hs.js",
            "lang-lisp": "apps/guide/lib/lang-lisp.js",
            "lang-sql": "apps/guide/lib/lang-sql.js",
            "lang-apollo": "apps/guide/lib/lang-apollo.js",
            "lang-css": "apps/guide/lib/lang-css.js",
            "lang-lua": "apps/guide/lib/lang-lua.js",
            "lang-vb": "apps/guide/lib/lang-vb.js",
            "lang-ml": "apps/guide/lib/lang-ml.js",
            "lang-tex": "apps/guide/lib/lang-tex.js",
            "lang-yaml": "apps/guide/lib/lang-yaml.js",
            "prettify": "apps/guide/lib/prettify.js",
            "lang-xq": "apps/guide/lib/lang-xq.js"
        },
        "internals":         {
            "createSample":             {
                "validators": {"Category": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"},
                "*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js",
                "steps": {"*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"}
            },
            "*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"
        },
        "main":         {
            "home": {"*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"},
            "dataModel": {"*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"},
            "navigationModules": {"*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"},
            "*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js",
            "sidebar": {"*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"},
            "header": {"*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"},
            "breadcrumbs": {"*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"},
            "samplecollection": {"*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"},
            "search": {"*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"},
            "documentation": {"*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"},
            "library": {"*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"},
            "mainContent": {"*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"},
            "sample": {"*": "apps/guide/guide_897c70a10a490e38bb2799d18d06bb90.js"}
        }
    }}});