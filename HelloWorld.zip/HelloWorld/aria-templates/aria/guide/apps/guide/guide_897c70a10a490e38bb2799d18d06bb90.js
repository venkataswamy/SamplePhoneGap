/*
 * Copyright Amadeus
 */
//***MULTI-PART
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/Form.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.internals.createSample.Form",
	$hasScript : false
}}
	{macro main()}
		{@aria:ErrorList {
			bind: {
				messages: {
					to: "errorMessages",
					inside: data
				}
			}
		}/}
	
		{@aria:AutoComplete {
			label: "Category",
			mandatory: true,
			resourcesHandler: moduleCtrl.getCategoriesHandler(),
			bind : {
				value : {
					to : "category",
					inside : data.newSampleConf
				}
			}
		}/}
		<br />
		
		{@aria:TextField {
			label: "Name",
			mandatory: true,
			bind : {
				value : {
					to : "name",
					inside : data.newSampleConf
				}
			}
		}/}
		<br />
		
		{@aria:TextField {
			label: "Description",
			bind : {
				value : {
					to : "description",
					inside : data.newSampleConf
				}
			}
		}/}
		<br />
		{@aria:TextField {
			label: "Template Classpath",
			mandatory: true,
			bind : {
				value : {
					to : "templateClasspath",
					inside : data.newSampleConf
				}
			}
		}/}
		<br />
		
		{@aria:CheckBox {
			label: "Has Data Model",
			bind : {
				value : {
					to : "hasDataModel",
					inside : data.newSampleConf,
					transform : {
						fromWidget : function (value) {
							this.$json.setValue(data.newSampleConf, "hasModuleCtrl", false);
							return value;
						}
					}
				},
				disabled : {
					to : "hasModuleCtrl",
					inside : data.newSampleConf
				}
			}
		}/}
		<br />
		
		{@aria:TextField {
			label : "Data Classpath",
			mandatory: true,
			bind : {
				value : {
					to : "dataClasspath",
					inside : data.newSampleConf
				},
				disabled : {
					to : "hasDataModel",
					inside : data.newSampleConf,
					transform : function (value) {
						return !value;
					}
				}
			}
		}/}
		<br />
		
		
		{@aria:CheckBox {
			label: "Has Module Controller",
			bind : {
				value : {
					to : "hasModuleCtrl",
					inside : data.newSampleConf,
					transform : {
						fromWidget : function (value) {
							this.$json.setValue(data.newSampleConf, "hasDataModel", false);
							return value;
						}
					}
				},
				disabled : {
					to : "hasDataModel",
					inside : data.newSampleConf
				}
			}
		}/}
		<br />
		
		{@aria:TextField {
			label : "ModuleCtrl Classpath",
			mandatory: true,
			bind : {
				value : {
					to : "mctrlClasspath",
					inside : data.newSampleConf
				},
				disabled : {
					to : "hasModuleCtrl",
					inside : data.newSampleConf,
					transform : function (value) {
						return !value;
					}
				}
			}
		}/}
		<br />
		{@aria:TextField {
			label : "ModuleCtrl Refpath",
			mandatory: true,
			bind : {
				value : {
					to : "mctrlRefpath",
					inside : data.newSampleConf
				},
				disabled : {
					to : "hasModuleCtrl",
					inside : data.newSampleConf,
					transform : function (value) {
						return !value;
					}
				}
			}
		}/}
		<br />
		
		{@aria:CheckBox {
			label: "Create Template Test",
			bind : {
				value : {
					to : "hasTemplateTest",
					inside : data.newSampleConf
				}
			}
		}/}
		<br />
		
		{@aria:TextField {
			label : "Test classpath",
			mandatory: true,
			bind : {
				value : {
					to : "testClasspath",
					inside : data.newSampleConf
				},
				disabled : {
					to : "hasTemplateTest",
					inside : data.newSampleConf,
					transform : function (value) {
						return !value;
					}
				}
			}
		}/}
		<br />
		
		
		{@aria:MultiSelect {
			label : "Restrict from Audience",
			fieldDisplay : "label",
			bind : {
				value : {
					to : "audience",
					inside : data.newSampleConf
				}
			},
			items : [
				{value: "uideveloper", label : "UI Developer"},
				{value: "customiser", label : "Customiser"},
				{value: "serverscripter", label : "Server Side Scripting"}
			]
		}/}
		<br />
		
		
		{@aria:Button {
			label : "Create",
			onclick : {
				fn : "submitNewSample",
				scope : moduleCtrl
			}
		}/}
	{/macro}
	
{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/AppDataModel.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.internals.createSample.steps.AppDataModel",
	$extends : "apps.guide.internals.createSample.steps.GeneralStep",
	$hasScript : true
}}

{var dummy = buildResultBean() /}

{macro main()}
	{call common.contentTitle("Application Data Model") /}
	Open the file {call common.fileName("apps.guide.main.dataModel.SamplesList") /} and replace the content of <strong>$prototype</strong> with

	{call $GeneralStep.sourceFile(aria.utils.Json.convertToJsonString(this.data.initialBean, {indent : "\t", maxDepth : 50}), "height: 300px; width: 700px; overflow:auto") /}

	<br />
	{@aria:Button {
		label : "Next",
		onclick : {
			fn : "nextStep",
			scope: moduleCtrl
		}
	}/}
{/macro}

{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/GeneralStep.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.internals.createSample.steps.GeneralStep",
	$hasScript : true,
	$macrolibs : {
		common : "apps.guide.main.library.CommonMacros"
	}
}}

{macro main()}
{/macro}

{macro sourceFile(content, extra)}
	{call common.sourceFile(setAndGetContentFile(content), extra) /}
{/macro}

{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/GoTo.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.internals.createSample.steps.GoTo"
}}

{macro main()}
You can now edit your sample in Eclipse and visit <a {on click {fn: "goToSample", scope: moduleCtrl} /}>your sample</a>
{/macro}

{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/ModuleController.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.internals.createSample.steps.ModuleController",
	$texts : {
		mctrl : "apps.guide.internals.createSample.steps.TextModuleController",
		itf : "apps.guide.internals.createSample.steps.TextModuleControllerInterface"
	},
	$hasScript : true,
	$macrolibs : {
		common : "apps.guide.main.library.CommonMacros"
	}
}}

{var cfg = {
	mctrlPath : data.newSample.location.moduleCtrlClasspath,
	interfacePath : buildInterfaceFromMctrlPath(data.newSample.location.moduleCtrlClasspath)
} /}

{macro main()}
	{call common.contentTitle("Module Controller") /}
	Inside Aria Samples stream create the file {call common.fileName("src.main.webapp." + cfg.mctrlPath)  /}
	
	<pre class="sampleDisplayContent">
		${mctrl.processTextTemplate(cfg)}
	</pre>

	{call common.contentTitle("Module Controller - Interface") /}
	Inside Aria Samples stream create the file {call common.fileName("src.main.webapp." + cfg.interfacePath)  /}
	
	
	<pre class="sampleDisplayContent">
		${itf.processTextTemplate(cfg)}
	</pre>
<br />
{@aria:Button {
	label : "Next",
	onclick : {
		fn : "nextStep",
		scope: moduleCtrl
	}
}/}
{/macro}

{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/SampleTest.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.internals.createSample.steps.SampleTest",
	$texts : {
		tpl : "apps.guide.internals.createSample.steps.TextSampleTest"
	},
	$extends : "apps.guide.internals.createSample.steps.GeneralStep"
}}

{var cfg = {
	testPath : "test.sampleTests." + data.newSample.location.templateClasspath + "TestCase",
	tplPath : data.newSample.location.templateClasspath
} /}

{macro main()}
	{call common.contentTitle("Test Case") /}
	Inside Aria Integration stream create the file {call common.fileName("src.main.static." + cfg.testPath)  /}
	
	{call $GeneralStep.sourceFile(tpl.processTextTemplate(cfg)) /}
	
	<br />
	{@aria:Button {
		label : "Next",
		onclick : {
			fn : "nextStep",
			scope: moduleCtrl
		}
	}/}
{/macro}

{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/TemplateFile.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.internals.createSample.steps.TemplateFile",
	$texts : {
		tpl : "apps.guide.internals.createSample.steps.TextTemplateFile"
	},
	$extends : "apps.guide.internals.createSample.steps.GeneralStep"
}}

{var cfg = {
	newClasspath : data.newSample.location.templateClasspath
} /}

{macro main()}
	{call common.contentTitle("Template") /}
	Inside Aria Samples stream create the file {call common.fileName("src.main.webapp." + cfg.newClasspath, ".tpl")  /}
	
	{call $GeneralStep.sourceFile(tpl.processTextTemplate(cfg)) /}
	
	<br />
	{@aria:Button {
		label : "Next",
		onclick : {
			fn : "nextStep",
			scope: moduleCtrl
		}
	}/}
{/macro}

{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/TplDataModel.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.internals.createSample.steps.TplDataModel",
	$texts : {
		tpl : "apps.guide.internals.createSample.steps.TextTplDataModel"
	},
	$extends : "apps.guide.internals.createSample.steps.GeneralStep"
}}

{var cfg = {
	newClasspath : data.newSample.location.dataClasspath
} /}

{macro main()}
	{call common.contentTitle("Sample Data Model") /}
	Inside Aria Samples stream create the file {call common.fileName("src.main.webapp." + cfg.newClasspath)  /}
	
	{call $GeneralStep.sourceFile(tpl.processTextTemplate(cfg)) /}
	
	<br />
	{@aria:Button {
		label : "Next",
		onclick : {
			fn : "nextStep",
			scope: moduleCtrl
		}
	}/}
{/macro}

{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/Main.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.internals.Main",
	$hasScript : true,
	$css : ["apps.guide.internals.MainCSS"]
}}
	{macro main()}
		<div class="content">
		{if !data.loadedTemplate}
			{call possibleAudiences() /}
			
			How would you make yourself useful today?<br />
			
			<a {on click { fn: "newSample", scope: moduleCtrl}/}>Create a Sample</a><br />
		{else /}
			{@aria:Template {
				defaultTemplate : data.loadedTemplate
			}/}
		{/if}
		</div>
	{/macro}
	
	
	{macro possibleAudiences()}
		Possible audiences that can be applied with ?audience=xxx are
		<table class="wikitable">
			<tbody>
				<tr>
					<th>Value</th>
					<th>Descritption</th>
				</tr>
				<tr>
					<td>customiser</td>
					<td>He will have access to basic documentation and Template customization.</td>
				</tr>
				<tr>
					<td>uideveloper</td>
					<td>He will have access to the whole documentation.</td>
				</tr>
				<tr>
					<td>serverscripter</td>
					<td>He will have access to the whole documentation.</td>
				</tr>
				<tr>
					<td>internal</td>
					<td>He will have access to the whole documentation and some internal tools.</td>
				</tr>
			</tbody>
		</table>
	{/macro}
{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/breadcrumbs/BreadcrumbsTemplate.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.main.breadcrumbs.BreadcrumbsTemplate",
	$hasScript : true,
	$css : ["apps.guide.main.breadcrumbs.BreadcrumbCSS"]
}}
	{var breadcrumbs = this.data.breadcrumbs /}
	{macro main()}

		{if breadcrumbs}
		<div class="breadcrumbs">
			{foreach part inArray breadcrumbs}
			{separator}>{/separator}
				{@aria:Link {
					label: getCrumbName(part),
					onclick: {fn : 'handleCrumbClick', args : part}
				} /}
			{/foreach}
		</div>
		{/if}
	{/macro}

{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/documentation/ContentTemplate.tpl
//z9A2tcZCFD
// Allows to display the content of a sample collection
{Template {
	$classpath: "apps.guide.main.documentation.ContentTemplate",
	$hasScript: true,
	$css: ["apps.guide.main.documentation.DocumentationCSS"]
}}
	{macro main()}

		<div class="documentationBody">${this.data.doc.pageContent}</div>
		
	{/macro}
	

{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/header/HeaderTemplate.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.main.header.HeaderTemplate",
	$hasScript : true,
	$macrolibs : {
		common : "apps.guide.main.library.CommonMacros"
	},
	$css : ["apps.guide.main.header.HeaderCSS"],
	$height : {value : 50},
	$dependencies : ["apps.guide.main.search.SearchBoxHandler"]
}}
	{var selected = this.getHighlightedTab() /}
	{macro main()}
	<div class=header>	
		<span class="banner" {on click {fn : "navigate", args : {path : "Home", type : "Home"}, scope: moduleCtrl} /}></span>
		<span class="bannerEdge"></span>
		<div class="mainMenu">
			// Home
			{call common.menuTab("Home", 
				(selected == "Home"),
				\{fn : "navigate", args : \{path : "Home", type : "Home"\}, scope: moduleCtrl\}
			) /}

            // Documentation
            {call common.menuTab("Documentation", 
                (selected == "Documentation"),
                \{fn : "navigate", args : \{path : "index", type : "doc"\}, scope: moduleCtrl\}
            ) /}
			
			// Samples
			{call common.menuTab("Samples", 
				(selected == "Sample"),
				\{fn : "navigate", args : \{path : "Samples", type : "spl"\}, scope: moduleCtrl\}
			) /}

            {call common.menuTab("Tutorials", 
                (selected == "Tutorial"),
                \{fn : "navigate", args : \{path : "Tutorials", type : "spl"\}, scope: moduleCtrl\}
            ) /}
			
			// Internal - Restricted to internal audience
			{call common.menuTab("Internals", 
				(selected == "Internals"),
				\{fn : 'navigate', args : \{path : 'Internals', type : 'int'\}, scope: moduleCtrl\},
				(Aria.audience !== "internal")
			) /}

			// API
			{call common.menuTab("API", 
				false,
				\{fn : 'navigate', args : \{path : '', type : 'APIdocs'\}, scope: moduleCtrl\}				
			) /}
		</div>
		
		<br />&nbsp;&nbsp;&nbsp;
		{@aria:AutoComplete {
			helptext : "Type here to search a Sample",
			resourcesHandler: "apps.guide.main.search.SearchBoxHandler",
			width : 300,
			popupWidth : 450,
			bind : {
				value : {
					inside : data,
					to : "searchBox:value"
				}
			},
			onchange : { fn : "searchboxChange" }
		}/}
	</div>
		
	{/macro}
{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/home/ContentTemplate.tpl
//z9A2tcZCFD
{Template {
	$classpath : 'apps.guide.main.home.ContentTemplate',
	$css : ['apps.guide.main.home.HomeCSS']
}}
	{macro main()}
			<div class="homeContent">
			<div>
				<div class="screenshot">&nbsp;</div>
				<h1>Build RIA with ARIA Templates</h1>
					 
	      		<p>Aria Templates complements the Aria framework family by adding support for client-side templates.</p><br/>
				<p>Client-side templates are the basis for the Customization Framework. They make it possible for clients to rewrite all or part of the UI of a web application.</p>
			</div><br/><br/><br/>
			<div>
				<p>This guide allows to learn how to use the features available in Aria Templates by means of samples and documentation pages.<br/>
				For each item displayed while browsing the guide, the sidebar reports a list of related documentation pages and samples.
				</p>
				<p>The main useful areas are the following:</p>
				<table class="tableOfContents">
				<tbody>
				<tr>
					<td><span class="homeLinks" {on click {fn : "navigate", args : {path : "index", type : "doc"}, scope: moduleCtrl} /}>Documentation</span></td>
					<td>contains documentation pages.</td>
				</tr>
				<tr>
					<td><span class="homeLinks" {on click {fn : "navigate", args : {path : "Samples", type : "spl"}, scope: moduleCtrl} /}>Samples</span></td>
					<td>contains some examples of various complexity.</td>
				</tr>
				<tr>
					<td><span class="homeLinks" {on click {fn : "navigate", args : {path : "Tutorials", type : "spl"}, scope: moduleCtrl} /}>Tutorials</span></td>
					<td>contains tutorials on the main features of Aria Templates. They are conceived for a step-wise navigation.</td>
				</tr>
				<tr>
					<td><span class="homeLinks" {on click {fn : "navigate", args : {path : "", type : "APIdocs"}, scope: moduleCtrl} /}>API doc</span></td>
					<td>redirects to the API documentation of Aria Templates.</td>
				</tr>
				</tbody>
				</table>
				
			</div>
			</div>				
	{/macro}	
{/Template}

//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/mainContent/MainContent.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.main.mainContent.MainContent",
	$hasScript : true,
	$css : ["apps.guide.main.mainContent.MainContentCSS"],
	$width : {min: 600}
}}
	{macro main()}

	{section { 
		id : "sidebar",
		cssClass : "sidebar",
		macro : "setSidebar"
	} /}

	{section { 
		id : "content",
		cssClass : "actualContent",
		macro : "setContent"
	} /}

	{/macro}

	{macro setSidebar()}
	
			{if this.data.currentState.contentType == "Home" || this.data.currentState.contentType == "Internals"}
				<div id="sidebarFilling" style="background: none repeat scroll 0 0 #EFF9FF;
			width: 220px;
			margin-left: 10px;"></div>
			{else /}
				{@aria:Template {
					width:250,
					defaultTemplate: "apps.guide.main.sidebar.SidebarTemplate",
					moduleCtrl: getSidebarController()
				}/}	
			{/if}
	{/macro}

	{macro setContent()}
			{@aria:Template {
				width:$hdim(400,0.85),
				defaultTemplate: getContentTemplatePath(),
				moduleCtrl: getContentController()
			}/}	
	{/macro}
	
{/Template}

//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/MainTemplate.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.main.MainTemplate",
	$hasScript : true,
	$width : {min: 600, max: 1260}
}}
	{macro main()}
			{@aria:Template {
				width:$hdim(600),
				height:50,
				defaultTemplate : 'apps.guide.main.header.HeaderTemplate',
				block:true
			}/}
	
		{section { 
			id : "mainContentSection",
			macro : "setMainContent"
		} /}
	{/macro}
	
	{macro setMainContent()}
			{@aria:Template {
				width: $hdim(600,1),
				defaultTemplate: "apps.guide.main.mainContent.MainContent",
				block: true
			}/}	
	{/macro}
	
{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/sample/ContentTemplate.tpl
//z9A2tcZCFD
// TODOC
{Template {
	$classpath: "apps.guide.main.sample.ContentTemplate",
	$hasScript: true,
	$macrolibs : {
		common : "apps.guide.main.library.CommonMacros"
	},
	$css : ["apps.guide.main.sample.SampleCSS"]
}}
	{var metadata = {visible : true} /}
	{var dataSnapshot = {} /}
	
	{var sample = this.data.spl /}
	{macro main()}
		{if sample}
			{@aria:Template {
				defaultTemplate: 'apps.guide.main.breadcrumbs.BreadcrumbsTemplate',
				block: true,
				data : {breadcrumbs : sample.breadcrumbs}
			}/}	
			
			{call displayPrevAndNext({previousSample : sample.data.previousSample, nextSample : sample.data.nextSample}, this.moduleCtrl) /}

			{if data.templateReady}
				{var displayType = sample.displayType /}
				{if displayType == "Output"}
					{call displayOutput() /}
				{elseif displayType == "Source" /}
					{call displaySource() /}
				{elseif displayType == "Data" /}
					{call displayData() /}
				{/if}
			{/if}
		{/if}
	{/macro}

	{macro displayOutput()}
		<div class="sampleTitle">Output of ${sample.data.name}</div>
		{if sample.data.preview}
			<div class="sampleDescription">
			{@aria:Template {
				defaultTemplate : sample.data.preview,
				block:true
			}/}
			</div>
		{elseif sample.data.description /}
			<div class="sampleDescription">${sample.data.description}
			</div>
		{/if}
		<div class="sampleDisplayContent">
		{var templateCfg = sample.data.location /}
	
		{if templateCfg.moduleCtrlClasspath}
			{@aria:Template {
				defaultTemplate : templateCfg.templateClasspath,
				moduleCtrl: moduleCtrl[templateCfg.refpath]
			}/}
		{else /}
			// Data sandboxing
			{@aria:Template {
				defaultTemplate :  templateCfg.templateClasspath,
 				data: (sample.sampleData)? sample.sampleData : {}
			}/}
		{/if}
		</div>
	{/macro}

	{macro displaySource()}
		<div class="sampleTitle">${this.getFilePath({classPath : sample.selectedItem, type : sample.sourceFileType})}</div>
		
		{call common.sourceFile(this.getFileContent({classPath : sample.selectedItem, type : sample.sourceFileType})) /}
	{/macro}
	
	{macro displayData()}
		{var dataSnapshot = getDataSnapshot() /}
		
		{section {
			id : "dataModel",
			bindRefreshTo : [{
				to : "visible",
				inside : metadata
			}],
			macro : "dataContent"
		}/}
	{/macro}
	
	{macro dataContent()}
		<div class="sampleTitle">Data Model Content</div>
		
		<div class="sourceContent">
			<div class="sourceContentLinks" {on click {
				fn : function () {
					this.$json.setValue(metadata, "visible", !metadata.visible);
				}} /}>
				{if metadata.visible}
					Hide metadata
				{else /}
					Show metadata
				{/if}
			</div>
			<pre class="prettyprint">${prettyFormatDataModel(dataSnapshot, metadata.visible)}</pre>
		</div>
	{/macro}
	
	{macro displayPrevAndNext(neighbours)}
		{if neighbours.nextSample || neighbours.previousSample}
			<div class="linkToSiblings">
			{if neighbours.previousSample}
				<span {on click {fn : "select", args : {type : neighbours.previousSample.type, path : neighbours.previousSample.path}, scope : this.moduleCtrl} /}>< ${neighbours.previousSample.name} </span>
			{/if}
			 | 
			{if neighbours.nextSample}
				<span {on click {fn : "select", args : {type : neighbours.nextSample.type, path : neighbours.nextSample.path}, scope : this.moduleCtrl} /}>${neighbours.nextSample.name} ></span>
			{/if}
			</div>
		{/if}
	{/macro}
	
{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/samplecollection/ContentTemplate.tpl
//z9A2tcZCFD
// Allows to display the content of a sample collection
{Template {
	$classpath: "apps.guide.main.samplecollection.ContentTemplate",
	$hasScript: true,
	$css : ['apps.guide.main.samplecollection.SampleCollectionCSS']
}}
	// portion of the datamodel that describes the sample collection
	{var sample = this.data.spl.data /}
	{macro main()}
		{@aria:Template {
			defaultTemplate: 'apps.guide.main.breadcrumbs.BreadcrumbsTemplate',
			block: true,
			data : {breadcrumbs : this.data.spl.breadcrumbs}
		}/}

		{call displayPrevAndNext({previousSample : sample.previousSample, nextSample : sample.nextSample}, this.moduleCtrl) /}

		<div class="sampleCollectionTitle">${sample.name}</div>
		{if sample.preview}
			<div class="sampleCollectionDescription">
			{@aria:Template {
				defaultTemplate : sample.preview,
				block:true
			}/}
			</div>
		{elseif sample.description /}
			<div class="sampleCollectionDescription">${sample.description}</div>
		{/if}

		{section {
			id : "sampleCollection",
			cssClass : "collectionDisplay",
			type : "UL",
			macro : {
				name : "displayCollection",
				args : [sample],
				scope : this
			}
		} /}
	{/macro}


	{macro displayCollection(currentSample)}
		{foreach item inArray currentSample.items}
			{var classSuffix = (!((item_index+1)%3))? "Last" : "" /}
			<li class="sampleShot${classSuffix}" {on click {fn : "select", args : {path : item.packageName, type : "spl"}, scope: moduleCtrl} /}>
				{call displayCollectionItem(item) /}
			</li>
		{/foreach}
	{/macro}

	{macro displayCollectionItem(item)}
		{if item.image}
		<img src="
			${item.image}
		"/>
		{/if}
		<h1 class="sampleShotName">
			{@aria:Link {
				label: item.name,
				onclick: {fn : "select", args : {path : item.packageName, type : "spl"}, scope: moduleCtrl}
			} /}</h1>
		{if item.description}
			<div class="sampleShotDescription">${item.description}</div>
		{/if}
	{/macro}

	{macro displayPrevAndNext(neighbours)}
		{if neighbours.nextSample || neighbours.previousSample}
			<div class="linkToSiblings">
			{if neighbours.previousSample}
				<span {on click {fn : "select", args : {type : neighbours.previousSample.type, path : neighbours.previousSample.path}, scope : this.moduleCtrl} /}>< ${neighbours.previousSample.name} </span>
			{/if}
			 |
			{if neighbours.nextSample}
				<span {on click {fn : "select", args : {type : neighbours.nextSample.type, path : neighbours.nextSample.path}, scope : this.moduleCtrl} /}>${neighbours.nextSample.name} ></span>
			{/if}
			</div>
		{/if}
	{/macro}

{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/search/SearchBoxListTemplate.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.main.search.SearchBoxListTemplate",
	$extends : "aria.widgets.form.list.templates.ListTemplate",
	$hasScript : true
}}
	{macro main()}
		// The Div is used to wrap the items with good looking border.
		{@aria:Div data.cfg}
				{call approximate() /}
				
				{section {
					id : "Items",
					type : "div"
				}}
				<table
						{if !data.disabled}
							{on mouseup {fn: "itemClick"} /}
							{on mouseover {fn: "itemMouseOver"} /}
						{/if} 
						
						cellpadding="0"
						cellspacing="0"
						// release hack. table does not take all available width, but does not break the display. FIXME
						${(aria.core.Browser.isIE7 && data.cfg.width != null && data.cfg.width <= 0) ? "" : "style='width:100%'"}
				>
					<tbody {id "myList" /}	>
							
						{for var i = 0; i < data.items.length; i++}
							{if data.items[i].object.value.label !== "view:approx"}
								{call renderItem(data.items[i], i)/}
							{/if}
						{/for}
						
					</tbody>
				</table>
				{/section}
		{/@aria:Div}
	{/macro}
	
	{macro renderItem(item, itemIdx)}
		<tr class="${_getClassForItem(item)}" _itemIdx="${itemIdx}">
				<td style="padding: 3px 0; border:none;">
					{var suggestion = item.object.value /}
					{var entry = item.object.entry /}
		
					&raquo;&nbsp;<span style="font-size: 115%; color: #000">${prettifyPath(suggestion.path)|highlight:entry}</span>
					
					<br />
					&nbsp;&nbsp;&nbsp;<em>${basicEllipsis(suggestion.description, 60)}</em>
				</td>
				<td style="text-align:right;color:#888;padding-left:5px;">
					${suggestion.type}
				</td>
		</tr>
	{/macro}
	
	{macro approximate()}
		{if data.items.length > 0}
			{var last = data.items[data.items.length - 1] /}
			{if last.object.value.label === "view:approx"}
				<div style="border-bottom: 1px solid black; padding: 2px;">No match for <strong><em>${last.object.entry}</em></strong>. Approximate results :</div>
			{/if}
		{/if}
	{/macro}
{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/sidebar/SidebarTemplate.tpl
//z9A2tcZCFD
{Template {
	$classpath : "apps.guide.main.sidebar.SidebarTemplate",
	$hasScript : true,
	$css : ["apps.guide.main.sidebar.SidebarCSS"]	
}}
	{var selectedItem = {value : null} /}
	{var display = {type : 'Output'} /}
	{var contentType = data.contentType /}
	{var sourceFilesCollapsed = {main : {collapsed : false}, secondary : {collapsed : true}} /}
	{macro main()}
		
		// Output link
		{call displayOutputBlock() /}
		
		// Data model link
		{call displayDataModelBlock() /}
		//Links to the blocks in the data model (source files, apis, ...)
		{if data.sidebar}
		{foreach itm in data.sidebar}
			{if itm && itm.items && itm.items.length > 0}
				{section {
					id : itm_index,
					macro : {
						name : "displayList",
						args : [itm]
					},
					type : "div",
					bindRefreshTo : [{
						to : "collapsed",
						inside : itm
					}]
				} /}
			{/if}
		
		{/foreach}
		{/if}
		<div id="sidebarFilling"></div>
	{/macro}	

	{macro displayList(itm)}
		{if itm.type == "Source"}
			{call displaySourceFilesList(itm) /}
		{else /}	
			<div class="sidebarBlock">
			<div class="sidebarBlockHeader" {on click {
				fn : "triggerBlockDisplay",
				args : itm,
				scope : this
			}/}>
				<span class="sidebarBlockTitle"> ${itm.text}</span>
							
				<span class="sidebarBlockIcon" >
					{@aria:Icon {
							icon : (itm["collapsed"]) ? "std:expand" : "std:collapse"
					} /}
				</span>
			</div>
			
			{if !itm["collapsed"]}
				<div class="sidebarBlockContent">
				{foreach entry inArray itm.items}
					<div class="sidebarBlockItem" {on click {fn : "select", args : {type : itm.type, value : entry.value, sourceFileType : (entry.type)? entry.type : null}, scope : this} /}>${entry.label}</div>
				{/foreach}
				</div>
			{/if}
			</div>
		{/if}
	{/macro}

	{macro displayOutputBlock()}
		{if contentType == "Sample"}
		<div class="sidebarBlock">
		<div class="sidebarBlockLink" {on click {fn : "select", args : {type : "Output", item : selectedItem}, scope : this} /}>
			<span class="sidebarBlockTitle">Output</span>
		</div>
		</div>
		{/if}
	{/macro}
	
	{macro displayDataModelBlock()}
		{if contentType == "Sample"}
		<div class="sidebarBlock">
		<div class="sidebarBlockLink" {on click {fn : "select", args : {type : "Data", item : selectedItem}, scope : this} /}>
			<span class="sidebarBlockTitle">Data Model</span>
		</div>
		</div>
		{/if}
	{/macro}

	
	{macro displaySourceFilesList(itm)}
		{var sourceFiles = splitMainAndSecondarySourceFiles(itm.items) /}

		{@aria:Tooltip {
					id: "sourceFilesLegend",
					macro: "legendTooltipMacro"
		} /}
		
		<div class="sidebarBlock">
		<div class="sidebarBlockHeader" {on click {
			fn : "triggerBlockDisplay",
			args : itm,
			scope : this
		}/}>
			<span class="sidebarBlockTitle"> 
			{if sourceFiles.secondary.length == 0 && !itm["collapsed"]}
				{@aria:Text {
					text: itm.text,
					tooltipId: "sourceFilesLegend",
					width: 180
				} /}
			{else /}
				${itm.text}
			{/if}
			</span>
						
			<span class="sidebarBlockIcon" >
				{@aria:Icon {
						icon : (itm["collapsed"]) ? "std:expand" : "std:collapse"
				} /}
			</span>
		</div>
		
		
		{if !itm["collapsed"]}

			{if sourceFiles.secondary.length == 0}
				<div class="sidebarBlockContent">
				{foreach entry inArray sourceFiles.main}
					<div class="sidebarBlockItem" {on click {fn : "select", args : {type : itm.type, value : entry.value, sourceFileType : (entry.type)? entry.type : null}, scope : this} /}>
						{@aria:Text {
								text: entry.label,
								tooltipId: "sourceFilesLegend",
								width: 184
						} /}
						{call printRoleIcon(entry.role) /}
					</div>
				{/foreach}
				</div>
			{else /}
				{section {
					id : "mainSourceFiles",
					macro : {
						name : "displaySourceFilesSubList",
						args : [sourceFiles.main, "main"]
					},
					type : "div",
					bindRefreshTo : [{
						to : "collapsed",
						inside : sourceFilesCollapsed.main
					}]
				} /}
				
				{section {
					id : "secondarySourceFiles",
					macro : {
						name : "displaySourceFilesSubList",
						args : [sourceFiles.secondary, "secondary"]
					},
					type : "div",
					bindRefreshTo : [{
						to : "collapsed",
						inside : sourceFilesCollapsed.secondary
					}]
				} /}
			{/if}

		{/if}
		</div>
	
	{/macro}
	
	{macro displaySourceFilesSubList(items, type)}
		{var collapsed = sourceFilesCollapsed[type].collapsed /}
		
		<div class="sidebarBlockSubHeader"{on click {
			fn : "triggerBlockDisplay",
			args : sourceFilesCollapsed[type],
			scope : this
		}/}>
			<span class="sidebarBlockSubTitle"> 

			<span class="sidebarBlockIconLeft" >
				{@aria:Icon {
						icon : (collapsed) ? "std:expand" : "std:collapse"
				} /}
			</span>

			{if type == "main" && !collapsed}
				{@aria:Text {
					text: type + " source files",
					tooltipId: "sourceFilesLegend",
					width: 180
				} /}
			{else/}
				${type}  source files
			{/if}
			
			</span>
						
		</div>
		{if !collapsed}
			<div class="sidebarBlockContent">
			{foreach entry inArray items}
				<div class="sidebarBlockItem" {on click {fn : "select", args : {type : "Source", value : entry.value, sourceFileType : (entry.type)? entry.type : null}, scope : this} /}>
					{if type == "main"}
						{@aria:Text {
								text: entry.label,
								tooltipId: "sourceFilesLegend",
								width: 184
						} /}
					{call printRoleIcon(entry.role) /}
					{else /}
						${entry.label}
					{/if}
				</div>
			{/foreach}
			</div>
		{/if}
	{/macro}



	{macro legendTooltipMacro()}
		{var sourceFilesRoles = this.getSourceFilesRoles() /}
		<table><tbody>
		{foreach role inArray sourceFilesRoles}
			<tr>
			<td>{call printRoleIcon(role) /}</td>
			<td>${role}</td>
			</tr>			
		{/foreach}
		</tbody></table>
	{/macro}

	{macro printRoleIcon(role)}
		<span class="roleIcon" style="background: ${getRoleColor(role)};">&nbsp</span>
	{/macro}
	
{/Template}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/MainCSS.tpl.css
//z9A2tcZCFD
{CSSTemplate {
	$classpath : "apps.guide.internals.MainCSS"
}}

{macro main()}

.content {
	margin-left: 150px;
}

table.wikitable {
	background: none repeat scroll 0 0 #F5FAFF;
	border: 1px solid #1A61A9;
	border-collapse: collapse;
	margin: 1em 1em 1em 0;
	border-collapse: collapse;
}

table.wikitable th {
	background: none repeat scroll 0 0 #E1F3FF;
	text-align: left;
}

table.wikitable th, table.wikitable td {
	border: 1px solid #1A61A9;
	padding: 0.2em;
}

.fileName {
	font-weight:bold
}

{/macro}
{/CSSTemplate}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/breadcrumbs/BreadcrumbCSS.tpl.css
//z9A2tcZCFD
{CSSTemplate {
	$classpath : 'apps.guide.main.breadcrumbs.BreadcrumbCSS'
}}

	{macro main()}
		.breadcrumbs {
			background: white;
			height : 30px;
			margin: 10px 20px 0 -10px;
			font-size: 12px;
			font-weight: bolder;
		}

		.breadcrumbs span {
			padding: 10px;
			position : relative;
			cursor: pointer;
		}

		.breadcrumbs a {
			color : #4776A7;
		}

	{/macro}

{/CSSTemplate}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/documentation/DocumentationCSS.tpl.css
//z9A2tcZCFD
{CSSTemplate {
	$classpath : "apps.guide.main.documentation.DocumentationCSS"
}}
	
	{var url = "url" /}
	
	{macro main()}
		/* Extracted from Topspot css */
		
		body {
		font:small sans-serif;
		background-color:#fff;
		color:#000;
		margin:0;
		padding:20px;
		}
		
		#globalTable {
		font-size:127%;
		width:100%;
		border-collapse:collapse;
		table-layout:fixed;
		margin:0;
		padding:0;
		}
		
		table {
		font-size:100%;
		color:#000;
		}
		
		fieldset table {
		background:none;
		}
		
		a {
		color:#002bb8;
		background:none;
		}
		
		a.stub {
		color:#723;
		}
		
		a.new {
		color:#ba0000;
		}
		
		a.new:visited {
		color:#a55858;
		}
		
		img {
		border:none;
		vertical-align:middle;
		}
		
		p {
		line-height:1.5em;
		margin:.4em 0 .5em;
		}
		
		p img {
		margin:0;
		}
		
		hr {
		height:1px;
		color:#1a61a9;
		background-color:#1a61a9;
		border:0;
		margin:.2em 0;
		}
		
		h1,h2,h3,h4,h5,h6 {
		color:#000;
		background:none;
		font-weight:400;
		padding-top:.5em;
		padding-bottom:.25em;
		border-bottom:1px solid #000;
		margin:0;
		}
		
		h1 {
		font-size:188%;
		}
		
		h1 .editsection {
		font-size:53%;
		}
		
		h2 {
		font-size:150%;
		}
		
		h2 .editsection {
		font-size:67%;
		}
		
		h3,h4,h5,h6 {
		border-bottom:none;
		font-weight:700;
		}
		
		h3 {
		font-size:132%;
		}
		
		h3 .editsection {
		font-size:76%;
		font-weight:400;
		}
		
		h4 {
		font-size:116%;
		}
		
		h4 .editsection {
		font-size:86%;
		font-weight:400;
		}
		
		h5 .editsection {
		font-weight:400;
		}
		
		h6 {
		font-size:80%;
		}
		
		h6 .editsection {
		font-size:125%;
		font-weight:400;
		}
		
		ul {
		line-height:1.5em;
		list-style-type:square;
		list-style-image:${url}("${this.cssFolderPath}/../../imgs/bullet.png");
		margin:.3em 0 0 1.5em;
		padding:0;
		}
		
		ol {
		line-height:1.5em;
		list-style-image:none;
		margin:.3em 0 0 3.2em;
		padding:0;
		}
		
		li {
		margin-bottom:.1em;
		}
		
		dt {
		font-weight:700;
		margin-bottom:.1em;
		}
		
		dl {
		margin-top:.2em;
		margin-bottom:.5em;
		}
		
		dd {
		line-height:1.5em;
		margin-left:2em;
		margin-bottom:.1em;
		}
		
		abbr,acronym,.explain {
		border-bottom:1px dotted #000;
		color:#000;
		background:none;
		cursor:help;
		}
		
		q {
		font-family:Times, "Times New Roman", serif;
		font-style:italic;
		}
		
		pre {
		color:#000;
		background-color:#f5faff;
		overflow-x:auto;
		width:96%;
		padding:1em 1em 15px;
		}
		
		#contentSub,#contentSub2 {
		font-size:84%;
		line-height:1.2em;
		color:#7d7d7d;
		width:auto;
		margin:0 0 1.4em 1em;
		}
		
		span.subpages {
		display:block;
		}
		
		#firstHeading {
		margin-bottom:.1em;
		line-height:1.2em;
		padding-bottom:0;
		}
		
		#catlinks {
		border:1px solid #1a61a9;
		background-color:#f5faff;
		margin-top:1em;
		clear:both;
		padding:5px;
		}
		
		.documentDescription {
		font-weight:700;
		display:block;
		line-height:1.5em;
		margin:1em 0;
		}
		
		.documentByLine {
		text-align:right;
		font-size:90%;
		clear:both;
		font-weight:400;
		color:#76797c;
		}
		
		.center {
		width:100%;
		text-align:center;
		}
		
		.center * {
		margin-left:auto;
		margin-right:auto;
		}
		
		#toc,.toc,.mw-warning {
		border:1px solid #1a61a9;
		background-color:#f5faff;
		font-size:95%;
		margin-left:auto;
		margin-right:auto;
		padding:5px;
		}
		
		#toc h2,.toc h2 {
		display:inline;
		border:none;
		font-size:100%;
		font-weight:700;
		padding:0;
		}
		
		#toc ul,.toc ul {
		list-style-type:none;
		list-style-image:none;
		margin-left:0;
		padding-left:0;
		text-align:left;
		}
		
		#toc ul ul,.toc ul ul {
		margin:0 0 0 2em;
		}
		
		.mw-warning {
		margin-left:50px;
		margin-right:50px;
		text-align:center;
		}
		
		div.floatright,table.floatright {
		clear:right;
		float:right;
		position:relative;
		border:0;
		margin:0 0 .5em .5em;
		}
		
		div.floatleft,table.floatleft {
		float:left;
		clear:left;
		position:relative;
		border:0;
		margin:0 .5em .5em 0;
		}
		
		div.thumb {
		margin-bottom:.5em;
		width:auto;
		border-color:#FFF;
		border-style:solid;
		}
		
		div.thumbinner {
		border:1px solid #ccc;
		background-color:#f5faff;
		font-size:94%;
		text-align:center;
		overflow:hidden;
		padding:3px!important;
		}
		
		html .thumbimage {
		border:1px solid #ccc;
		}
		
		html .thumbcaption {
		border:none;
		text-align:left;
		line-height:1.4em;
		font-size:94%;
		padding:3px!important;
		}
		
		div.magnify {
		float:right;
		border:none!important;
		background:none!important;
		}
		
		div.magnify a,div.magnify img {
		display:block;
		border:none!important;
		background:none!important;
		}
		
		div.tright {
		clear:right;
		float:right;
		border-width:.5em 0 .8em 1.4em;
		}
		
		div.tleft {
		float:left;
		clear:left;
		margin-right:.5em;
		border-width:.5em 1.4em .8em 0;
		}
		
		img.thumbborder {
		border:1px solid #ddd;
		}
		
		table.rimage {
		float:right;
		position:relative;
		margin-left:1em;
		margin-bottom:1em;
		text-align:center;
		}
		
		.toccolours {
		border:1px solid #1a61a9;
		background-color:#f5faff;
		font-size:95%;
		padding:5px;
		}
		
		#bodyContent a.external,#bodyContent a[href ^="gopher://"] {
		background:url(main/documentation/external.png) center right no-repeat;
		padding:0 13px;
		}
		
		.rtl #bodyContent a.external,.rtl #bodyContent a[href ^="gopher://"] {
		background-image:url(main/documentation/external-rtl.png);
		}
		
		#bodyContent a[href ^="https://"],.link-https {
		background:url(main/documentation/lock_icon.gif) center right no-repeat;
		padding:0 16px;
		}
		
		#bodyContent a[href ^="mailto:"],.link-mailto {
		background:url(main/documentation/mail_icon.gif) center right no-repeat;
		padding:0 18px;
		}
		
		#bodyContent a[href ^="news://"] {
		background:url(main/documentation/news_icon.png) center right no-repeat;
		padding:0 18px;
		}
		
		#bodyContent a[href ^="ftp://"],.link-ftp {
		background:url(main/documentation/file_icon.gif) center right no-repeat;
		padding:0 18px;
		}
		
		#bodyContent a[href ^="irc://"],#bodyContent a.extiw[href ^="irc://"],.link-irc {
		background:url(main/documentation/discussionitem_icon.gif) center right no-repeat;
		padding:0 18px;
		}
		
		#bodyContent a.external[href $=".ogg"],#bodyContent a.external[href $=".OGG"],#bodyContent a.external[href $=".mid"],#bodyContent a.external[href $=".MID"],#bodyContent a.external[href $=".midi"],#bodyContent a.external[href $=".MIDI"],#bodyContent a.external[href $=".mp3"],#bodyContent a.external[href $=".MP3"],#bodyContent a.external[href $=".wav"],#bodyContent a.external[href $=".WAV"],#bodyContent a.external[href $=".wma"],#bodyContent a.external[href $=".WMA"],.link-audio {
		background:url(main/documentation/audio.png) center right no-repeat;
		padding:0 13px;
		}
		
		#bodyContent a.external[href $=".ogm"],#bodyContent a.external[href $=".OGM"],#bodyContent a.external[href $=".avi"],#bodyContent a.external[href $=".AVI"],#bodyContent a.external[href $=".mpeg"],#bodyContent a.external[href $=".MPEG"],#bodyContent a.external[href $=".mpg"],#bodyContent a.external[href $=".MPG"],.link-video {
		background:url(main/documentation/video.png) center right no-repeat;
		padding:0 13px;
		}
		
		#bodyContent a.external[href $=".pdf"],#bodyContent a.external[href $=".PDF"],#bodyContent a.external[href *=".pdf#"],#bodyContent a.external[href *=".PDF#"],#bodyContent a.external[href *=".pdf?"],#bodyContent a.external[href *=".PDF?"],.link-document {
		background:url(main/documentation/document.png) center right no-repeat;
		padding:0 12px;
		}
		
		.rtl #bodyContent a.external {
		background-position:left;
		padding-right:0;
		}
		
		.rtl a.feedlink {
		background-position:right;
		padding-right:16px;
		padding-left:0;
		}
		
		.ltr #bodyContent a.external {
		padding-left:0;
		}
		
		#bodyContent a.extiw,#bodyContent a.extiw:active {
		color:#36b;
		background:none;
		padding:0;
		}
		
		#bodyContent a.external {
		color:#1a61a9;
		}
		
		#bodyContent .plainlinks a {
		background:none!important;
		padding:0!important;
		}
		
		#p-logo {
		width:171px;
		height:55px;
		text-align:center;
		}
		
		#containersearch {
		text-align:center;
		border-bottom:1px solid #1a61a9;
		padding:2px 0;
		}
		
		#searchform {
		margin:5px;
		}
		
		input.searchButton {
		margin-top:1px;
		font-size:95%;
		}
		
		#searchGoButton {
		padding-left:5px;
		padding-right:5px;
		width:35%;
		}
		
		#searchSearchButton {
		font-weight:700;
		width:55%;
		}
		
		#searchInput {
		width:90%;
		font-size:95%;
		margin:0;
		}
		
		#p-personal {
		overflow:hidden;
		text-align:right;
		vertical-align:top;
		white-space:nowrap;
		height:35px;
		font-size:98%;
		}
		
		#p-personal ul {
		list-style:none;
		text-transform:lowercase;
		margin:0 1em 0 0;
		}
		
		#p-personal li {
		display:inline;
		margin-left:1em;
		}
		
		#p-personal li a {
		text-decoration:none;
		color:#000;
		font-size:90%;
		font-family:sans-serif;
		white-space:nowrap;
		}
		
		li#pt-userpage,li#pt-anonuserpage,li#pt-login {
		background:url(main/documentation/user.gif) top left no-repeat;
		padding-left:20px;
		text-transform:none;
		}
		
		#p-misc {
		height:20px;
		font-size:0;
		text-align:right;
		}
		
		#p-misc img {
		position:relative;
		top:1px;
		margin-left:5px;
		}
		
		#p-misc img#ca-talk {
		margin-right:20px;
		}
		
		#p-misc img#ca-watch,#p-misc img#ca-unwatch,#p-misc img#ca-varlang-0,#p-misc img#ca-print {
		margin-left:20px;
		}
		
		#actions {
		font-size:95%;
		vertical-align:top;
		}
		
		#actions ul {
		position:relative;
		left:-1px;
		top:-2px;
		list-style:none;
		margin:0;
		}
		
		#actions li {
		display:inline;
		margin-right:1px;
		background-color:#999;
		padding:1px 0;
		}
		
		#actions li.selected {
		background-color:#000;
		}
		
		#actions li a {
		color:#FFF;
		text-decoration:none;
		padding:.2em 1em;
		}
		
		#p-lang {
		position:relative;
		z-index:3;
		}
		
		#t-ispermalink,#t-iscite {
		color:#999;
		}
		
		#footer {
		background-color:#FFF;
		text-align:center;
		clear:both;
		line-height:1em;
		margin:1em 0;
		padding:.25em 1em;
		}
		
		#footer div {
		margin:.75em 0;
		}
		
		#preftoc {
		width:100%;
		clear:both;
		margin:0;
		padding:0;
		}
		
		#preftoc li {
		float:left;
		background-color:#f0f0f0;
		color:#000;
		border:1px solid #fff;
		border-right-color:#716f64;
		border-bottom:0;
		position:relative;
		white-space:nowrap;
		list-style-type:none;
		list-style-image:none;
		z-index:3;
		margin:1px -2px 1px 2px;
		padding:2px 0 3px;
		}
		
		#preftoc li.selected {
		font-weight:700;
		background-color:#f5faff;
		border:1px solid #1a61a9;
		border-bottom:none;
		cursor:default;
		top:1px;
		padding-top:2px;
		margin-right:-3px;
		}
		
		#preftoc > li.selected {
		top:2px;
		}
		
		#preftoc a,#preftoc a:active {
		display:block;
		color:#000;
		position:relative;
		text-decoration:none;
		padding:0 .7em;
		}
		
		#preftoc li.selected a {
		cursor:default;
		text-decoration:none;
		}
		
		#prefcontrol {
		padding-top:2em;
		clear:both;
		}
		
		#preferences {
		border:1px solid #1a61a9;
		clear:both;
		background-color:#f5faff;
		margin:0;
		padding:1.5em;
		}
		
		.prefsection {
		border:none;
		margin:0;
		padding:0;
		}
		
		.prefsection fieldset {
		border:1px solid #1a61a9;
		float:left;
		margin-right:2em;
		}
		
		div.prefsectiontip {
		font-size:x-small;
		color:#666;
		padding:.2em 2em;
		}
		
		.btnSavePrefs {
		font-weight:700;
		padding-left:.3em;
		padding-right:.3em;
		}
		
		.preferences-login {
		clear:both;
		margin-bottom:1.5em;
		}
		
		.prefcache {
		font-size:90%;
		margin-top:2em;
		}
		
		div#userloginForm form,div#userlogin form#userlogin2 {
		border:1px solid #1a61a9;
		clear:both;
		background-color:#f5faff;
		margin:0 0 1em;
		padding:1.5em 2em;
		}
		
		.rtl div#userloginForm form,.rtl div#userlogin form#userlogin2 {
		float:right;
		}
		
		div#userloginForm h2,div#userlogin form#userlogin2 h2 {
		padding-top:0;
		}
		
		div#userlogin .captcha,div#userloginForm .captcha {
		border:1px solid #bbb;
		background-color:#FFF;
		padding:1.5em 2em;
		}
		
		#userloginprompt {
		font-size:85%;
		}
		
		#login-emailforlost {
		font-size:85%;
		line-height:1.2em;
		padding-top:2em;
		}
		
		#userlogin .loginText,#userlogin .loginPassword {
		width:12em;
		}
		
		* > html #p-misc li {
		border:none;
		}
		
		* > html #p-misc li a {
		border:1px solid #1a61a9;
		border-bottom:none;
		}
		
		* html div.editsection {
		font-size:smaller;
		}
		
		#pagehistory li.selected {
		position:relative;
		}
		
		.redirectText {
		font-size:150%;
		margin:5px;
		}
		
		.not-patrolled {
		background-color:#ffa;
		}
		
		div.patrollink {
		clear:both;
		font-size:75%;
		text-align:right;
		}
		
		span.unpatrolled {
		font-weight:700;
		color:red;
		}
		
		span.updatedmarker {
		color:#000;
		background-color:#0f0;
		}
		
		table.gallery {
		border:1px solid #ccc;
		background-color:#FFF;
		margin:2px;
		padding:2px;
		}
		
		table.gallery tr {
		vertical-align:top;
		}
		
		table.gallery td {
		vertical-align:top;
		background-color:#f5faff;
		border:solid 2px #FFF;
		}
		
		div.gallerybox {
		margin:2px;
		}
		
		div.gallerybox div.thumb {
		text-align:center;
		border:1px solid #ccc;
		margin:2px;
		}
		
		div.gallerytext {
		overflow:hidden;
		font-size:94%;
		padding:2px 4px;
		}
		
		span.changedby {
		font-size:95%;
		}
		
		.previewnote {
		text-indent:3em;
		color:#c00;
		border-bottom:1px solid #000;
		padding-bottom:1em;
		margin-bottom:1em;
		}
		
		.previewnote p {
		margin:0;
		padding:0;
		}
		
		.editExternally {
		border:1px solid gray;
		background-color:#fff;
		margin-top:.5em;
		float:left;
		font-size:small;
		text-align:center;
		padding:3px;
		}
		
		.editExternallyHelp {
		font-style:italic;
		color:gray;
		}
		
		.toggle {
		margin-left:2em;
		text-indent:-2em;
		}
		
		table.mw_metadata {
		font-size:.8em;
		margin-left:.5em;
		margin-bottom:.5em;
		width:300px;
		border:none;
		border-collapse:collapse;
		}
		
		table.mw_metadata th {
		font-weight:400;
		background-color:#f5faff;
		}
		
		table.mw_metadata td {
		background-color:#fcfcfc;
		padding:.1em;
		}
		
		table.mw_metadata td,table.mw_metadata th {
		text-align:center;
		border:1px solid #1a61a9;
		padding-left:.1em;
		padding-right:.1em;
		}
		
		ul#filetoc {
		text-align:center;
		border:1px solid #1a61a9;
		background-color:#f5faff;
		font-size:95%;
		margin-bottom:.5em;
		margin-left:0;
		margin-right:0;
		padding:5px;
		}
		
		#filetoc li {
		display:inline;
		list-style-type:none;
		padding-right:2em;
		}
		
		input#wpSummary {
		width:80%;
		}
		
		input#wpSave,input#wpDiff {
		margin-right:.33em;
		}
		
		table.revisionform_default {
		border:1px solid #000;
		}
		
		table.revisionform_focus {
		border:1px solid #000;
		background-color:#1a61a9;
		}
		
		tr.revision_tr_default {
		background-color:#eee;
		}
		
		tr.revision_tr_first {
		background-color:#ddd;
		}
		
		p.revision_saved {
		color:green;
		font-weight:700;
		}
		
		#mw_trackbacks {
		border:solid 1px #1a61a9;
		background-color:#f5faff;
		padding:.2em;
		}
		
		#allmessagestable th {
		background-color:#8cb0d4;
		}
		
		#allmessagestable tr.orig {
		background-color:#ffe2e2;
		}
		
		#allmessagestable tr.new {
		background-color:#e2ffe2;
		}
		
		div.noarticletext {
		border:1px solid #ccc;
		background:#fff;
		color:#000;
		padding:.2em 1em;
		}
		
		div#searchTargetContainer {
		left:10px;
		top:10px;
		width:90%;
		background:#FFF;
		}
		
		div#searchTarget {
		background:#f0f0f0;
		border:solid 1px blue;
		margin:5px;
		padding:3px;
		}
		
		div#searchTarget ul li {
		list-style:none;
		}
		
		div#searchTarget ul li:before {
		color:orange;
		content:"\00BB \0020";
		}
		
		div#searchTargetHide {
		float:right;
		border:solid 1px #000;
		background:#DCDCDC;
		padding:2px;
		}
		
		#powersearch p {
		margin-top:0;
		}
		
		div.multipageimagenavbox {
		border:solid 1px silver;
		background:#f0f0f0;
		margin:1em;
		padding:4px;
		}
		
		div.multipageimagenavbox div.thumb {
		border:none;
		margin-left:2em;
		margin-right:2em;
		}
		
		div.multipageimagenavbox hr {
		margin:6px;
		}
		
		table#sv-ext,table#sv-hooks,table#sv-software {
		margin:1em;
		padding:0;
		}
		
		#sv-ext td,#sv-hooks td,#sv-software td,#sv-ext th,#sv-hooks th,#sv-software th {
		border:1px solid #A0A0A0;
		padding:0 .15em;
		}
		
		#sv-ext th,#sv-hooks th,#sv-software th {
		background-color:#F0F0F0;
		color:#000;
		padding:0 .15em;
		}
		
		tr.sv-space {
		height:.8em;
		border:none;
		}
		
		.TablePager {
		min-width:80%;
		border-collapse:collapse;
		}
		
		.TablePager,.TablePager td,.TablePager th {
		border:1px solid #aaa;
		padding:0 .15em;
		}
		
		.TablePager td {
		background-color:#fff;
		}
		
		.imagelist .TablePager_col_img_description {
		white-space:normal;
		}
		
		.imagelist th.TablePager_sort {
		background-color:#ccf;
		}
		
		.templatesUsed {
		margin-top:1.5em;
		}
		
		.mw-summary-preview {
		margin:.1em 0;
		}
		
		div.mw-lag-warn-normal,div.mw-lag-warn-high {
		text-align:center;
		margin:3px auto;
		padding:3px;
		}
		
		div.mw-lag-warn-normal {
		border:1px solid #FC6;
		background-color:#FFC;
		}
		
		div.mw-lag-warn-high {
		font-weight:700;
		border:2px solid #F03;
		background-color:#FCC;
		}
		
		.MediaTransformError {
		background-color:#ccc;
		padding:.1em;
		}
		
		.MediaTransformError td {
		text-align:center;
		vertical-align:middle;
		font-size:90%;
		}
		
		div#mw-search-interwiki-caption {
		text-align:center;
		font-weight:700;
		font-size:95%;
		}
		
		.mw-search-interwiki-project {
		font-size:97%;
		text-align:left;
		background:#cae8ff;
		padding:.15em .15em .2em .2em;
		}
		
		.os-suggest {
		font-size:127%;
		}
		
		table.rci {
		width:100%;
		font-size:90%;
		}
		
		#menu {
		border-top:8px solid #1a61a9;
		border-bottom:3px solid #1a61a9;
		border-right:3px solid #1a61a9;
		vertical-align:top;
		width:172px;
		}
		
		.menuwrapper {
		font-family:sans-serif;
		font-size:95%;
		text-align:left;
		width:170px;
		background-color:#f5faff;
		}
		
		#menuwrappertoolbox {
		border-bottom:1px solid #1a61a9;
		}
		
		.menuwrapper a {
		text-decoration:none;
		color:#000;
		width:170px;
		margin:0;
		}
		
		.menuwrapper a:hover {
		text-decoration:none;
		color:#002bb8;
		}
		
		.menuwrappertitle {
		color:#fff;
		background-color:#1a61a9;
		border-top:1px solid #1a61a9;
		border-bottom:1px solid #1a61a9;
		cursor:pointer;
		width:170px;
		text-transform:uppercase;
		font-size:90%;
		margin:0;
		}
		
		#mwttoolbox {
		cursor:default;
		}
		
		.menucontainer {
		background-color:#f5faff;
		width:165px;
		margin:0;
		padding:0;
		}
		
		.menucontainer ul {
		color:#000;
		list-style-type:disc;
		list-style-image:url(main/documentation/images/bullet.png);
		width:165px;
		margin:2px 0;
		padding:0 0 0 1em;
		}
		
		.menucontainer li {
		line-height:1.2em;
		margin:0 .4em 0 1.2em;
		padding:0;
		}
		
		.menumargin {
		margin:.2em .2em .2em .5em;
		}
		
		table.wikitable {
		background:#f5faff;
		border:1px #1a61a9 solid;
		border-collapse:collapse;
		margin:1em 1em 1em 0;
		}
		
		table.wikitable th,table.wikitable td {
		border:1px #1a61a9 solid;
		padding:.2em;
		}
		
		table.wikitable th {
		background:#e1f3ff;
		text-align:left;
		}
		
		table.invisible th,table.invisible td {
		vertical-align:top;
		text-align:left;
		padding:.2em;
		}
		
		.restrictedpage-link {
		font-style:normal;
		}
		
		.visualClear,#loginend,#signupend {
		clear:both;
		}
		
		a:visited,a:active,#p-personal li a:active,#p-personal li a:hover,.menuwrapper a:active {
		color:#002bb8;
		}
		
		a:hover,#toc a:hover,table.rci a:hover {
		text-decoration:underline;
		}
		
		#p-personal a.new,div.floatright p,div.floatleft p,#actions li.new,.sharedUploadNotice,span.comment,.restrictedpage {
		font-style:italic;
		}
		
		h5,table.small {
		font-size:100%;
		}
		
		#siteSub,#jump-to-nav,.hiddenStructure,#p-misc .hiddenStructure,.mainLegend,.printfooter,table.collapsed tr.collapsable,tr.sv-space td,.toclimit-2 .toclevel-2,.toclimit-3 .toclevel-3,.toclimit-4 .toclevel-4,.toclimit-5 .toclevel-5,.toclimit-6 .toclevel-6,.toclimit-7 .toclevel-7 {
		display:none;
		}
		
		.small,.small *,#toc .toctoggle,.toc .toctoggle {
		font-size:94%;
		}
		
		#toccontainer,#toc #toctitle,.toc #toctitle,#toc .toctitle,.toc .toctitle,table.multipageimage td {
		text-align:center;
		}
		
		#toc a,.TablePager_nav a,table.rci a {
		text-decoration:none;
		}
		
		#p-personal li.active,.prefsection legend,#userloginlink a,#wpLoginattempt,#wpCreateaccount,span.newpage,span.minor,span.bot,table.mw_metadata caption,#wpSave {
		font-weight:700;
		}
		
		#p-personal li a:visited,.menuwrapper a:visited {
		color:#000;
		}
		
		.prefsection table,.prefsection legend,div#userloginForm table,div#userlogin form#userlogin2 table,#allmessagestable tr.def {
		background-color:#f5faff;
		}
		
		.TablePager th,.TablePager tr:hover td,.imagelist .TablePager_col_links {
		background-color:#eef;
		}
		
		.imagelist td,.imagelist th,.nowrap {
		white-space:nowrap;
		}
		
		
		/* Extracted from Topspot syntaxhighlight plugin */
		
		div.mw-geshi {
		  padding: 1em; 
		  margin: 1em 0; 
		  background-color:#eee;
		  border: 1px solid #ccc;
		}
		
		.javascript.source-javascript .de1, .javascript.source-javascript .de2 {font: normal normal 1em/1.2em monospace; margin:0; padding:0; background:none; vertical-align:top;}
		.javascript.source-javascript  {font-family:monospace;}
		.javascript.source-javascript .imp {font-weight: bold; color: red;}
		.javascript.source-javascript li, .javascript.source-javascript .li1 {font-weight: normal; vertical-align:top;}
		.javascript.source-javascript .ln {width:1px;text-align:right;margin:0;padding:0 2px;vertical-align:top;}
		.javascript.source-javascript .li2 {font-weight: bold; vertical-align:top;}
		.javascript.source-javascript .kw1 {color: #000066; font-weight: bold;}
		.javascript.source-javascript .kw2 {color: #003366; font-weight: bold;}
		.javascript.source-javascript .kw3 {color: #000066;}
		.javascript.source-javascript .co1 {color: #006600; font-style: italic;}
		.javascript.source-javascript .co2 {color: #009966; font-style: italic;}
		.javascript.source-javascript .coMULTI {color: #006600; font-style: italic;}
		.javascript.source-javascript .es0 {color: #000099; font-weight: bold;}
		.javascript.source-javascript .br0 {color: #009900;}
		.javascript.source-javascript .sy0 {color: #339933;}
		.javascript.source-javascript .st0 {color: #3366CC;}
		.javascript.source-javascript .nu0 {color: #CC0000;}
		.javascript.source-javascript .me1 {color: #660066;}
		.javascript.source-javascript .ln-xtra, .javascript.source-javascript li.ln-xtra, .javascript.source-javascript div.ln-xtra {background-color: #ffc;}
		.javascript.source-javascript span.xtra { display:block; }
		
		.at.source-at .de1, .at.source-at .de2 {font: normal normal 1em/1.2em monospace; margin:0; padding:0; background:none; vertical-align:top;}
		.at.source-at  {font-family:monospace;}
		.at.source-at .imp {font-weight: bold; color: red;}
		.at.source-at li, .at.source-at .li1 {font-weight: normal; vertical-align:top;}
		.at.source-at .ln {width:1px;text-align:right;margin:0;padding:0 2px;vertical-align:top;}
		.at.source-at .li2 {font-weight: bold; vertical-align:top;}
		.at.source-at .kw1 {color: #0000CC; font-weight: bold;}
		.at.source-at .kw2 {color: #CC00CC; font-weight: bold;}
		.at.source-at .co1 {color: #006600; font-style: italic;}
		.at.source-at .co2 {color: #009966; font-style: italic;}
		.at.source-at .coMULTI {color: #006600; font-style: italic;}
		.at.source-at .es0 {color: #000099; font-weight: bold;}
		.at.source-at .br0 {color: #009900;}
		.at.source-at .sy0 {color: #339933;}
		.at.source-at .st0 {color: #3366CC;}
		.at.source-at .nu0 {color: #CC0000;}
		.at.source-at .me1 {color: #660066;}
		.at.source-at .re0 {color: red; font-weight: bold;}
		.at.source-at .ln-xtra, .at.source-at li.ln-xtra, .at.source-at div.ln-xtra {background-color: #ffc;}
		.at.source-at span.xtra { display:block; }
		
		.html4strict.source-html4strict .de1, .html4strict.source-html4strict .de2 {font: normal normal 1em/1.2em monospace; margin:0; padding:0; background:none; vertical-align:top;}
		.html4strict.source-html4strict  {font-family:monospace;}
		.html4strict.source-html4strict .imp {font-weight: bold; color: red;}
		.html4strict.source-html4strict li, .html4strict.source-html4strict .li1 {font-weight: normal; vertical-align:top;}
		.html4strict.source-html4strict .ln {width:1px;text-align:right;margin:0;padding:0 2px;vertical-align:top;}
		.html4strict.source-html4strict .li2 {font-weight: bold; vertical-align:top;}
		.html4strict.source-html4strict .kw1 {color: #b1b100;}
		.html4strict.source-html4strict .kw2 {color: #000000; font-weight: bold;}
		.html4strict.source-html4strict .kw3 {color: #000066;}
		.html4strict.source-html4strict .coMULTI {color: #808080; font-style: italic;}
		.html4strict.source-html4strict .es0 {color: #000099; font-weight: bold;}
		.html4strict.source-html4strict .br0 {color: #66cc66;}
		.html4strict.source-html4strict .sy0 {color: #66cc66;}
		.html4strict.source-html4strict .st0 {color: #ff0000;}
		.html4strict.source-html4strict .nu0 {color: #cc66cc;}
		.html4strict.source-html4strict .sc0 {color: #00bbdd;}
		.html4strict.source-html4strict .sc1 {color: #ddbb00;}
		.html4strict.source-html4strict .sc2 {color: #009900;}
		.html4strict.source-html4strict .ln-xtra, .html4strict.source-html4strict li.ln-xtra, .html4strict.source-html4strict div.ln-xtra {background-color: #ffc;}
		.html4strict.source-html4strict span.xtra { display:block; }	
	{/macro}

{/CSSTemplate}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/header/HeaderCSS.tpl.css
//z9A2tcZCFD
{CSSTemplate {
	$classpath : 'apps.guide.main.header.HeaderCSS'
}}
	{var url = "url" /}
	{macro main()}

		.banner {
			background:#4776A7 ${url}("${this.cssFolderPath}/../../imgs/ariaHeader.gif") no-repeat scroll 70px 0px;
			width : 220px;
			height : 35px;
			float: left;
			cursor: pointer;
		}
		.bannerEdge {
			width: 10px;
			height: 10px;
			background: ${url}("${this.cssFolderPath}/../../imgs/bannerEdge.png") no-repeat scroll left top transparent;
			float: left;
		}
		
		.header {
			height: 100%;
			border-top: 10px solid #4776A7;
			margin-left: 10px;
		}
		
		.header a {
			cursor:pointer;
		}
		
		.menuTab {
			padding-top: 10px;
			background:  #EFF9FF none repeat scroll 0 40px;
			font-size: 13px;
			float: left;
			height: 30px;
			color: black;
			cursor: pointer;
		}

		.menuTabLeftEdge {
			width: 10px;
			height: 40px;
			background: ${url}("${this.cssFolderPath}/../../imgs/menuTabEdges.png") no-repeat scroll left bottom #EFF9FF;
			float: left;
		}

		.menuTabRightEdge {
			width: 10px;
			height: 40px;
			background: ${url}("${this.cssFolderPath}/../../imgs/menuTabEdges.png") no-repeat scroll right bottom #EFF9FF;
			float: left;
			margin-right: 5px;
		}

		
		.menuTabSelected {
			color: white;
			padding-top: 10px;
			background: #4776A7 none repeat scroll 0 0;
			font-size: 13px;
			float: left;
			height: 30px;
			color: white;
			cursor: pointer;
		}
		
		.menuTabSelectedLeftEdge {
			width: 10px;
			height: 40px;
			background: ${url}("${this.cssFolderPath}/../../imgs/menuTabEdges.png") no-repeat scroll left bottom #4776A7;
			float: left;
		}

		.menuTabSelectedRightEdge {
			width: 10px;
			height: 40px;
			background: ${url}("${this.cssFolderPath}/../../imgs/menuTabEdges.png") no-repeat scroll right bottom #4776A7;
			float: left;
			margin-right: 5px;
		}

		.mainMenu {
			font-size: 13px;
			background: transparent;
			position: absolute;
			top: 10px;
			right: 10px;
		}
		 

	{/macro}
	
{/CSSTemplate}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/home/HomeCSS.tpl.css
//z9A2tcZCFD
{CSSTemplate {
	$classpath : "apps.guide.main.home.HomeCSS"
}}
{var url = "url" /}

{macro main()}
	.homeContent {
			margin-top: 30px;
			padding: 28px;
			border: 2px solid  #A5CA39;
			background: #efefef;
			position: relative;
			height: 560px;
			top : 0;
			left : 0;
			font-family: helvetica;
			font-size: 15px;
	}
	
	.screenshot {
		background: ${url}("${this.cssFolderPath}/../../imgs/checkmytrip.gif") no-repeat scroll 0 0 transparent;
		display: block;
		float: left;
		height: 158px;
		margin-right: 50px;
		width: 212px;
	}
	
	.tableOfContents {
			font-family: helvetica;
			font-size: 15px;
			margin-top: 30px;
	}

	.tableOfContents td {
		height: 50px;
	}

	.homeLinks {
			background: #4776A7;
			color: white;
			padding: 10px;
			margin-right: 20px;
			cursor: pointer;
			width: 150px;
			float: left;
	}
	
	
	
{/macro}

{/CSSTemplate}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/mainContent/MainContentCSS.tpl.css
//z9A2tcZCFD
{CSSTemplate {
	$classpath : "apps.guide.main.mainContent.MainContentCSS" 
}}

{macro main()}
		.actualContent {
			width : 600px;
			margin-left: 10px;
			float: left;
		}
		
		.sidebar {
			vertical-align: top;
			float: left;
			width: 250px;
		}

{/macro}

{/CSSTemplate}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/sample/SampleCSS.tpl.css
//z9A2tcZCFD
{CSSTemplate {
	$classpath : "apps.guide.main.sample.SampleCSS"
}}

	{macro main()}

		.contentTitle {
			font-size: 14px;
			background: #A5CA39;
			padding: 10px;
			font-weight: bolder;
			color: white;
		}

		.sourceContent {
			padding: 8px;
			border: 2px solid  #A5CA39;
			background: #fff;
			position: relative;
			top : 0;
			left : 0;
			height: 560px;
			overflow: auto;
		}

		.sourceContentLinks {
			margin: 5px 5px;
			position: absolute;
			right: 0;
			top: 0;
			background: #cccccc;
			padding: 10px;
			cursor: pointer;
		}

		.sampleTitle {
			font-size: 15px;
			padding: 10px 0;
			font-weight: bolder;
		}

		.sampleDisplayContent {
			margin-top: 10px;
			padding: 8px;
			border: 2px solid #A5CA39;
			background: #fefefe;
			min-height: 546px;
		}

		.sampleDescription {
			font-size: 12px;
			line-height: 18px;
		}

		.linkToSiblings {
			color: #4776A7;
			font-size: 13px;
			float: right;
		}

		.linkToSiblings span{
			cursor: pointer;
		}

		pre {
			margin : 0;
			font-size : 1.2em;
			font-family: consolas, courier, monospace;
		}

	{/macro}

{/CSSTemplate}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/samplecollection/SampleCollectionCSS.tpl.css
//z9A2tcZCFD
{CSSTemplate {
	$classpath : 'apps.guide.main.samplecollection.SampleCollectionCSS'
}}

	{macro main()}
		.sampleCollectionTitle {
			font-size: 15px;
			padding: 10px 0;
			font-weight: bolder;
		}

		.sampleCollectionDescription {
			font-size: 12px;
			line-height: 18px;
			padding-bottom: 20px;
		}

		.collectionDisplay {
			padding: 0px;
			width: 961px;
			margin: 0px;
			overflow-x:hidden;
		}

		.sampleShot {
			width: 290px;
			float: left;
			height: 110px;
			margin-right: 15px;
			margin-bottom: 15px;
			background: #eeeeee;
			border: 1px solid #DDDDDD;
			cursor: pointer;
			padding: 5px;
		}
		.sampleShotLast {
			width: 290px;
			float: left;
			height: 110px;
			margin-right: 0px;
			margin-bottom: 15px;
			background: #eeeeee;
			border: 1px solid #DDDDDD;
			cursor: pointer;
			padding: 5px;
		}

		.sampleShotName {
			padding-bottom: 10px;
			font-family: verdana;
		    font-size: 24px;
    		font-weight: normal;
		}

		.sampleShotName a {
			color: black;
		}

		.sampleShotDescription {
			padding-bottom: 10px;
		}

		.linkToSiblings {
			color: #4776A7;
			font-size: 13px;
			float: right;
		}

		.linkToSiblings span{
			cursor: pointer;
		}

	{/macro}

{/CSSTemplate}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/sidebar/SidebarCSS.tpl.css
//z9A2tcZCFD
{CSSTemplate {
	$classpath : 'apps.guide.main.sidebar.SidebarCSS'
}}

	{macro main()}

		.sidebarBlock {
			margin: 0 0 5px 10px;
		}

		.sidebarBlockHeader {
			background: none repeat scroll 0 0 #4776A7;
		    color: white;
		    cursor: pointer;
		    font-size: 13px;
		    padding: 10px;
		    width: 200px;
		}

		.sidebarBlockSubHeader {
			background: none repeat scroll 0 0 #9bb7d3;
		    color: white;
		    cursor: pointer;
		    font-size: 12px;
		    padding: 5px 0px 5px 10px;
		    width: 210px;
		}

		.sidebarBlockTitle {
		    width: 179px;
		    display: inline-block;
		}

		.sidebarBlockLink {
			background: none repeat scroll 0 0 #EFF9FF;
		    cursor: pointer;
		    font-size: 12px;
		    padding: 9px;
		    border: 1px solid #4776A7;
		    width: 200px;
		}

		.sidebarBlockIcon {
		}

		.sidebarBlockContent {
			background: none repeat scroll 0 0 #EFF9FF;
			padding: 0 10px 10px 10px;
			width: 200px;
			cursor: pointer;
			overflow: hidden;
		}

  		.sidebarBlockItem {
			padding-top: 5px;
		}

		.roleIcon {
			width: 10px;
			height: 10px;
			margin: 3px 2px 0 0;
			display: inline-block;
			vertical-align: middle;
		}

		#sidebarFilling {
			background: none repeat scroll 0 0 #EFF9FF;
			width: 220px;
			margin-left: 10px;
		}

	{/macro}

{/CSSTemplate}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/TextModuleController.tpl.txt
//z9A2tcZCFD
{TextTemplate {
   $classpath: "apps.guide.internals.createSample.steps.TextModuleController"
}}

{macro main()}

Aria.classDefinition(\{
	$classpath : "${data.mctrlPath}",
	$extends : "aria.templates.ModuleCtrl",
	$implements : ["${data.interfacePath}"],
	$constructor : function () \{
		this.$ModuleCtrl.constructor.call(this);
	\},
	$prototype : \{
		$publicInterfaceName : "${data.interfacePath}",
	\}
\});

{/macro}
{/TextTemplate}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/TextModuleControllerInterface.tpl.txt
//z9A2tcZCFD
{TextTemplate {
   $classpath: "apps.guide.internals.createSample.steps.TextModuleControllerInterface"
}}

{macro main()}

Aria.interfaceDefinition(\{
	$classpath : "${data.interfacePath}",
	$extends : "aria.templates.IModuleCtrl",
	$interface : \{
		
	\},
	$events : \{
		
	\}
\});

{/macro}
{/TextTemplate}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/TextSampleTest.tpl.txt
//z9A2tcZCFD
{TextTemplate {
   $classpath: "apps.guide.internals.createSample.steps.TextSampleTest"
}}

{macro main()}

Aria.classDefinition(\{
	$classpath : "${data.testPath}",
	$extends : 'aria.jsunit.TemplateTestCase',
	$constructor : function () \{
		this.$TemplateTestCase.constructor.call(this);
		
		this.setTestEnv(\{
			template : "${data.tplPath}"
		\});
	\},
	$prototype : \{
		runTemplateTest : function () \{
			this.notifyTemplateTestEnd();
		\}
	\}
\});


{/macro}
{/TextTemplate}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/TextTemplateFile.tpl.txt
//z9A2tcZCFD
{TextTemplate {
   $classpath: "apps.guide.internals.createSample.steps.TextTemplateFile"
}}

{macro main()}
\{Template \{
	$classpath : "${data.newClasspath}"
\}\}

	\{macro main()\}
		Something here
	\{/macro\}

\{/Template\}
{/macro}
{/TextTemplate}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/TextTplDataModel.tpl.txt
//z9A2tcZCFD
{TextTemplate {
   $classpath: "apps.guide.internals.createSample.steps.TextTplDataModel"
}}

{macro main()}
Aria.classDefinition(\{
	$classpath : "${data.newClasspath}",
	$constructor : function () \{\},
	$prototype : \{
		\/**
		 * The data object will be the datamodel of your sample
		 * @type Object
		 *\/
		data : \{\}
	\}
\});
{/macro}
{/TextTemplate}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/library/CommonMacros.tml
//z9A2tcZCFD
{Library {
	$classpath : "apps.guide.main.library.CommonMacros",
	$hasScript : false
}}

{macro menuTab(displayName, selected, clickCallback, restricted /* = false */)}
	{if restricted !== true}
		{if selected === true}
			<span class="menuTabSelectedLeftEdge"></span>
			<span class="menuTabSelected"
		{else/}
			<span class="menuTabLeftEdge"></span>
			<span class="menuTab"
		{/if}
		
				{if clickCallback} {on click clickCallback /}{/if}>${displayName}
			
			</span>
		{if selected === true}
			<span class="menuTabSelectedRightEdge"></span>
		{else/}
			<span class="menuTabRightEdge"></span>
		{/if}

	{/if}
{/macro}

{macro fileName(classPath, extension)}
	{if !extension}
		{var extension = ".js" /}
	{/if}
	<span class="fileName">${classPath.replace(/\./g, "/")}${extension}</span>
{/macro}

{macro contentTitle(text)}
	<h2 class="contentTitle">${text}</h2>
{/macro}
 
{macro sourceFile(content, style)}
	<div class="sourceContent" {if style}style="${style}"{/if}>
		<div class="sourceContentLinks">
			<div id="_copy_to_clipboard">copy to clipboard</div>
		</div>
		
		<pre class="prettyprint">${content|escape}</pre>
	</div>
{/macro}

{/Library}
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/Controller.js
//z9A2tcZCFD
Aria.classDefinition({$classpath:"apps.guide.internals.Controller",$extends:"aria.templates.ModuleCtrl",$implements:["apps.guide.internals.IController"],$dependencies:["apps.guide.internals.createSample.ConfBean","aria.resources.handlers.LCResourcesHandler","apps.guide.internals.createSample.validators.Category","aria.utils.validators.Mandatory","apps.guide.main.dataModel.SamplesUtils"],$constructor:function(){this.$ModuleCtrl.constructor.call(this)},$prototype:{$publicInterfaceName:"apps.guide.internals.IController",
init:function(a,b){var c={};aria.core.JsonValidator.normalize({json:c,beanName:"apps.guide.internals.createSample.ConfBean.NewSample"});this.setData({loadedTemplate:false,collections:[],newSampleConf:c,newSample:{},initialBean:{samples:apps.guide.main.dataModel.SamplesUtils.samplesList,tutorials:apps.guide.main.dataModel.SamplesUtils.tutorialsList}});this.buildCategories(apps.guide.main.dataModel.SamplesUtils.samplesPackages);aria.utils.Data.setValidator(this._data.newSampleConf,"category",new apps.guide.internals.createSample.validators.Category("",
this._data.validCategories));aria.utils.Data.setValidator(this._data.newSampleConf,"name",new aria.utils.validators.Mandatory);this.$callback(b)},navigateTo:function(){},buildCategories:function(a){var b=[],c={},d;for(d in a)if(a.hasOwnProperty(d)&&a[d].type=="SampleCollection"){b.push({label:d,code:d});c[d]=true}this._data.validCategories=c;this._data.categoryHandler=new aria.resources.handlers.LCResourcesHandler;this._data.categoryHandler.setSuggestions(b)},__steps:{form:"apps.guide.internals.createSample.Form",
stepAppDataModel:"apps.guide.internals.createSample.steps.AppDataModel",stepTemplate:"apps.guide.internals.createSample.steps.TemplateFile",stepTplDataModel:"apps.guide.internals.createSample.steps.TplDataModel",stepModuleCtrl:"apps.guide.internals.createSample.steps.ModuleController",stepSampleTest:"apps.guide.internals.createSample.steps.SampleTest",stepGoTo:"apps.guide.internals.createSample.steps.GoTo"},__hijack:function(a){this._data.loadedTemplate=this.__steps.stepAppDataModel;this._data.newSampleConf=
{name:"My New Sample",description:"My short description",audience:["customizer"],category:{label:"Samples.Widgets",code:"Samples.Widgets"},hasDataModel:false,hasModuleCtrl:false,mctrlRefpath:"myrefpath",hasTemplateTest:true};this.buildNewSampleConf(this._data.newSampleConf);this.$callback(a)},newSample:function(){this._data.loadedTemplate=this.__steps.form;this.$raiseEvent("templateChanged")},submitNewSample:function(){var a={};aria.utils.Data.validateModel(this._data.newSampleConf,a);this.json.setValue(this._data,
"errorMessages",a.listOfMessages);if(!a.nbrOfE){this.buildNewSampleConf(this._data.newSampleConf);this._data.loadedTemplate=this.__steps.stepAppDataModel;this.$raiseEvent("templateChanged")}},getCategoriesHandler:function(){return this._data.categoryHandler},buildNewSampleConf:function(a){var b=a.category.code,c=a.name.charAt(0).toUpperCase()+a.name.substring(1),d=c.replace(/ /g,"");b={name:c,description:a.description,location:{templateClasspath:a.templateClasspath},restrictedAudience:a.audience,
packageName:b+"."+d};if(a.hasModuleCtrl){b.location.moduleCtrlClasspath=a.moctrlClasspath;b.location.refpath=a.mctrlRefpath}else if(a.hasDataModel)b.location.dataClasspath=a.dataClasspath;if(!aria.core.JsonValidator.normalize({json:b,beanName:"apps.guide.main.dataModel.SamplesListBean.SampleItem"}))return this.$logError("Invalid configuration object for sample "+c);this._data.newSample=b},nextStep:function(){var a=this._data.loadedTemplate.split(".").pop();if(a=="AppDataModel")this._data.loadedTemplate=
this.__steps.stepTemplate;else if(a=="TemplateFile")this._data.loadedTemplate=this._data.newSampleConf.hasDataModel?this.__steps.stepTplDataModel:this._data.newSampleConf.hasModuleCtrl?this.__steps.stepModuleCtrl:this._data.newSampleConf.hasTemplateTest?this.__steps.stepSampleTest:this.__steps.stepGoTo;else if(a=="TplDataModel")this._data.loadedTemplate=this._data.newSampleConf.hasTemplateTest?this.__steps.stepSampleTest:this.__steps.stepGoTo;else if(a=="ModuleController")this._data.loadedTemplate=
this._data.newSampleConf.hasTemplateTest?this.__steps.stepSampleTest:this.__steps.stepGoTo;else if(a=="SampleTest")this._data.loadedTemplate=this.__steps.stepGoTo;this.$raiseEvent("templateChanged")},goToSample:function(){this.$raiseEvent({name:"goToSample",path:this._data.newSample.packageName,type:"spl"})}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/ConfBean.js
//z9A2tcZCFD
Aria.beanDefinitions({$package:"apps.guide.internals.createSample.ConfBean",$description:"Definition of the configuration object needed to create a new Sample.",$namespaces:{json:"aria.core.JsonTypes",sample:"apps.guide.main.dataModel.SamplesListBean"},$beans:{NewSample:{$type:"json:Object",$description:"Configuration option.",$mandatory:true,$properties:{category:{$type:"json:String",$description:"Category of the Sample.",$default:""},name:{$type:"json:String",$description:"Name of the Sample.",
$default:""},description:{$type:"json:String",$description:"Short description for the Sample.",$default:""},templateClasspath:{$type:"json:String",$description:"Classpath of the template.",$default:""},hasDataModel:{$type:"json:Boolean",$description:"This sample has a separate datamodel.",$default:false},dataClassPath:{$type:"json:String",$description:"Class path of the data.",$default:""},hasModuleCtrl:{$type:"json:Boolean",$description:"This sample has a separate module controller.",$default:false},
mctrlClasspath:{$type:"json:String",$description:"Classpath of the module controller.",$default:""},mctrlRefpath:{$type:"json:String",$description:"Reference path of the datamodel."},hasTemplateTest:{$type:"json:Boolean",$description:"Should this Sample be linked to a Template test.",$default:false},testClassPath:{$type:"json:String",$description:"Classpath of the test.",$default:""},audience:{$type:"sample:Audience",$default:[]}}}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/AppDataModelScript.js
//z9A2tcZCFD
Aria.tplScriptDefinition({$classpath:"apps.guide.internals.createSample.steps.AppDataModelScript",$prototype:{buildResultBean:function(){for(var b=this.data.newSampleConf.category.code.split("."),a=b[0]=="Samples"?this.data.initialBean.samples:this.data.initialBean.tutorials,c=0,d=b.length;c<d;c+=1){if(a.name!==b[c])return this.$logError("Working with the wrong category "+a.name);if(c<d-1){a=this.__getSubCategory(b[c+1],a);if(!a)return this.$logError("Unable to find the category "+this.data.newSampleConf.category)}}if(b[0]==
"Samples"){b=0;for(d=a.items.length;b<d&&a.items[b].name.toLowerCase()<this.data.newSample.name.toLowerCase();b++);a.items.splice(b,0,this.data.newSample)}else a.items.push(this.data.newSample)},__getSubCategory:function(b,a){for(var c=0,d=a.items.length;c<d;c+=1)if(a.items[c].name===b&&a.items[c].items)return a.items[c];return false}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/GeneralStepScript.js
//z9A2tcZCFD
Aria.tplScriptDefinition({$classpath:"apps.guide.internals.createSample.steps.GeneralStepScript",$dependencies:["ZeroClipboard"],$destructor:function(){ZeroClipboard.stop()},$prototype:{setAndGetContentFile:function(a){if(a)this._content=a;return this._content},$afterRefresh:function(){var a=this._content;ZeroClipboard.stop();ZeroClipboard.start(a)}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/steps/ModuleControllerScript.js
//z9A2tcZCFD
Aria.tplScriptDefinition({$classpath:"apps.guide.internals.createSample.steps.ModuleControllerScript",$prototype:{buildInterfaceFromMctrlPath:function(a){a=a.split(".");var b=a.pop();a.push("I"+b);return a.join(".")}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/createSample/validators/Category.js
//z9A2tcZCFD
Aria.classDefinition({$classpath:"apps.guide.internals.createSample.validators.Category",$extends:"aria.utils.validators.Validator",$constructor:function(a,b){this.$Validator.constructor.call(this,a);this.resources=b},$destructor:function(){this.$Validator.destructor.call(this)},$statics:{DEFAULT_LOCALIZED_MESSAGE:"This field is mandatory and should contain a valid Sample Category."},$prototype:{validate:function(a){if(a&&this.resources[a.code]===true)return this._validationSucceeded();return this._validationFailed()}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/IController.js
//z9A2tcZCFD
Aria.interfaceDefinition({$classpath:"apps.guide.internals.IController",$extends:"aria.templates.IModuleCtrl",$interface:{newSample:"Function",submitNewSample:"Function",getCategoriesHandler:"Function",nextStep:"Function",goToSample:"Function",navigateTo:"Function"},$events:{templateChanged:"Raised when the loaded template changes.",goToSample:{description:"Call the navigation function on the parent module controller.",properties:{type:"Type of navigation.",path:"Path of the destination."}}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/internals/MainScript.js
//z9A2tcZCFD
Aria.tplScriptDefinition({$classpath:"apps.guide.internals.MainScript",$prototype:{onModuleEvent:function(a){a.name==="templateChanged"&&this.$refresh()}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/AppModule.js
//z9A2tcZCFD
Aria.classDefinition({$classpath:"apps.guide.main.AppModule",$extends:"aria.templates.ModuleCtrl",$implements:["apps.guide.main.IAppModule"],$dependencies:["apps.guide.main.dataModel.SamplesUtils","aria.utils.Type","aria.utils.Array","aria.utils.HashManager","aria.touch.Event","aria.utils.ScriptLoader","aria.utils.QueryString"],$constructor:function(){this.$ModuleCtrl.constructor.call(this);this.__currentHash=""},$destructor:function(){this._hashManagerCallback&&aria.utils.HashManager.removeCallback(this._hashManagerCallback);
this.$ModuleCtrl.$destructor.call(this)},$prototype:{$publicInterfaceName:"apps.guide.main.IAppModule",init:function(a,b){if(aria.touch.Event.touch){var c=aria.utils.QueryString.getKeyValue("weinre");c&&aria.utils.ScriptLoader.load(["http://debug.phonegap.com/target/target-script-min.js#guid:"+c])}this.loadSubModules([{refpath:"sampleNavigation",classpath:"apps.guide.main.navigationModules.SampleNavigation"},{refpath:"documentationNavigation",classpath:"apps.guide.main.navigationModules.DocumentationNavigation"}],
{fn:"_completeInit",scope:this,args:b})},_completeInit:function(a,b){this._hashManagerCallback={fn:function(d){d=this._interpretHash(d);this.navigate(null,{type:d.type,path:d.path})},scope:this};aria.utils.HashManager.addCallback(this._hashManagerCallback);this.setData({currentState:{}});var c=this._interpretHash();this.navigate(null,{type:c.type,path:c.path});b&&this.$callback(b)},__navigateMap:{spl:{subModule:"sampleNavigation",method:"navigateTo"},doc:{subModule:"documentationNavigation",method:"navigateTo"},
"int":{method:"__navigateToInternals"},APIdocs:{method:"__navigateToAPIdocs"},Home:{method:"__navigateToHome"}},navigate:function(a,b){var c=b.type,d=b.path||"";if(c=="spl")this._data.currentState={contentType:apps.guide.main.dataModel.SamplesUtils.getSampleType(d),path:d};else if(c=="doc")this._data.currentState={contentType:"Documentation",path:d};if(this.__currentHash!==c+"="+d){d=this.__navigateMap[c];var e;e=d.subModule?this[d.subModule][d.method]:this[d.method];if(aria.utils.Type.isFunction(e))e.call(d.subModule?
this[d.subModule]:this,b);else{this.$logError("No navigate action defined for type: "+c);this.__navigateToHome()}}},__navigateToInternals:function(a){a=a.path||"Internals";this._data.currentState.contentType="Internals";this._data.currentState.path=a;this._changeLocationRef("int="+a);this.internals?this.__onload_InternalsController(null,a):this.loadSubModules([{refpath:"internals",classpath:"apps.guide.internals.Controller"}],{fn:"__onload_InternalsController",args:a})},__onload_InternalsController:function(a,
b){this.internals.navigateTo(b);this.$raiseEvent("locationChanged")},__navigateToAPIdocs:function(a){a=a.path;var b=/(^.*aria\/guide[^\/]*\/)/.exec(location.href);b||(b=/(^.*aria\-templates[^\/]*\/)/.exec(location.href));a?window.open(b[0]+"apps/apidocs/#"+a):window.open(b[0]+"apps/apidocs/")},__navigateToHome:function(){this._data.currentState.contentType="Home";this._data.currentState.path="Home";this._changeLocationRef("");this.$raiseEvent("locationChanged")},_changeLocationRef:function(a){aria.utils.HashManager.setHash(a);
this.__currentHash=a},onSubModuleEvent:function(a){if(a.name=="selectedItemChanged")this.navigate(null,{type:a.type,path:a.path,sourceFileType:a.sourceFileType});else if(a.name=="goToSample")this.navigate(null,{type:a.type,path:a.path});else if(a.name=="navigationComplete"){this._changeLocationRef(a.newLocationRef);this.$raiseEvent("locationChanged")}},_interpretHash:function(a){a=a?a:aria.utils.HashManager.getHashObject();var b,c;if(a.tpl||a.spl){b="spl";c=a.tpl||a.spl}if(a.doc){b="doc";c=a.doc;
if(a.hash)c=c+"#"+a.hash}if(a["int"]){b="int";c=a["int"]}if(!aria.utils.Array.contains(["int","doc","spl"],b))c=b="Home";return{type:b,path:c}},setSidebarFillingHeight:function(){this.sampleNavigation.sidebar.setSidebarFillingHeight()}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/breadcrumbs/BreadcrumbsTemplateScript.js
//z9A2tcZCFD
Aria.tplScriptDefinition({$classpath:"apps.guide.main.breadcrumbs.BreadcrumbsTemplateScript",$prototype:{getCrumbName:function(a){if(aria.utils.Type.isString(a))return a;return a.name},handleCrumbClick:function(a,b){aria.utils.Type.isString(b)||this.moduleCtrl.select(null,{type:b.type,path:b.path})}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/dataModel/DataBean.js
//z9A2tcZCFD
Aria.beanDefinitions({$package:"apps.guide.main.dataModel.DataBean",$description:"Definition of the complete structure for the datamodel.",$namespaces:{json:"aria.core.JsonTypes",samples:"apps.guide.main.dataModel.SamplesListBean",sidebar:"apps.guide.main.dataModel.SidebarBean"},$beans:{ApplicationState:{$type:"json:Object",$description:"Describe the current state of the application",$properties:{contentType:{$type:"json:Enum",$enumValues:["Home","Sample","SampleCollection","Documentation"],$description:"It is useful to decide which submodule or template to load.",
$default:"Home"},path:{$type:"json:String",$description:"Path of the resource to display.",$default:"Home"}}},SampleState:{$type:"json:Object",$description:"Describe the data model of the SampleNavigation module controller.",$properties:{displayType:{$type:"json:Enum",$enumValues:["Output","Source","Data"],$description:"The type of sample that should be displayed.",$default:"Output"},data:{$type:"json:MultiTypes",$description:"Portion of the samples data model that is accessible from a Template.",
$contentTypes:[{$type:"samples:SampleCollection",$description:"A collection of samples."},{$type:"samples:SampleItem",$description:"A single sample."}]},selectedItem:{$type:"json:String",$description:"Selected item. It's shared among all the application."},sourceFileType:{$type:"json:Enum",$enumValues:["JS","TPL","RES","CSS","TML","TXT"],$description:"Type of the source file to be displayed. Used when the selectedItem is a source file."},sampleData:{$type:"json:Object",$description:"Data model of the sample."},
breadcrumbs:{$type:"json:Array",$description:"Breadcrumb for the current selected sample item or collection. Item 0 is the top level.",$contentType:{$type:"json:MultiTypes",$description:"Single crumb.",$contentTypes:[{$type:"json:String",$description:"Name of a crumb. Doesn't trigger navigation"},{$type:"samples:NavigationCrumb",$description:"Crumb that triggers navigation."}]}}}},DocumentationState:{$type:"json:Object",$description:"Information about a documentation page.",$properties:{pageContent:{$type:"json:String",
$description:"Body of the HTML page to be displayed."},pageHash:{$type:"json:String",$description:"Id of the HTML Element to scroll to after the documentation template is refreshed."},selectedItem:{$type:"json:String",$description:"Selected item. It's shared among all the application."}}}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/dataModel/SamplesList.js
//z9A2tcZCFD
Aria.classDefinition({$classpath:"apps.guide.main.dataModel.SamplesList",$singleton:true,$constructor:function(){},$prototype:{samples:{name:"Samples",description:"Whole list of samples",items:[{name:"Widgets",description:"Reusable user interface components that handle the interaction between the user and the data model. Input fields, calendar, buttons and more.<br />Read more on <a href='http://ariatemplates.com/usermanual/Widgets'>ariatemplates.com</a>",items:[{name:"Aria",description:"Aria Templates Widgets Collection. A comprehensive collection of widgets with a rich set of features. This is the default widget library used by {@aria:WidgetName /}",
items:[{name:"AutoComplete",description:"A textfield with autocompletion features.",items:[{name:"Basic usage",description:"A sample showing a basic usage of the autoComplete.",location:{templateClasspath:"samples.widgets.form.templates.AutoCompleteSample"}},{name:"Spell check underline",description:"A sample showing how to use the spell check underline state of the auto-complete.",preview:"samples.widgets.form.templates.spellCheckAutoComplete.SpellCheckPreview",location:{templateClasspath:"samples.widgets.form.templates.spellCheckAutoComplete.SpellCheckSample"},
extra:{sourceFiles:{items:[{value:"samples.widgets.form.templates.spellCheckAutoComplete.SpellCheckAIRList",type:"TPL"}]}}}]},{name:"Button",description:"A normal push button",location:{templateClasspath:"samples.widgets.action.templates.TemplateButton"}},{name:"Calendar",description:"A calendar to select dates",location:{templateClasspath:"samples.widgets.form.templates.TemplateCalendar"},extra:{sourceFiles:{items:[{value:"samples.widgets.form.templates.CustomizedCalendar",type:"TPL"}]}}},{name:"Checkbox",
description:"A simple checkbox",location:{templateClasspath:"samples.widgets.form.templates.TemplateCheckBox",dataClasspath:"samples.widgets.form.CheckBoxData"}},{name:"Datefield",description:"A textfield to enter dates",location:{templateClasspath:"samples.widgets.form.templates.TemplateDateField"}},{name:"DatePicker",description:"A control to select dates, either by typing them or by selecting them in a calendar.",items:[{name:"DatePicker normal usage",description:"samples which show basic usage of Datepicker",
location:{templateClasspath:"samples.widgets.form.templates.TemplateDatePicker"}},{name:"DatePicker with reference",description:"samples showing usage of Datepicker with a reference date",location:{templateClasspath:"samples.widgets.form.templates.TemplateDatePickerReference"}}]},{name:"Dialog",description:"",items:[{name:"Basic",description:"A dialog shown in front of other content",location:{templateClasspath:"samples.widgets.container.templates.TemplateDialog",dataClasspath:"samples.widgets.container.DialogData"}},
{name:"Movable",description:"Moving a dialog",location:{templateClasspath:"samples.widgets.container.templates.TemplateMovableDialog"}},{name:"Resizable",description:"Resizing a dialog",location:{templateClasspath:"samples.widgets.container.templates.TemplateResizableDialog"}}]},{name:"Div",description:"A container for any content",location:{templateClasspath:"samples.widgets.container.templates.TemplateDiv"}},{name:"ErrorList",description:"A widget to display errors or other messages.",location:{templateClasspath:"samples.widgets.form.templates.errorManagement.TemplateErrorList",
moduleCtrlClasspath:"samples.widgets.form.templates.errorManagement.TemplateErrorListController",refpath:"errorListWidget"},extra:{sourceFiles:{items:[{value:"samples.widgets.form.templates.errorManagement.CustomizedErrorList",type:"TPL"}]}}},{name:"Splitter",description:"Special container widget to split macros in to panels",location:{templateClasspath:"samples.widgets.container.splitter.TemplateSplitter"}},{name:"Fieldset",description:"Container widget to group together a set of fields.",location:{templateClasspath:"samples.widgets.container.templates.TemplateFieldset"}},
{name:"Gauge",description:"A textfield to enter Numbers",location:{templateClasspath:"samples.widgets.form.templates.TemplateGauge",dataClasspath:"samples.widgets.form.GaugeData"}},{name:"Icon",description:"Icon library",location:{templateClasspath:"samples.widgets.templates.TemplateIcon"}},{name:"List",description:"A simple list of selectable items",location:{templateClasspath:"samples.widgets.form.templates.TemplateList",dataClasspath:"samples.widgets.form.ListData"}},{name:"MultiSelect",description:"A control to create a list of checkbox options",
location:{templateClasspath:"samples.widgets.form.templates.TemplateMultiSelect"}},{name:"Numberfield",description:"A textfield to enter Numbers",location:{templateClasspath:"samples.widgets.form.templates.TemplateNumberField"}},{name:"Select",description:"A dropdown list of selectable items, similar to the &lt;select&gt; html component",location:{templateClasspath:"samples.widgets.form.templates.TemplateSelect",dataClasspath:"samples.widgets.form.ListData"}},{name:"SelectBox",description:"A dropdown list of selectable items, with type ahead feature.",
location:{templateClasspath:"samples.widgets.form.templates.TemplateSelectBox",dataClasspath:"samples.widgets.form.ListData"}},{name:"SortIndicator",description:"SortIndicator",location:{templateClasspath:"samples.widgets.action.templates.SortShopperTemplate",dataClasspath:"samples.widgets.action.SortData"},extra:{relatedSamples:{items:[{value:"Samples.Templates.Views"}]}}},{name:"Tab",description:"Tab",location:{templateClasspath:"samples.widgets.container.templates.TemplateTab",dataClasspath:"samples.widgets.container.TabData"}},
{name:"Text",description:"Text",location:{templateClasspath:"samples.widgets.templates.TemplateText",dataClasspath:"samples.widgets.container.TabData"}},{name:"Textfield",description:"A form field to enter text",location:{templateClasspath:"samples.widgets.form.templates.TemplateTextField"}},{name:"Textarea",description:"A form field to enter text",location:{templateClasspath:"samples.widgets.form.templates.TemplateTextarea"}},{name:"Timefield",description:"A textfield to enter times",location:{templateClasspath:"samples.widgets.form.templates.TemplateTimeField"}},
{name:"Tooltip",description:"A standard tooltip",location:{templateClasspath:"samples.widgets.container.templates.TemplateTooltip"}}]},{name:"HTML",description:"HTML Widgets Library. Simple library in terms of markup, but still providing easy bindings and event listeners. You can use it as the building blocks for your html5 or mobile application.",items:[{name:"TextInput",description:"A plain html text input with event listeners and bindings.",location:{templateClasspath:"samples.widgetLibs.html.textinput.BaseTextInputTag"}},
{name:"Template include",description:"Simple template include widget",location:{templateClasspath:"samples.widgetLibs.html.template.SimpleTemplate",testClasspath:"test.templateTests.tests.html.template.TemplateSampleTestCase",moduleCtrlClasspath:"samples.widgetLibs.html.template.SimpleTemplateController",refpath:"template"},extra:{sourceFiles:{items:[{value:"samples.widgetLibs.html.template.SimpleSubTemplate",type:"TPL"},{value:"samples.widgetLibs.html.template.SimpleSubTemplateScript",type:"js"},
{value:"samples.widgetLibs.html.template.SimpleChildSubTemplate",type:"TPL"}]}}}]},{name:"Embed",description:"Embed widget library gives you the complete freedom to manage the lifecycle of your widgets that are thus able to survive through refreshes of the template.",items:[{name:"Embed Element",description:"Creates special type of DOM container to include standard HTML/JS/CSS ",location:{templateClasspath:"samples.features.embed.EmbedSample",testClasspath:"test.sampleTests.samples.features.embed.embedSample.EmbedSampleTestCase",
moduleCtrlClasspath:"samples.features.embed.EmbedSampleController",refpath:"element"}},{name:"Maps",description:"Map widget",items:[{name:"Simple Map",description:"Creates a simple map",location:{templateClasspath:"samples.widgetLibs.embed.map.MapSample"}},{name:"Customized Map",description:"Creates a customized map",location:{templateClasspath:"samples.widgetLibs.embed.customMap.CustomMap"},extra:{sourceFiles:{items:[{value:"samples.widgetLibs.embed.customMap.provider.CustomProvider",type:"JS"},
{value:"samples.widgetLibs.embed.customMap.provider.Map",type:"JS"},{value:"samples.widgetLibs.embed.customMap.provider.Marker",type:"JS"},{value:"samples.widgetLibs.embed.customMap.provider.MarkerGroup",type:"JS"},{value:"samples.widgetLibs.embed.customMap.provider.MapBeans",type:"JS"}]}}}]},{name:"Placeholder",description:"Placeholder widget to include configurable content",location:{templateClasspath:"samples.widgetLibs.embed.placeholder.PlaceholderSample",testClasspath:"test.sampleTests.samples.widgetLibs.embed.placeholder.PlaceholderSampleTestCase",
moduleCtrlClasspath:"samples.widgetLibs.embed.placeholder.PlaceholderSampleController",refpath:"placeholder"}}]},{name:"Custom",description:"More samples on how to reuse base classes and other widget libraries to create you own set of widgets.",items:[{name:"Slider",description:"A simple slider widget extending BaseWidget.",location:{templateClasspath:"samples.widgetLibs.slider.DemoTemplate",testClasspath:"test.sampleTests.samples.widgetLibs.SliderDemoTestCase"},preview:"samples.widgetLibs.slider.Preview",
extra:{sourceFiles:{items:[{value:"samples.widgetLibs.SampleWidgetLib",type:"JS"}]}}},{name:"AutoComplete - HTML Widget",description:"AutoComplete widget based on TextInput widget from HtmlLibrary.",location:{templateClasspath:"samples.widgetLibs.html.autocomplete.InputWidget"},preview:"samples.widgetLibs.html.autocomplete.PreviewWidget"},{name:"AutoComplete - Markup only",description:"AutoComplete widget based on simple html markup.",location:{templateClasspath:"samples.widgetLibs.html.autocomplete.PlainInput"},
preview:"samples.widgetLibs.html.autocomplete.PreviewPlain"},{name:"Image Gallery",description:"Image Gallery Widget based on aria.html.Element",location:{templateClasspath:"samples.widgetLibs.gallery.ImageGallery",dataClasspath:"samples.widgetLibs.gallery.DataModel"}}]},{name:"Touch",description:"Touch Widgets Library, containing all widgets supporting touch events.  Where touch events are not supported by the device then (legacy) mouse events will be used by the widgets.",items:[{name:"Slider",
description:"A Touch Slider widget, uses the Swipe Touch gesture.",location:{templateClasspath:"samples.widgets.touch.templates.Slider"}}]}]},{name:"Templates",description:"Details on the Templating engine for HTML, CSS and text. How to create a template, list of statements, inheritance, macro libraries and more.",items:[{name:"CDATA",description:"samples.templates.cdata.templates.CDATATemplate",location:{templateClasspath:"samples.templates.cdata.templates.CDATATemplate"}},{name:"CSS Templates",
description:"CSS at Template level",location:{templateClasspath:"samples.templates.csstemplate.SampleTemplate"},extra:{relatedSamples:{items:[{value:"Tutorials.CSS Templates"}]},relatedDocs:{items:[{value:"Aria_Templates_-_CSS_Template"}]}}},{name:"Modifiers",description:"Simply modify data to display in a template",location:{templateClasspath:"samples.templates.modifiers.templates.ModifiersTemplate"}},{name:"HTML Template",description:"Basic HTML Template",location:{templateClasspath:"samples.templates.htmltemplate.SimpleTemplate",
dataClasspath:"samples.templates.htmltemplate.TemplateData"},extra:{relatedSamples:{items:[{value:"Tutorials.HTML Templates"}]},relatedDocs:{items:[{value:"Aria_Templates_principles"},{value:"Aria_Templates_statements"}]}}},{name:"Repeater",description:"Repeater example.",location:{templateClasspath:"tutorials.repeater.step1.RepeaterStepOne"}},{name:"Simple HTML",description:"Simple HTML form elements",location:{templateClasspath:"samples.widgets.action.templates.SimpleHTMLTemplate"},restrictedAudience:["appcustomizer"]},
{name:"Template Scripts",description:"Creating custom scripts with templates",items:[{name:"Step 1",description:"Creating custom scripts with templates, step 1",location:{templateClasspath:"tutorials.templatescripts.step1.SampleTemplate"}}]},{name:"Text templates",description:"Text templates examples.",location:{templateClasspath:"tutorials.texttemplates.step1.MainTemplate"},restrictedAudience:["appcustomizer"]},{name:"Views",description:"Sorting, filtering and paging data",preview:"samples.templates.views.Preview",
location:{templateClasspath:"samples.templates.views.templates.ViewsTemplate",dataClasspath:"samples.templates.views.ViewData",testClasspath:"test.sampleTests.samples.templates.views.ViewsTestCase"},extra:{sourceFiles:{items:[{value:"samples.templates.views.templates.BasicTemplate",type:"TPL"},{value:"samples.templates.views.templates.FilteringTemplate",type:"TPL"},{value:"samples.templates.views.templates.FilteringTemplateScript",type:"JS"},{value:"samples.templates.views.templates.SortingTemplate",
type:"TPL"},{value:"samples.templates.views.templates.SortingTemplateScript",type:"JS"},{value:"samples.templates.views.templates.PagingTemplate",type:"TPL"},{value:"samples.templates.views.templates.PagingTemplateScript",type:"JS"},{value:"samples.templates.views.templates.HotelLibrary",type:"TML"}]},relatedSamples:{items:[{value:"Tutorials.Views"}]}}}]},{name:"Features",description:"General features of Aria Templates that are used by almost any application.",items:[{name:"Error Management",description:"Examples of error management for developers to get started with aria templates development.",
items:[{name:"Validator Events",description:"A sample demonstrating single and multiple validators triggered onblur, and onsubmit.",location:{templateClasspath:"samples.features.errorManagement.TemplateValidatorEvents",moduleCtrlClasspath:"samples.features.errorManagement.TemplateValidatorEventsController",refpath:"validatorEvents"}},{name:"Validator Filters",description:"A sample demonstrating how validators can be grouped and validation can be filtered on the groupings.",location:{templateClasspath:"samples.features.errorManagement.TemplateValidatorFilters",
moduleCtrlClasspath:"samples.features.errorManagement.TemplateValidatorFiltersController",refpath:"validatorFilters"}},{name:"Scrollable Error Tips",description:"A sample demonstrating how the error tips are positioned and are scrollable.",location:{templateClasspath:"samples.features.errorManagement.TemplateScrollableErrorTips"}}],restrictedAudience:["appcustomizer"]},{name:"Refresh",description:"Refreshing a whole template or individual parts of it",location:{templateClasspath:"samples.templates.refresh.templates.TemplateRefresh"},
extra:{relatedDocs:{items:[{value:"Aria_Templates_Refresh"}]},relatedSamples:{items:[{value:"Tutorials.Refresh"}]}}},{name:"Print",description:"",location:{templateClasspath:"samples.printpage.PrintTestPage"},restrictedAudience:["appcustomizer"]},{name:"Widgets prefill",description:"Prefill state for TextInput-based widgets",items:[{name:"Basic usage",description:"Presentation of the behaviour of the prefill for all TextInput-based widgets in different scenarios",location:{templateClasspath:"samples.features.textInputPrefill.prefillSample.PrefillSample",
testClasspath:"test.sampleTests.samples.features.textInputPrefill.prefillSample.PrefillSampleTestCase"},extra:{relatedSamples:{items:[{value:"Samples.Widgets"}]},relatedDocs:{items:[{value:"Aria_Templates_-_Prefill_state_for_TextInput-based_widgets"}]}}},{name:"Usecase",description:"Implementation of a realistic usecase",location:{templateClasspath:"samples.features.textInputPrefill.prefillUsecase.PrefillSample"},extra:{relatedSamples:{items:[{value:"Samples.Widgets"}]},relatedDocs:{items:[{value:"Aria_Templates_-_Prefill_state_for_TextInput-based_widgets"}]}}}],
extra:{relatedSamples:{items:[{value:"Samples.Widgets"}]},relatedDocs:{items:[{value:"Aria_Templates_-_Prefill_state_for_TextInput-based_widgets"}]}}},{name:"Widgets AutoSelect",description:"AutoSelect for TextInput-based widgets",items:[{name:"Basic usage",description:"Presentation of the behaviour of the AutoSelect for all TextInput-based widgets in different scenarios",location:{templateClasspath:"samples.features.autoselect.AutoSelect"},extra:{relatedSamples:{items:[{value:"Samples.Widgets"}]}}}],
extra:{relatedSamples:{items:[{value:"Samples.Widgets"}]},relatedDocs:{items:[{value:"Aria_Templates_-_Prefill_state_for_TextInput-based_widgets"}]}}}]},{name:"Utilities",description:"Less common features.",items:[{name:"Auto resize",description:"Auto resize of content when browser is resized",location:{templateClasspath:"samples.templates.autoresize.templates.AutoresizeTemplate"}},{name:"DOM Events",description:"DOM events",items:[{name:"Simple Syntax",description:"Mouse event examples using the simple syntax",
location:{templateClasspath:"samples.templates.domevents.templates.DomEventsTemplate"}},{name:"Mouse Events",description:"A simple box selection mechanism using {on click}",location:{templateClasspath:"samples.templates.domevents.mouseevents.templates.MouseEvents"},extra:{relatedDocs:{items:[{value:"Aria_Templates_DOM_Events"}]}},preview:"samples.templates.domevents.mouseevents.templates.MouseEventsPreview"},{name:"Keyboard Events",description:"Box selection using keyboard events",allowsPreviousNext:true,
items:[{name:"Step 1",description:"Use on keydown handlers to implement a basic keyboard navigation.",location:{templateClasspath:"samples.templates.domevents.keyboardevents.templates.step1.KeyboardEvents"},extra:{relatedDocs:{items:[{value:"Aria_Templates_DOM_Events"}]}},preview:"samples.templates.domevents.keyboardevents.templates.step1.KeyboardEventsPreview"},{name:"Step 2",description:"Listen to change events to store the state of inputs.",location:{templateClasspath:"samples.templates.domevents.keyboardevents.templates.step2.KeyboardEvents"},
extra:{relatedDocs:{items:[{value:"Aria_Templates_DOM_Events"}]}},preview:"samples.templates.domevents.keyboardevents.templates.step2.KeyboardEventsPreview"},{name:"Step 3",description:"Listen to focus events to mix a custom navigation with the default TAB navigation.",location:{templateClasspath:"samples.templates.domevents.keyboardevents.templates.step3.KeyboardEvents"},extra:{relatedDocs:{items:[{value:"Aria_Templates_DOM_Events"}]}},preview:"samples.templates.domevents.keyboardevents.templates.step3.KeyboardEventsPreview"},
{name:"Step 4",description:"Use Event Delegation and Expandos to improve template performances.",location:{templateClasspath:"samples.templates.domevents.keyboardevents.templates.step4.KeyboardEvents"},extra:{relatedDocs:{items:[{value:"Aria_Templates_DOM_Events"}]},relatedApidocs:{items:[{value:"aria.templates.DomElementWrapper:getExpando"}]}},preview:"samples.templates.domevents.keyboardevents.templates.step4.KeyboardEventsPreview"},{name:"Step 5",description:"Use the DOM Element Wrapper API to avoid unnecessary refresh.",
location:{templateClasspath:"samples.templates.domevents.keyboardevents.templates.step5.KeyboardEvents"},extra:{relatedDocs:{items:[{value:"Aria_Templates_DOM_Events"}]},relatedApidocs:{items:[{value:"aria.templates.DomElementWrapper"}]}},preview:"samples.templates.domevents.keyboardevents.templates.step5.KeyboardEventsPreview"}]},{name:"Event singleton",description:"Use the aria.utils.Event singleton to listen to events outside of a template",location:{templateClasspath:"samples.templates.domevents.utilsevent.templates.UtilsEvents"},
extra:{relatedDocs:{items:[{value:"Aria_Templates_DOM_Events"}]}},preview:"samples.templates.domevents.utilsevent.templates.UtilsEventsPreview"}]},{name:"Filter Delays",description:"Time delays using filters.",location:{templateClasspath:"samples.utilities.filters.delay.TemplateFilterDelay",moduleCtrlClasspath:"samples.utilities.filters.delay.TemplateFilterDelayController",refpath:"filterDelays"},extra:{sourceFiles:{items:[{value:"samples.utilities.filters.delay.SampleDelayFilter",type:"JS"}]}},restrictedAudience:["appcustomizer"]},
{name:"Filter redirections",description:"Redirecting requests using filters.",location:{templateClasspath:"samples.utilities.filters.redirect.TemplateFilterRedirect",moduleCtrlClasspath:"samples.utilities.filters.redirect.TemplateFilterRedirectController",refpath:"filterRedirect"},extra:{sourceFiles:{items:[{value:"samples.utilities.filters.redirect.SampleRedirectFilter",type:"JS"}]}},restrictedAudience:["appcustomizer"]},{name:"Focus handling",description:"Handling the focus inside templates",location:{templateClasspath:"samples.templates.focushandling.MainTemplate"},
extra:{relatedDocs:{items:[{value:"AriaTemplates_focus_handling"}]}}},{name:"JSON-P",description:"Make JSON-P requests to a server.",location:{templateClasspath:"samples.utilities.jsonp.JsonP",dataClasspath:"samples.utilities.jsonp.Data"},preview:"samples.utilities.jsonp.Preview"},{name:"Keyboard shortcuts",description:"KeyMap allows you to define keyboard shortcuts, at section and application level.",location:{templateClasspath:"samples.templates.keynav.KeyMap"}},{name:"Localization",description:"Localization of resources",
items:[{name:"Application",description:"Localization of application resources",location:{templateClasspath:"samples.templates.localization.templates.LocalizedTemplate",moduleCtrlClasspath:"samples.templates.localization.templates.LocalizedModule",refpath:"localization"}},{name:"Template",description:"Localization of resources.",location:{templateClasspath:"tutorials.localization.step1.LocalizedTemplate"}}],restrictedAudience:["appcustomizer"]},{name:"Processing indicator",description:"",location:{templateClasspath:"samples.utilities.loadingoverlay.LoadingOverlayTemplate"}},
{name:"Scroll control",description:"Handling the scroll positions of sections and DomElementWrapper.",location:{templateClasspath:"samples.templates.scrollcontrol.exampletwo.ScrollControlTwo"}},{name:"Table Navigation",description:"Table navigation provides advanced keyboard navigation in the HTML table.",location:{templateClasspath:"samples.templates.keynav.KeyboardNavigation"}},{name:"Visual focus",description:"This page allows to navigate the whole demo site with a visual focus",location:{templateClasspath:"samples.utilities.visualfocus.MainTemplate"}},
{name:"XDR",description:"Cross domain requests.",location:{templateClasspath:"samples.xdr.test.TemplateXdr"},restrictedAudience:["appcustomizer"]},{name:"File Upload",description:"Simulate a form submission asyncronously using the IFrame IO transport.  Useful when uploading files without refreshing the whole page.",location:{templateClasspath:"samples.utilities.fileupload.FileUpload"}},{name:"Drag and Drop",description:"Basic drag and drop capability. It allows to move an element on the screen.",
location:{templateClasspath:"samples.utilities.dragdrop.DragDrop"}},{name:"Touch and Gesture Events",description:"Aria Touch and Gesture events for touch capable devices.",items:[{name:"TouchStart",description:"This sample demonstrates TouchStart using the touch event coordinates.",location:{templateClasspath:"samples.utilities.touchevents.TouchStart"}},{name:"TouchMove",description:"This sample demonstrates TouchMove using...",location:{templateClasspath:"samples.utilities.touchevents.TouchMove"}},
{name:"TouchEnd",description:"This sample demonstrates TouchEnd using the touch event coordinates.",location:{templateClasspath:"samples.utilities.touchevents.TouchEnd"}},{name:"Tap",description:"This sample demonstrates Tap using a tab board to record the number of taps within a time limit.",location:{templateClasspath:"samples.utilities.touchevents.Tap"}},{name:"Swipe",description:"Demonstration of the Swipe gesture.",location:{templateClasspath:"samples.utilities.touchevents.Swipe"}}]},{name:"Persistence - Storage",
description:"Store informartion in localStorage for persitent data.",preview:"samples.utilities.storage.Preview",location:{templateClasspath:"samples.utilities.storage.Persist"}}]},{name:"Developer Tools",description:"Tools for improving the developer's capabilities.",items:[{name:"Custom mode",description:"A mode in which contextual menus for customization are available",location:{templateClasspath:"samples.custommode.templates.CustomMode"}},{name:"Files generator",description:"This page shows how to use the files generator helper class to generate skeleton of AT resources",
location:{templateClasspath:"samples.ext.filesgenerator.MainTemplate"}},{name:"CSS Stress Test",description:"This page describes how to use the CSS Stress Test tools in order to identify the slowest CSS Selectors in the page.",location:{templateClasspath:"samples.ext.stresstest.MainTemplate",dataClasspath:"samples.ext.stresstest.DataModel"}}],restrictedAudience:["appcustomizer"]},{name:"Customization",description:"Features that are related to customization.",items:[{name:"Customization",description:"This page shows how to use the customization descriptor to customize templates and to add custom sub-modules.",
location:{templateClasspath:"samples.customization.templates.Customization"}},{name:"Flow Customization",description:"This page shows how to use the customization descriptor to customize templates, add custom sub-modules and add custom flows.",location:{templateClasspath:"samples.customization.templates.FlowCustomization"}},{name:"Template reload",description:"This page shows how to reload a customized template and what happens to its dependencies.",location:{templateClasspath:"samples.customization.templates.reload.Controller",
testClasspath:"test.sampleTests.customization.TemplateReload"}}],restrictedAudience:["appcustomizer"]}]},tutorials:{name:"Tutorials",description:"Step by step introduction to the main features of Aria Templates.",items:[{name:"HTML Templates",description:"Basic ingredient for an Aria Templates application",allowsPreviousNext:true,items:[{name:"Step 1",description:"Hello World",location:{templateClasspath:"tutorials.basictemplate.step1.TemplateStep1"},extra:{relatedDocs:{items:[{value:"Aria_Templates_principles"},
{value:"Aria_Templates_Statements_Tutorials"}]}}},{name:"Step 2",description:"Providing some data to a template.",location:{templateClasspath:"tutorials.basictemplate.step2.TemplateStep2",dataClasspath:"tutorials.basictemplate.step2.TemplateStep2Data"},extra:{relatedDocs:{items:[{value:"Aria_Templates_principles"}]}}},{name:"Step 3",description:"Main statements that can be used in a template.",location:{templateClasspath:"tutorials.basictemplate.step3.TemplateStep3",dataClasspath:"tutorials.basictemplate.step3.TemplateStep3Data"},
preview:"tutorials.basictemplate.step3.Preview",extra:{relatedSamples:{items:[{value:"Samples.Templates.CDATA"},{value:"Samples.Templates.Modifiers"}]},relatedDocs:{items:[{value:"Aria_Templates_principles"},{value:"Aria_Templates_statements"},{value:"Aria_Templates_Variables#Internal_variables"}]}}},{name:"Step 4",description:"Defining and calling a macro.",location:{templateClasspath:"tutorials.basictemplate.step4.TemplateStep4",dataClasspath:"tutorials.basictemplate.step4.TemplateStep4Data"},preview:"tutorials.basictemplate.step4.Preview",
extra:{relatedDocs:{items:[{value:"Aria_Templates_principles"},{value:"Aria_Templates_statements"}]}}},{name:"Step 5",description:"Adding sub-templates",location:{templateClasspath:"tutorials.basictemplate.step5.TemplateStep5"}},{name:"Step 6",description:"Adding widgets",location:{templateClasspath:"tutorials.basictemplate.step6.TemplateStep6"},extra:{relatedSamples:{items:[{value:"Samples.Widgets"}]}}}],extra:{relatedSamples:{items:[{value:"Samples.Templates.HTML Template"},{value:"Samples.Templates.CDATA"},
{value:"Samples.Templates.Modifiers"}]},relatedDocs:{items:[{value:"Aria_Templates_principles"},{value:"Aria_Templates_statements"}]}}},{name:"Template Scripts",description:"Creating custom scripts with templates",allowsPreviousNext:true,items:[{name:"Step 1",description:"Defining a script",location:{templateClasspath:"tutorials.templatescripts.step1new.SampleTemplate",dataClasspath:"tutorials.templatescripts.step1new.SampleTemplateData"},extra:{relatedDocs:{items:[{value:"Aria_Templates_Scripts"},
{value:"Aria_Templates_template_lifecycle#Initialization"}]}},preview:"tutorials.templatescripts.step1new.Preview"},{name:"Step 2",description:"Basic methods of a script",location:{templateClasspath:"tutorials.templatescripts.step2.SampleTemplate"},extra:{relatedDocs:{items:[{value:"Aria_Templates_Scripts"},{value:"Aria_Templates_template_lifecycle#Initialization"}]},relatedSamples:{items:[{value:"Tutorials.Refresh"}]}},preview:"tutorials.templatescripts.step2.Preview"}],extra:{relatedDocs:{items:[{value:"Aria_Templates_Scripts"}]}},
preview:"tutorials.templatescripts.Preview"},{name:"CSS Templates",description:"Adding CSS styling to your application",allowsPreviousNext:true,preview:"tutorials.csstemplate.CssTemplatePreview",items:[{name:"Step 1",description:"Including a simple CSS Template",preview:"tutorials.csstemplate.step1.CSSStep1Preview",location:{templateClasspath:"tutorials.csstemplate.step1.TemplateStep1"},extra:{relatedSamples:{items:[{value:"Samples.Templates.CSS Templates"}]},relatedDocs:{items:[{value:"Aria_Templates_-_CSS_Template"}]}}},
{name:"Step 2",description:"Adding some logic in CSS Template",preview:"tutorials.csstemplate.step2.CSSStep2Preview",location:{templateClasspath:"tutorials.csstemplate.step2.TemplateStep2"},extra:{relatedSamples:{items:[{value:"Samples.Templates.CSS Templates"}]},relatedDocs:{items:[{value:"Aria_Templates_-_CSS_Template"}]}}},{name:"Step 3",description:"Specifying CSS rules at sub-template level",preview:"tutorials.csstemplate.step3.CSSStep3Preview",location:{templateClasspath:"tutorials.csstemplate.step3.TemplateStep3"},
extra:{relatedSamples:{items:[{value:"Samples.Templates.CSS Templates"}]},relatedDocs:{items:[{value:"Aria_Templates_-_CSS_Template"}]}}},{name:"Step 4",description:"Adding a script to a CSS Template",preview:"tutorials.csstemplate.step4.CSSStep4Preview",location:{templateClasspath:"tutorials.csstemplate.step4.TemplateStep4"},extra:{relatedSamples:{items:[{value:"Samples.Templates.CSS Templates"}]},relatedDocs:{items:[{value:"Aria_Templates_-_CSS_Template"}]}}}],extra:{relatedSamples:{items:[{value:"Samples.Templates.CSS Templates"}]},
relatedDocs:{items:[{value:"Aria_Templates_-_CSS_Template"}]}}},{name:"Sections",description:"Structuring the content with sections",allowsPreviousNext:true,items:[{name:"Step 1",description:"Defining sections",location:{templateClasspath:"tutorials.sections.step1.SectionTutorialStep1"},preview:"tutorials.sections.step1.Preview"},{name:"Step 2",description:"Styling sections",location:{templateClasspath:"tutorials.sections.step2.SectionTutorialStep2"},preview:"tutorials.sections.step2.Preview",extra:{relatedSamples:{items:[{value:"Tutorials.CSS Templates"}]}}},
{name:"Step 3",description:"Refreshing sections",location:{templateClasspath:"tutorials.sections.step3.SectionTutorialStep3"},preview:"tutorials.sections.step3.Preview",extra:{relatedSamples:{items:[{value:"Tutorials.Refresh"},{value:"Samples.Templates.Repeater"}]},relatedDocs:{items:[{value:"Aria_Templates_Refresh"}]}}}],extra:{relatedSamples:{items:[{label:"Section with table navigation",value:"samples.templates.keynav.KeyboardNavigation"},{label:"Section with keymap",value:"samples.templates.keynav.KeyMap"}]}}},
{name:"DOM control",description:"Interacting with the DOM",preview:"tutorials.domcontrol.Preview",allowsPreviousNext:true,extra:{relatedDocs:{items:[{value:"Aria_Templates_DOM_Control"}]}},items:[{name:"Step 1",description:"Defining DOM events handlers",location:{templateClasspath:"tutorials.domcontrol.domevents.SampleTemplate"},preview:"tutorials.domcontrol.domevents.Preview",extra:{relatedSamples:{items:[{value:"Samples.Utilities.DOM Events"}]},relatedDocs:{items:[{value:"Aria_Templates_statements#on"}]}}},
{name:"Step 2",description:"Access a DOM Element",location:{templateClasspath:"tutorials.domcontrol.domaccess.SampleTemplate"},preview:"tutorials.domcontrol.domaccess.Preview",extra:{relatedSamples:{items:[{value:"Samples.Utilities.Processing indicator"}]},relatedDocs:{items:[{value:"Aria_Templates_statements#id"},{value:"Aria_Templates_DOM_Control"}]}}}]},{name:"Refresh",description:"Refreshing a whole template or parts of it",allowsPreviousNext:true,items:[{name:"Step 1",description:"Refreshing a whole template or parts of it, step 1",
location:{templateClasspath:"tutorials.refresh.step1.TemplateRefresh"},extra:{relatedDocs:{items:[{value:"Aria_Templates_Refresh"}]},relatedSamples:{items:[{value:"Samples.Features.Refresh"}]}}},{name:"Step 2",description:"Refreshing a whole template or parts of it, step 2",location:{templateClasspath:"tutorials.refresh.step2.TemplateRefresh"},extra:{relatedDocs:{items:[{value:"Aria_Templates_Refresh"}]},relatedSamples:{items:[{value:"Samples.Features.Refresh"}]}}},{name:"Step 3",description:"Refreshing a whole template or parts of it, step 3",
location:{templateClasspath:"tutorials.refresh.step3.TemplateRefresh"},extra:{relatedDocs:{items:[{value:"Aria_Templates_Refresh"}]},relatedSamples:{items:[{value:"Samples.Features.Refresh"}]}}},{name:"Step 4",description:"Refreshing a whole template or parts of it, step 4",location:{templateClasspath:"tutorials.refresh.step4.TemplateRefresh"},extra:{relatedDocs:{items:[{value:"Aria_Templates_Refresh"}]},relatedSamples:{items:[{value:"Samples.Features.Refresh"}]}}},{name:"Step 5",description:"Refreshing a whole template or parts of it, step 5",
location:{templateClasspath:"tutorials.refresh.step5.TemplateRefresh"},extra:{relatedDocs:{items:[{value:"Aria_Templates_Refresh"}]},relatedSamples:{items:[{value:"Samples.Features.Refresh"}]}}}],extra:{relatedDocs:{items:[{value:"Aria_Templates_Refresh"}]},relatedSamples:{items:[{value:"Samples.Features.Refresh"}]}}},{name:"Module",description:"Creating modules and submodules",allowsPreviousNext:true,items:[{name:"Step 1",description:"Creating a simple module with module controller",location:{templateClasspath:"tutorials.module.step1.PersonSearchTemplate",
moduleCtrlClasspath:"tutorials.module.step1.PersonSearchTemplateController",refpath:"moduleTutorialStep1"},preview:"tutorials.module.step1.Preview"},{name:"Step 2",description:"Creating submodules",location:{templateClasspath:"tutorials.module.step2.SampleTemplate",moduleCtrlClasspath:"tutorials.module.step2.SampleModule",refpath:"moduleTutorialStep2"},preview:"tutorials.module.step2.Preview",extra:{sourceFiles:{items:[{value:"tutorials.module.step2.IPersonAddModule",type:"JS"},{value:"tutorials.module.step2.PersonAddModule",
type:"JS"},{value:"tutorials.module.step2.IPersonSearchModule",type:"JS"},{value:"tutorials.module.step2.PersonSearchModule",type:"JS"}]}}}],restrictedAudience:["appcustomizer"]},{name:"Data Model",description:"How to create the Data Model for you module controller.",allowsPreviousNext:true,items:[{name:"Step 1",description:"Data Model from Bean Definition",location:{templateClasspath:"tutorials.datamodel.step1.Step1Template",moduleCtrlClasspath:"tutorials.datamodel.step1.ModuleController",refpath:"tutorialDataModelStep1"},
preview:"tutorials.datamodel.step1.Preview"}]},{name:"Macro Libraries",description:"Shared Macro Libraries.",allowsPreviousNext:true,items:[{name:"Step 1",description:"Simple Template with Library dependency",location:{templateClasspath:"tutorials.macrolibs.step1.TemplateStep1"}},{name:"Step 2",description:"Nested Libraries",location:{templateClasspath:"tutorials.macrolibs.step2.TemplateStep2"}},{name:"Step 3",description:"Widget Bindings",location:{templateClasspath:"tutorials.macrolibs.step3.TemplateStep3"}}]},
{name:"Views",description:"Sorting, filtering and paging utilities",allowsPreviousNext:true,items:[{name:"Step 1",description:"Sorting data",location:{templateClasspath:"tutorials.view.step1.SortingTemplate",dataClasspath:"tutorials.view.step1.ViewData"},extra:{relatedSamples:{items:[{value:"Samples.Templates.Views"}]},relatedDocs:{items:[{value:"Aria_Templates_Views"}]}}},{name:"Step 2",description:"Sorting and filtering data",location:{templateClasspath:"tutorials.view.step2.FilterTemplate",dataClasspath:"tutorials.view.step2.ViewData"},
extra:{relatedSamples:{items:[{value:"Samples.Templates.Views"}]},relatedDocs:{items:[{value:"Aria_Templates_Views"}]}}},{name:"Step 3",description:"Sorting, filtering and paging data",location:{templateClasspath:"tutorials.view.step3.PagingTemplate",dataClasspath:"tutorials.view.step3.ViewData"},extra:{relatedSamples:{items:[{value:"Samples.Templates.Views"}]},relatedDocs:{items:[{value:"Aria_Templates_Views"}]}}}],extra:{relatedSamples:{items:[{value:"Samples.Templates.Views"}]},relatedDocs:{items:[{value:"Aria_Templates_Views"}]}}},
{name:"Template inheritance",description:"Template inheritance",allowsPreviousNext:true,items:[{name:"Step 1 parent",description:"Simple parent template with 3 macros",location:{templateClasspath:"tutorials.tplinheritance.step1.ParentTemplate"}},{name:"Step 1 child",description:"Simple child template with 2 macros (one overriding its parent macro)",location:{templateClasspath:"tutorials.tplinheritance.step1.ChildTemplate"}},{name:"Step 2 parent",description:"Parent template with a script",location:{templateClasspath:"tutorials.tplinheritance.step2.ParentTemplate"}},
{name:"Step 2 child",description:"Child template with script",location:{templateClasspath:"tutorials.tplinheritance.step2.ChildTemplate"}},{name:"Step 3 parent",description:"Parent template with 2 macro libraries",location:{templateClasspath:"tutorials.tplinheritance.step3.ParentTemplate"}},{name:"Step 3 child",description:"Child template which inherits 2 macro libraries from its parent and overrides one of them",location:{templateClasspath:"tutorials.tplinheritance.step3.ChildTemplate"}},{name:"Step 4 child 1",
description:"Child template overriding its parent's CSS",location:{templateClasspath:"tutorials.tplinheritance.step4.FirstChildTemplate"}},{name:"Step 4 child 2",description:"Child template inheriting its parent's CSS",location:{templateClasspath:"tutorials.tplinheritance.step4.SecondChildTemplate"}}]}]},oldSamples:{name:"Old Samples",description:"Samples kept for backward compatibility.",items:[{name:"Hello World",description:"Learn the basics of Aria templates",allowsPreviousNext:true,items:[{name:"Step 1",
description:"Hello World Step 1",location:{templateClasspath:"tutorials.helloworld.step1.TemplateStep1"}},{name:"Step 2",description:"Hello World Step 2",location:{templateClasspath:"tutorials.helloworld.step2.TemplateStep2",dataClasspath:"tutorials.helloworld.step2.TemplateStep2Data"}},{name:"Step 3",description:"Hello World Step 3",location:{templateClasspath:"tutorials.helloworld.step3.TemplateStep3",dataClasspath:"tutorials.helloworld.step3.TemplateStep3Data"}}]},{name:"Control flow",description:"Control flow statements in templates",
allowsPreviousNext:true,items:[{name:"Step 1",description:"Control flow step 1",location:{templateClasspath:"tutorials.controlflow.step1.ControlFlowStep1"}},{name:"Step 2",description:"Control flow step 2",location:{templateClasspath:"tutorials.controlflow.step2.ControlFlowStep2"}},{name:"Step 3",description:"Control flow step 3",location:{templateClasspath:"tutorials.controlflow.step3.ControlFlowStep3",dataClasspath:"tutorials.controlflow.step3.ControlFlowStep3Data"}}]},{name:"Template Scripts",
description:"Creating custom scripts with templates",allowsPreviousNext:true,location:{templateClasspath:"tutorials.templatescripts.step1.SampleTemplate"},extra:{relatedDocs:{items:[{value:"Aria_Templates_Scripts"}]}}}]}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/dataModel/SamplesListBean.js
//z9A2tcZCFD
Aria.beanDefinitions({$package:"apps.guide.main.dataModel.SamplesListBean",$description:"Definition of the datamodel structure containing the list of samples.",$namespaces:{json:"aria.core.JsonTypes",sidebar:"apps.guide.main.dataModel.SidebarBean"},$beans:{BaseSample:{$type:"json:Object",$description:"Base configuration for a collection of samples or a single sample.",$mandatory:true,$properties:{name:{$type:"json:String",$description:"Name of the sample/collection.",$mandatory:true},description:{$type:"json:String",
$description:"Short description of the sample/collection.",$mandatory:true},preview:{$type:"json:PackageName",$description:"Template to be included in the content section."},extra:{$type:"sidebar:Sidebar",$description:"Additional information on the sample/collection."},restrictedAudience:{$type:"Audience",$default:[]},packageName:{$type:"json:String",$description:"Unique identifier for the collection. Dot notation. Built by the application"},previousSample:{$type:"NavigationCrumb",$description:"Crumb that allows to navigate to the previous sample/collection"},
nextSample:{$type:"NavigationCrumb",$description:"Crumb that allows to navigate to the next sample/collection"}}},SampleCollection:{$type:"BaseSample",$description:"A collection of samples.",$mandatory:true,$properties:{items:{$type:"json:Array",$description:"List of samples or collections.",$mandatory:true,$contentType:{$type:"json:MultiTypes",$description:"A collection or a single sample.",$contentTypes:[{$type:"SampleCollection",$description:"A collection of samples."},{$type:"SampleItem",$description:"A single sample."}]}},
allowsPreviousNext:{$type:"json:Boolean",$description:"Whether the previous and next items have to be shown when displaying it",$default:false}}},SampleItem:{$type:"BaseSample",$description:"A single sample",$properties:{location:{$type:"Location",$description:"Describe how to retrieve the sample.",$mandatory:true},allowsPreviousNext:{$type:"json:Boolean",$description:"Whether the previous and next items have to be shown when displaying it",$default:true}}},Location:{$type:"json:Object",$description:"Describe how to retrieve the sample.",
$properties:{templateClasspath:{$type:"json:PackageName",$description:"Classpath of the main template. It's the sample output.",$mandatory:true},moduleCtrlClasspath:{$type:"json:PackageName",$description:"Classpath of an optional module controller. It will be loaded as a submodule of the main application."},dataClasspath:{$type:"json:PackageName",$description:"Classpath of an optional data model."},refpath:{$type:"json:String",$description:"Reference name of the submodule."},testClasspath:{$type:"json:PackageName",
$description:"Classpath of an optional template test."}}},Audience:{$type:"json:Array",$contentType:{$type:"json:Enum",$enumValues:["uideveloper","customiser","serverscripter","appcustomizer","internal"],$description:"List of possible audiences."},$description:"This collection or the single sample will be invisible to this audience."},NavigationCrumb:{$type:"json:Object",$description:"Crumb that triggers navigation.",$properties:{name:{$type:"json:String",$description:"Name of the crumb."},type:{$type:"json:String",
$description:"Type of navigation."},path:{$type:"json:String",$description:"Destination path."}}},SamplesPackagesMap:{$type:"json:Map",$description:"Sample packages map extracted from the samples list.",$contentType:{$type:"json:MultiTypes",$description:"A collection or a single sample or a String.",$contentTypes:[{$type:"json:Object",$description:"A sample collection with a SampleCollection type.",$properties:{type:{$type:"json:String",$description:"Type of the item.",$regExp:/^SampleCollection$/},
content:{$type:"SampleCollection",$description:"A collection of samples."}}},{$type:"json:Object",$description:"A sample with a Sample type.",$properties:{type:{$type:"json:String",$description:"Type of the item.",$regExp:/^Sample$/},content:{$type:"SampleItem",$description:"A single sample."}}},{$type:"json:String",$description:"PackageName of a sample Template"}]}}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/dataModel/SamplesUtils.js
//z9A2tcZCFD
Aria.classDefinition({$classpath:"apps.guide.main.dataModel.SamplesUtils",$dependencies:["aria.utils.Array","aria.utils.Type","apps.guide.main.dataModel.SamplesList","apps.guide.main.dataModel.SamplesListBean"],$singleton:true,$constructor:function(){this.samplesList=apps.guide.main.dataModel.SamplesList.samples;this.tutorialsList=apps.guide.main.dataModel.SamplesList.tutorials;this.oldSamplesList=apps.guide.main.dataModel.SamplesList.oldSamples;this.__packageNamesFromSampleList(this.oldSamplesList,
this.samplesPackages,null,Aria.audience);this.__packageNamesFromSampleList(this.samplesList,this.samplesPackages,null,Aria.audience);this.__packageNamesFromSampleList(this.tutorialsList,this.samplesPackages,null,Aria.audience);this.__normalizeSamples()},$prototype:{samplesPackages:{},__packageNamesFromSampleList:function(a,b,c,e){c=(c?c+".":"")+a.name;a.packageName=c;if(aria.utils.Array.contains(a.restrictedAudience||[],e))return true;if(a.items){b[c]={type:"SampleCollection",content:a};for(var d=
0,f=a.items.length;d<f;d+=1)if(this.__packageNamesFromSampleList(a.items[d],b,c,e)===true){a.items.splice(d,1);d-=1;f-=1}}else{b[c]={type:"Sample",content:a};b[a.location.templateClasspath]=c}},extractTestClasspaths:function(a,b){a=a||this.samplesList;b=b||[];if(a.items)for(var c=0,e=a.items.length;c<e;c+=1)this.extractTestClasspaths(a.items[c],b);else a.location.testClasspath&&b.push(a.location.testClasspath);return b},getPackageName:function(a){var b=this.samplesPackages[a];if(aria.utils.Type.isString(b))return b;
return a},getPortionOf:function(a){a=this.samplesPackages[a];if(aria.utils.Type.isString(a))a=this.samplesPackages[a];return a},getSampleType:function(a){return(a=this.getPortionOf(a))?a.type:"Sample"},updateExtra:function(a,b){var c=this.getPortionOf(a);if(c)c.content.extra=b},__normalizeSamples:function(){aria.core.JsonValidator.normalize({json:this.samplesList,beanName:"apps.guide.main.dataModel.SamplesListBean.SampleCollection"})||this.$logError("Invalid samples list");aria.core.JsonValidator.normalize({json:this.tutorialsList,
beanName:"apps.guide.main.dataModel.SamplesListBean.SampleCollection"})||this.$logError("Invalid tutorials list");aria.core.JsonValidator.normalize({json:this.samplesPackages,beanName:"apps.guide.main.dataModel.SamplesListBean.SamplesPackagesMap"})||this.$logError("Invalid samples packages map")}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/dataModel/SidebarBean.js
//z9A2tcZCFD
Aria.beanDefinitions({$package:"apps.guide.main.dataModel.SidebarBean",$description:"Definition of the portion of the datamodel holding the sidebar information for the selected sample.",$namespaces:{json:"aria.core.JsonTypes"},$beans:{Sidebar:{$type:"json:Object",$description:"Extra information to be displayed in the sidebar.",$properties:{sourceFiles:{$type:"SidebarBlock",$description:"List of files for which the source code should be made available."},relatedSamples:{$type:"SidebarBlock",$description:"List of similar samples."},
relatedDocs:{$type:"SidebarBlock",$description:"List of documentation files linked to this sample."},relatedApidocs:{$type:"SidebarBlock",$description:"List of related API doc pages."}}},SidebarBlock:{$type:"json:Object",$description:"Representation of a block of information to be displayed in the sidebar",$properties:{text:{$type:"json:String",$description:"Header for block container.",$mandatory:true},collapsed:{$type:"json:Boolean",$description:"True if the content should be invisible/collapsed.",
$default:false},type:{$type:"json:Enum",$enumValues:["Source","APIdocs","doc","spl"],$description:"Type of the contained items."},items:{$type:"SidebarItemsList",$description:"List of items to be displayed"}}},SidebarItemsList:{$type:"json:Array",$description:"List of documentation items.",$contentType:{$type:"SidebarItem",$description:"A single sidebar item."}},SidebarItem:{$type:"json:Object",$description:"A single sidebar item.",$properties:{value:{$type:"json:String",$description:"Package name that represent the resource.",
$mandatory:true},label:{$type:"json:String",$description:"Resource label.",$mandatory:true},type:{$type:"json:Enum",$enumValues:["JS","TPL","RES","CSS","TML","TXT"],$description:"Type of the source file to be displayed."},role:{$type:"json:Enum",$enumValues:["Template","Script","CSS","ModuleCtrl","Data"],$description:"Role of the source file to be displayed."}}}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/documentation/ContentTemplateScript.js
//z9A2tcZCFD
Aria.tplScriptDefinition({$classpath:"apps.guide.main.documentation.ContentTemplateScript",$dependencies:["aria.utils.Dom","apps.guide.main.library.ScrollController"],$prototype:{$afterRefresh:function(){var a=this.data.doc.pageHash;if(a){a=aria.utils.Dom.getElementById(a);aria.utils.Dom.scrollIntoView(a,true)}else apps.guide.main.library.ScrollController.resetScroll(null,{scrollTop:0,scrollLeft:0})}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/header/HeaderTemplateScript.js
//z9A2tcZCFD
Aria.tplScriptDefinition({$classpath:"apps.guide.main.header.HeaderTemplateScript",$prototype:{getHighlightedTab:function(){var a=this.data.currentState.contentType;switch(a){case "SampleCollection":case "Sample":return this.data.currentState.path.indexOf("Tutorial")==0?"Tutorial":"Sample";default:return a}},searchboxChange:function(){var a=this.data["searchBox:value"];if(a&&a.path){this.moduleCtrl.navigate(null,{type:"spl",path:a.path});this.data=!this.data?{}:this.data;this.$json.setValue(this.data,
"searchBox:value","")}}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/IAppModule.js
//z9A2tcZCFD
Aria.interfaceDefinition({$classpath:"apps.guide.main.IAppModule",$extends:"aria.templates.IModuleCtrl",$events:{locationChanged:"Raised when a new location has been set."},$interface:{init:{$type:"Function",$callbackParam:1},navigate:{$type:"Function"},setSidebarFillingHeight:{$type:"Function"}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/library/Dependencies.js
//z9A2tcZCFD
Aria.classDefinition({$classpath:"apps.guide.main.library.Dependencies",$singleton:true,$statics:{REGEXP:/{@aria:Template[^{]*\{[\s\S]*?defaultTemplate\s*:\s*['\"]([0-9a-z.]+)['\"]\s*(?:\}|,)/gi},$constructor:function(){},$prototype:{matchTemplateWidget:function(b){for(var a=[],c=apps.guide.main.library.Dependencies.REGEXP;match=c.exec(b);)a.push(match[1]);return a}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/library/ScrollController.js
//z9A2tcZCFD
Aria.classDefinition({$classpath:"apps.guide.main.library.ScrollController",$singleton:true,$dependencies:["aria.utils.Dom"],$constructor:function(){},$prototype:{__scroll:{},rememberScroll:function(b){var a=aria.utils.Dom.getElementById("at-main");this.__scroll[b]={scrollTop:a.scrollTop,scrollLeft:a.scrollLeft}},resetScroll:function(b,a){a||(a=b&&this.__scroll[b]?this.__scroll[b]:{scrollTop:0,scrollLeft:0});var c=aria.utils.Dom.getElementById("at-main");c.scrollTop=a.scrollTop;c.scrollLeft=a.scrollLeft}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/mainContent/MainContentScript.js
//z9A2tcZCFD
Aria.tplScriptDefinition({$classpath:"apps.guide.main.mainContent.MainContentScript",$prototype:{$viewReady:function(){this.moduleCtrl.setSidebarFillingHeight()},getContentTemplatePath:function(){var a=this.data.currentState.contentType;if(a=="Internals")return"apps.guide.internals.Main";return"apps.guide.main."+a.toLowerCase()+".ContentTemplate"},getSidebarController:function(){return this.data.currentState.contentType=="Documentation"?this.moduleCtrl.documentationNavigation.sidebar:this.moduleCtrl.sampleNavigation.sidebar},
getContentController:function(){switch(this.data.currentState.contentType){case "Documentation":return this.moduleCtrl.documentationNavigation;case "Home":return this.moduleCtrl;case "Internals":return this.moduleCtrl.internals;default:return this.moduleCtrl.sampleNavigation}}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/MainTemplateScript.js
//z9A2tcZCFD
Aria.tplScriptDefinition({$classpath:"apps.guide.main.MainTemplateScript",$prototype:{onModuleEvent:function(a){a.name==="locationChanged"&&this.$refresh()}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/navigationModules/DocumentationNavigation.js
//z9A2tcZCFD
Aria.classDefinition({$classpath:"apps.guide.main.navigationModules.DocumentationNavigation",$extends:"aria.templates.ModuleCtrl",$implements:["apps.guide.main.navigationModules.INavigation"],$dependencies:["apps.guide.main.dataModel.DataBean","aria.core.Cache","aria.core.DownloadMgr"],$constructor:function(){this.$ModuleCtrl.constructor.call(this)},$prototype:{$publicInterfaceName:"apps.guide.main.navigationModules.INavigation",init:function(a,b){this.loadSubModules([{refpath:"sidebar",classpath:"apps.guide.main.sidebar.DocumentationSidebar"}],
{fn:"_completeInit",scope:this,args:b})},_completeInit:function(a,b){b&&this.$callback(b)},navigateTo:function(a){var b=a.path;this.setData({doc:{selectedItem:b}});a=this.__getDocPathFromFullPath(b);aria.core.Cache.getItem("files","docs/"+a+".html")?this.__navigateToDocComplete(b):aria.core.DownloadMgr.loadFile("docs/"+a+".html",{fn:function(){this.__navigateToDocComplete(b)},scope:this})},onSubModuleEvent:function(a){a.name=="selectedItemChanged"&&this.select(null,a)},select:function(a,b){if(b.type==
"doc")this.navigateTo(b);else{b.name="selectedItemChanged";this.$raiseEvent(b)}},__navigateToDocComplete:function(a){var b=this.__getDocPathFromFullPath(a),e=this.__getDocHashFromFullPath(a),d=aria.core.Cache.getItem("files","docs/"+b+".html");d||this.$logError("Unable to display "+b+" documentation page");this._data.doc.pageContent=d?this.__preprocessDocumentation(d.value):"";this._data.doc.pageHash=this.__getDocHashFromFullPath(a);this.sidebar.update(this._data.doc);try{aria.core.JsonValidator.normalize({json:this._data.doc,
beanName:"apps.guide.main.dataModel.DataBean.DocumentationState"},true)}catch(c){if(c.errors){a=0;for(d=c.errors.length;a<d;a+=1)this.$logError(c.errors[a].msgId,c.errors[a].msgArgs)}else throw c;}b="doc="+b;if(e)b=b.concat(",hash=",e);this.$raiseEvent({name:"navigationComplete",newLocationRef:b})},__getDocPathFromFullPath:function(a){if(a.match(/#/))return a.split("#")[0];return a},__getDocHashFromFullPath:function(a){if(a.match(/#/)){a=a.split("#");return a.length>=2?a[1]:""}return""},__preprocessDocumentation:function(a){a=
a.split(/<body[^>]*>[\n\s]*/,2);var b=a[1].lastIndexOf("</body>");a=a[1].slice(0,b);a=a.replace(/<a([^>]*)href=(['"]{1})([^'"\/]*)['"]{1}/g,this.__linkReplacement());a=a.replace(/<a([^>]*)href=(['"]{1})([^'"]*)['"]{1}([^>]*)>/g,this.__linkReplacementForSamples);b=/(^.*aria\/guide[^\/]*\/)/.exec(location.href)?"":"aria/guide/";return a=a.replace(/<img([^>]*)src=(['"]{1})\/*([^'"]*)['"]{1}/g,"<img$1src=$2"+b+"docs/$3$2")},__linkReplacement:function(){var a=this.__getDocPathFromFullPath(this._data.doc.selectedItem);
return function(b,e,d,c){if(c.match(/\.html/))if(c.match(/#/)){c=c.split("#");b=c[0].replace(/\.html/,"");return(c=c.length>=2?c[1]:"")?"<a"+e+"href="+d+"#doc="+b+",hash="+c+d:"<a"+e+"href="+d+"#doc="+b+d}else{b=c.replace(/\.html/,"");return"<a"+e+"href="+d+"#doc="+b+d}else if(c.match(/#/)){b=a;c=c.substr(1);return"<a"+e+"href="+d+"#doc="+b+",hash="+c+d}else return b}},__linkReplacementForSamples:function(a,b,e,d,c){if(d.match(/#[spl|tpl]/)){a=d.replace(/#tpl/,"#spl");a=a.split("#");a=a[1].split(",");
c=c.replace(/title=(['"]{1})[^'"]*['"]{1}/,"title=$1#"+a[0]+"$1");return"<a"+b+"href="+e+"#"+a[0]+e+c+">"}else return a}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/navigationModules/INavigation.js
//z9A2tcZCFD
Aria.interfaceDefinition({$classpath:"apps.guide.main.navigationModules.INavigation",$extends:"aria.templates.IModuleCtrl",$events:{navigationComplete:{description:"Raised when the navigation is complete.",properties:{newLocationRef:"new hash to append to the url."}},displayChanged:"Raised when the displayed information changes. It is raised only when the contentType is equal to 'Sample'.",selectedItemChanged:{description:"Raised when a change of contentType occurs.",properties:{type:"type of the selected resource",
path:"path of the selected resource",sourceFileType:"type of the source file. Only used when resType is 'Source'."}}},$interface:{init:{$type:"Function",$callbackParam:1},navigateTo:{$type:"Function"},select:{$type:"Function"}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/navigationModules/SampleNavigation.js
//z9A2tcZCFD
Aria.classDefinition({$classpath:"apps.guide.main.navigationModules.SampleNavigation",$extends:"aria.templates.ModuleCtrl",$implements:["apps.guide.main.navigationModules.INavigation"],$dependencies:["aria.utils.Array","aria.utils.Type","aria.core.Cache","apps.guide.main.library.Dependencies","apps.guide.main.dataModel.SamplesUtils"],$constructor:function(){this.$ModuleCtrl.constructor.call(this);this.matchTemplateWidget=apps.guide.main.library.Dependencies.matchTemplateWidget;this.__samplesUtils=
apps.guide.main.dataModel.SamplesUtils},$prototype:{$publicInterfaceName:"apps.guide.main.navigationModules.INavigation",init:function(a,b){this.loadSubModules([{refpath:"sidebar",classpath:"apps.guide.main.sidebar.SampleSidebar"}],{fn:"_completeInit",scope:this,args:b})},_completeInit:function(a,b){b&&this.$callback(b)},__navigateMap:{spl:"__navigateToSample",Output:"__navigateToOutput",Source:"__navigateToSource",Data:"__navigateToData"},navigateTo:function(a){var b=this[this.__navigateMap[a.type]];
aria.utils.Type.isFunction(b)&&b.call(this,a)},select:function(a,b){if(aria.utils.Array.contains(["Output","Source","Data"],b.type))this.navigateTo({type:b.type,path:b.path,sourceFileType:b.sourceFileType});else{b.name="selectedItemChanged";this.$raiseEvent(b)}},onSubModuleEvent:function(a){if(a.name=="selectedItemChanged")this.select(null,a);else a.name=="updateExtra"&&this.__samplesUtils.updateExtra(a.packageName,a.extra)},__navigateToSample:function(a){this.setData({currentState:{},templateReady:false});
a=a.path;var b=this.__samplesUtils.getPortionOf(a);this.__addPreviousAndNext(b);var c={},d=true;if(b){if(b.type!="Sample")return this.__navigateToSampleComplete({portion:b,location:c,type:b.type,path:a,internal:true});c=b.content.location}else{d=false;c={templateClasspath:a}}this.__resolveDependenciesForNewLocation({portion:b,location:c,path:a,internal:d})},__resolveDependenciesForNewLocation:function(a){var b=a.location;b||this.$logError("Empty location while resolving dependencies");var c=[],d=
[];b.templateClasspath&&d.push(b.templateClasspath);b.moduleCtrlClasspath&&c.push(b.moduleCtrlClasspath);b.dataClasspath&&c.push(b.dataClasspath);a.portion&&a.portion.content.preview&&d.push(a.portion.content.preview);Aria.load({classes:c,templates:d,oncomplete:{fn:this.__completeDependencies,scope:this,args:a}})},__completeDependencies:function(a){this.__getTemplateDependencies(a,[a.location.templateClasspath])},__getTemplateDependencies:function(a,b){for(var c=[],d=0,f=b.length;d<f;d+=1){var e=
b[d],g=aria.core.Cache.getItem("files",e.replace(/\./g,"/")+".tpl");if(!g)return this.$logError("Couldn't find the cache item for "+e);g=this.matchTemplateWidget(g.value);for(var h=0,i=g.length;h<i;h+=1)aria.utils.Array.contains(c,g[h])||c.push(g[h]);if(g=Aria.nspace(e,false)){g=g.classDefinition;if(g.$templates)c=g.$templates.concat(c)}else this.$logError("Can't find the classdefinition for "+e)}a.templates=c;Aria.load({templates:c,oncomplete:{fn:this.__completeTemplateDependencies,scope:this,args:a}})},
__completeTemplateDependencies:function(a){a.templates.length?this.__getTemplateDependencies(a,a.templates):this.__navigateToSampleComplete(a)},__navigateToSampleComplete:function(a){var b=a.portion;if(a.internal){var c=this.__breadcrumbsFromSample(b.content.packageName);c={spl:{displayType:"Output",data:b.content,selectedItem:null,breadcrumbs:c}};if(aria.core.JsonValidator.normalize({json:c.spl,beanName:"apps.guide.main.dataModel.DataBean.SampleState"}))this._data=c;else this.$logError("Invalid application state");
b.type=="Sample"?this.__initializeDependencies(a.location,a.path):this.__endNavigate(a.path)}else this.__navigateToExternalTemplate(a.path)},__initializeDependencies:function(a,b){if(a.moduleCtrlClasspath)this[a.refpath]?this.__endNavigate(b):this.loadSubModules([{refpath:a.refpath,classpath:a.moduleCtrlClasspath}],{fn:"_onload_subModuleCtrl",args:{location:a,path:b}});else{var c={};if(a.dataClasspath)try{c=(new (Aria.getClassRef(a.dataClasspath))).data}catch(d){this.$logError("Unable to load the datamodel for sample "+
b+"\nPlease check the definition of "+a.dataClasspath,d)}this._data.spl.sampleData=c;this.__endNavigate(b)}},_onload_subModuleCtrl:function(a,b){var c=b.path;this._data.spl.sampleData=null;this.__endNavigate(c)},__endNavigate:function(a){this.sidebar.update(this._data.spl);this._data.templateReady=true;this.$raiseEvent({name:"navigationComplete",newLocationRef:"spl="+a})},__addPreviousAndNext:function(a){if(a){var b=a.content;if(!(b.previousSample||b.nextSample)){var c=false;b.previousSample=null;
b.nextSample=null;if(c=b.hasOwnProperty("allowsPreviousNext")?b.allowsPreviousNext:a.type=="Sample"){a=b.packageName.split(".");a.pop();if(a=a.join(".")){a=this.__samplesUtils.getPortionOf(a);a=a.content.items;c=a.length;for(var d=0;d<c&&a[d].packageName!=b.packageName;d++);var f,e;if(d>0){f=a[d-1];f=f.packageName;e=f.split(".");e=e[e.length-1];b.previousSample={name:e,type:"spl",path:f}}if(d<c-1){f=a[d+1];f=f.packageName;e=f.split(".");e=e[e.length-1];b.nextSample={name:e,type:"spl",path:f}}}}}}},
__navigateToExternalTemplate:function(a){var b={spl:{displayType:"Output",data:{name:"External sample",description:"External sample",location:{templateClasspath:a},packageName:a},selectedItem:null,breadcrumbs:null}};if(aria.core.JsonValidator.normalize({json:b.spl,beanName:"apps.guide.main.dataModel.DataBean.SampleState"}))this._data=b;else this.$logError("Invalid application state");this.sidebar.update(this._data.spl);this._data.templateReady=true;this.$raiseEvent({name:"navigationComplete",newLocationRef:"spl="+
a})},__breadcrumbsFromSample:function(a){a=a.split(".");var b=a.length,c=[],d=[];if(b<2)return a;for(var f=0;f<b;f+=1){var e=a[f];c.push(e);f<b-1?d.push({path:c.join("."),name:e,type:"spl"}):d.push(e)}return d},__navigateToOutput:function(){if(this._data.spl.displayType!="Output"){this._data.spl.displayType="Output";this._data.spl.selectedItem=null;this.$raiseEvent("displayChanged")}},__navigateToSource:function(a){this._data.spl.displayType="Source";this._data.spl.selectedItem=a.path;this._data.spl.sourceFileType=
a.sourceFileType;this.$raiseEvent("displayChanged")},__navigateToData:function(){if(this._data.spl.displayType!="Data"){this._data.spl.displayType="Data";this._data.spl.selectedItem=null;this.$raiseEvent("displayChanged")}}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/sample/ContentTemplateScript.js
//z9A2tcZCFD
Aria.tplScriptDefinition({$classpath:"apps.guide.main.sample.ContentTemplateScript",$dependencies:["ZeroClipboard","apps.guide.main.library.ScrollController","aria.core.Cache","aria.core.DownloadMgr","aria.utils.Json"],$statics:{SUFFIXES_MAP:{JS:".js",TPL:".tpl",RES:".js",CSS:".tpl.css",TML:".tml",TXT:".tpl.txt"}},$destructor:function(){ZeroClipboard.stop()},$prototype:{getFileContent:function(a){a=this.getFilePath(a);var b=aria.core.Cache.getItem("files",a);if(b)return b.value;else{aria.core.DownloadMgr.loadFile(a,
{fn:function(){this.$refresh()},scope:this});return""}},getFilePath:function(a){var b=a.classPath;if(a=a.type?a.type:null)return b.replace(/\./g,"/")+this.SUFFIXES_MAP[a];else{a=aria.core.Cache.getItem("classes",b);return b.replace(/\./g,"/")+this.SUFFIXES_MAP[a.content]}},onModuleEvent:function(a){a.name==="displayChanged"&&this.$refresh()},$afterRefresh:function(){apps.guide.main.library.ScrollController.resetScroll(null,{scrollLeft:0,scrollTop:0});var a=this.data.spl;if(a){if(a.displayType!="Source")return;
a=this.getFileContent({classPath:a.selectedItem,type:a.sourceFileType});ZeroClipboard.stop();ZeroClipboard.start(a)}prettyPrint()},getDataSnapshot:function(){var a=this.data.spl.data.location;return this._filterMetadata(a.refpath?this.data[a.refpath]:this.data.spl.sampleData)},_filterMetadata:function(a){var b;if(aria.utils.Type.isFunction(a))return"{function ...}";else if(aria.utils.Type.isArray(a))b=[];else if(aria.utils.Type.isObject(a))b={};else return a;for(var c in a)if(a.hasOwnProperty(c))b[c]=
aria.utils.Array.contains(this._excludedMetadataKeys,c)?"...":this._filterMetadata(a[c]);return b},prettyFormatDataModel:function(a,b){b||(a=aria.utils.Json.removeMetadata(a));return aria.utils.Json.convertToJsonString(a,{indent:"\t",maxDepth:10})},_excludedMetadataKeys:["scope","classDefinition","args","parent"]}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/samplecollection/ContentTemplateScript.js
//z9A2tcZCFD
Aria.tplScriptDefinition({$classpath:"apps.guide.main.samplecollection.ContentTemplateScript",$dependencies:["apps.guide.main.library.ScrollController"],$destructor:function(){apps.guide.main.library.ScrollController.rememberScroll(this.sample.packageName)},$prototype:{$afterRefresh:function(){apps.guide.main.library.ScrollController.resetScroll(this.sample.packageName)}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/search/SearchBoxBean.js
//z9A2tcZCFD
Aria.beanDefinitions({$package:"apps.guide.main.search.SearchBoxBean",$description:"Definition of the suggestions used in the SearchBox resource handler",$namespaces:{base:"aria.widgets.form.AutoCompleteBean",json:"aria.core.JsonTypes"},$beans:{Suggestion:{$type:"base:Suggestion",$description:"A SearchBox suggestion",$restricted:false,$properties:{label:{$type:"json:String",$description:"label for this suggestion",$sample:"TimeField",$mandatory:true},path:{$type:"json:String",$description:"path used to navigate to the suggestion",
$sample:"Samples.Widgets.TimeField",$mandatory:true},type:{$type:"json:String",$description:"Type of item, like Sample/Tutorial or Collection",$sample:"Sample Collection",$mandatory:true}}},Node:{$type:"json:Object",$description:"Node of the Trie",$properties:{isMatch:{$type:"json:Boolean",$description:"True if this node corresponds to one or more Suggestions",$default:false},children:{$type:"json:Object",$description:"List of child nodes"}}}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/search/SearchBoxHandler.js
//z9A2tcZCFD
Aria.classDefinition({$classpath:"apps.guide.main.search.SearchBoxHandler",$dependencies:["apps.guide.main.dataModel.SamplesList","apps.guide.main.search.SearchBoxBean"],$statics:{SUGGESTION_BEAN:"apps.guide.main.search.SearchBoxBean.Suggestion"},$constructor:function(){this.threshold=1;this._suggestionMap={children:[]};this._generateMap()},$prototype:{_generateMap:function(){this._walk(apps.guide.main.dataModel.SamplesList.samples,null,"Sample");this._walk(apps.guide.main.dataModel.SamplesList.oldSamples,
null,"Sample");this._walk(apps.guide.main.dataModel.SamplesList.tutorials,null,"Tutorial")},_walk:function(a,b,c){var d={},e=(b?b+".":"")+a.name;if(a.items){d={label:a.name,path:e,type:c+" Collection",description:a.description};b=0;for(var f=a.items.length;b<f;b+=1)this._walk(a.items[b],e,c)}else{d={label:a.name,path:e,type:c,description:a.description};this._insertItem(b?b.split(".").slice(-1)[0]:"",d)}this._insertItem(a.name,d)},_insertItem:function(a,b){if(a){this._populateTrie(a,b,true);var c=
a.split(" ");if(c.length)for(var d=1,e=c.length;d<e;d+=1)c[d]&&this._populateTrie(c[d],b,false)}},_populateTrie:function(a,b){var c=this._suggestionMap;a=a.toLowerCase();for(var d=0,e=a.length;d<e;d+=1){var f=a.charAt(d);c[f]||(c[f]={isMatch:false,children:[]});c=c[f];c.children.push(b)}c.isMatch=true},_getItems:function(a){for(var b=this._suggestionMap,c=0,d=a.length;c<d;c+=1){var e=a.charAt(c);if(b[e])b=b[e];else return{approx:b.children.slice(0),exact:[]}}return{exact:b.children.slice(0),approx:[]}},
getSuggestions:function(a,b){if(!a||a.length<this.threshold)return this.$callback(b,null);a=aria.utils.String.trim(a.toLowerCase());var c=this._getItems(a);if(c.exact.length>0)return this.$callback(b,c.exact);var d=a.split(" ").sort(function(i,j){var g=i.length,h=j.length;return g===h?0:g<h?1:-1}),e=null;if(d.length>1)for(var f=0,k=d.length;f<k&&d[f];f+=1)e=this.__intersect(e,this._getItems(d[f]));if(e&&e.length>0)return this.$callback(b,e);c.approx.push({label:"view:approx",path:"",type:"",description:""});
this.$callback(b,c.approx)},__intersect:function(a,b){if(!a)return b.exact;return aria.utils.Array.filter(a,function(c){return aria.utils.Array.contains(b.exact,c)})},getDefaultTemplate:function(){return"apps.guide.main.search.SearchBoxListTemplate"},suggestionToLabel:function(a){return a.label}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/search/SearchBoxListTemplateScript.js
//z9A2tcZCFD
Aria.tplScriptDefinition({$classpath:"apps.guide.main.search.SearchBoxListTemplateScript",$constructor:function(){this._itemShift=0},$prototype:{itemClick:function(a){if(!this.data.disabled)(a=a.target.getExpando("itemIdx",true))&&this.moduleCtrl.itemClick(a)},prettifyPath:function(a){return a.replace(/\./g," - ")},basicEllipsis:function(a,b){return a.length<b?a:a.substring(0,b)+"&hellip;"}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/sidebar/DocumentationSidebar.js
//z9A2tcZCFD
Aria.classDefinition({$classpath:"apps.guide.main.sidebar.DocumentationSidebar",$extends:"apps.guide.main.sidebar.SidebarModule",$implements:["apps.guide.main.sidebar.ISidebarModule"],$dependencies:["apps.guide.main.dataModel.SidebarBean","aria.utils.Array"],$prototype:{$publicInterfaceName:"apps.guide.main.sidebar.ISidebarModule",update:function(d){d=this.__updateDocumentationSidebar(d);aria.core.JsonValidator.normalize({json:d,beanName:"apps.guide.main.dataModel.SidebarBean.Sidebar"})||this.$logError("Invalid sidebar configuration");
this.setData({sidebar:d,contentType:"Documentation"})},__updateDocumentationSidebar:function(d){var f=this.initializeSidebar();this.__extractDocRelatedDoc(d,f);this.__extractDocRelatedSamples(d,f);this.__extractDocRelatedApidocs(d,f);return f},__extractDocRelatedDoc:function(d,f){var e=/doc=([^,"']*)[,'"]{1}/g,i=d.pageContent,c=d.selectedItem.replace(/#.*$/,""),a=aria.utils.Array,b,g=f.relatedDocs.items,h=["index"];b=0;for(var j=g.length;b<j;b++)h.push(g[b].value);for(;(b=e.exec(i))!=null;)if(b[1]!=
c&&!a.contains(h,b[1])){h.push(b[1]);g.push(this.formatRelatedContent(b[1],"doc"))}for(e=/startRelatedDocs\=([^=]*)\=endRelatedDocs/g;(b=e.exec(i))!=null;){b=b[1].split(/\s*,\s*/);for(var k=0,l=b.length;k<l;k++)if((j=b[k])&&j!=c&&!a.contains(h,j)){h.push(j);g.push(this.formatRelatedContent(j,"doc"))}}},__extractDocRelatedSamples:function(d,f){var e=/(tpl|spl)=([^,"']*)[,'"]{1}/g,i=d.pageContent,c;c=f.relatedSamples.items;for(var a=[],b=0,g=c.length;b<g;b++)a.push(c[b].value);for(;(c=e.exec(i))!=null;)a=
this.__insertSampleWhereNeeded(this.getPackageNameFromTemplate(c[2]),a);for(e=/startRelatedSamples\=([^=]*)\=endRelatedSamples/g;(c=e.exec(i))!=null;)if(c[1]){b=c[1].split(/\s*,\s*/);var h=0;for(c=b.length;h<c;h++){g=b[h];g=this.getPackageNameFromTemplate(g);a=this.__insertSampleWhereNeeded(g,a)}}f.relatedSamples.items=[];c=a.length;for(e=0;e<c;e++)f.relatedSamples.items.push(this.formatRelatedContent(a[e],"spl"))},__insertSampleWhereNeeded:function(d,f){for(var e=[],i=0,c=f.length,a=true;i<c;i++)if(f[i].indexOf(d)==
-1){e.push(f[i]);if(d.indexOf(f[i])!=-1)a=false}a&&e.push(d);return e},__extractDocRelatedApidocs:function(d,f){var e=/apidocs\/#([^,"']*)[,'"]{1}/g,i=d.pageContent,c=aria.utils.Array,a,b=f.relatedApidocs.items,g=[];a=0;for(var h=b.length;a<h;a++)g.push(b[a].value);for(;(a=e.exec(i))!=null;)if(!c.contains(g,a[1])){g.push(a[1]);b.push(this.formatRelatedContent(a[1],"APIdocs"))}for(e=/startRelatedAPIdocs\=([^=]*)\=endRelatedAPIdocs/g;(a=e.exec(i))!=null;){a=a[1].split(/\s*,\s*/);for(var j=0,k=a.length;j<
k;j++)if((h=a[j])&&!c.contains(g,h)){g.push(h);b.push(this.formatRelatedContent(h,"APIdocs"))}}}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/sidebar/ISidebarModule.js
//z9A2tcZCFD
Aria.interfaceDefinition({$classpath:"apps.guide.main.sidebar.ISidebarModule",$extends:"aria.templates.IModuleCtrl",$events:{selectedItemChanged:{description:"Raised when the item selected in the side bar changes.",properties:{type:"type of the selected resource",path:"path of the selected resource",sourceFileType:"type of the source file. Only used when resType is 'Source'."}},updateExtra:{description:"Raised when the portion of the datamodel containing 'extra' information is automatically generated.",
properties:{packageName:"Name of the sample item.",extra:"Extra information"}}},$interface:{update:"Function",select:"Function",setSidebarFillingHeight:"Function"}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/sidebar/SampleSidebar.js
//z9A2tcZCFD
Aria.classDefinition({$classpath:"apps.guide.main.sidebar.SampleSidebar",$extends:"apps.guide.main.sidebar.SidebarModule",$implements:["apps.guide.main.sidebar.ISidebarModule"],$dependencies:["aria.core.Cache","aria.utils.Array","aria.utils.Type","apps.guide.main.library.Dependencies","apps.guide.main.dataModel.SidebarBean"],$constructor:function(){this.$SidebarModule.constructor.call(this);this.matchTemplateWidget=apps.guide.main.library.Dependencies.matchTemplateWidget},$prototype:{$publicInterfaceName:"apps.guide.main.sidebar.ISidebarModule",
__cache:{},update:function(a){var d=this.__updateSampleSidebar(a);aria.core.JsonValidator.normalize({json:d,beanName:"apps.guide.main.dataModel.SidebarBean.Sidebar"})||this.$logError("Invalid sidebar configuration");this.setData({sidebar:d,contentType:this.__samplesUtils.getSampleType(a.data.packageName)})},__updateSampleSidebar:function(a){var d=a.data.packageName;if(!d)return this.$logError("Trying to update the sidebar for an undefined packageName");var c=null;if(this.__cache[d])c=a.data.extra;
else{c=this.__populate(d,a);this.__cache[d]=true}return c},__populate:function(a,d){var c=d.data,b=c.location,f=[],e=[];if(b){var g=this.__extractMainRoles(b,f);if(c.extra)if(c.extra.sourceFiles)c.extra.sourceFiles.items=c.extra.sourceFiles.items?g.concat(c.extra.sourceFiles.items):g;else c.extra.sourceFiles={items:g};else c.extra={sourceFiles:{items:g}};if(b.templateClasspath){this.__extractDependencies(b.templateClasspath,f,e);this.__extractSubTemplateDependencies([b.templateClasspath],f,e)}b.moduleCtrlClasspath&&
this.__extractDependencies(b.moduleCtrlClasspath,f,e);b.dataClasspath&&this.__extractDependencies(b.dataClasspath,f,e)}c=this.initializeSidebar(d.data.extra);if(b){b=g.length;for(g=f.length;b<g;b+=1){var h=aria.core.Cache.getItem("classes",f[b]);c.sourceFiles.items.push(this.formatRelatedContent(f[b],"Source",h?h.content:null))}b=0;for(g=e.length;b<g;b+=1)c.relatedApidocs.items.push(this.formatRelatedContent(e[b],"APIdocs"))}this.$raiseEvent({name:"updateExtra",packageName:a,extra:c});return c},__possibleDependencies:["$dependencies",
"$extends","$templates","$css","$macrolibs","$texts","$resources","$implements"],__extractDependencies:function(a,d,c){if(aria.utils.Type.isObject(a))a=aria.utils.Array.extractValuesFromMap(a);aria.utils.Type.isArray(a)||(a=[a]);for(var b=0,f=a.length;b<f;b+=1){var e=a[b];if(e.indexOf("aria.")!==0)if(e=Aria.nspace(e,false)){e=e.classDefinition||e.interfaceDefinition;for(var g=0,h=this.__possibleDependencies.length;g<h;g+=1){var i=e[this.__possibleDependencies[g]];if(i){this.__putInTheCorrectContainer(i,
d,c);this.__extractDependencies(i,d,c)}}}else aria.core.JsonValidator.__loadedBeans[a[b]]||this.$logError("Can't find the classdefinition for "+a[b])}},__extractSubTemplateDependencies:function(a,d,c){for(var b=[],f=0,e=a.length;f<e;f+=1){var g=aria.core.Cache.getItem("files",a[f].replace(/\./g,"/")+".tpl");if(!g)return this.$logError("Couldn't find the cache item for "+a[f]);g=this.matchTemplateWidget(g.value);for(var h=0,i=g.length;h<i;h+=1){var j=g[h];this.__putInTheCorrectContainer(j,d,c);this.__extractDependencies(j,
d,c);aria.utils.Array.contains(b,j)||b.push(j)}if(g=Aria.nspace(a[f],false)){g=g.classDefinition;if(g.$templates)b=g.$templates.concat(b)}else this.$logError("Can't find the classdefinition for "+a[f])}b.length&&this.__extractSubTemplateDependencies(b,d,c)},__putInTheCorrectContainer:function(a,d,c){if(a){if(aria.utils.Type.isObject(a))a=aria.utils.Array.extractValuesFromMap(a);aria.utils.Type.isArray(a)||(a=[a]);for(var b=0,f=a.length;b<f;b+=1){var e=a[b];if(e.indexOf("aria.")===0){if(e.indexOf("aria.widgets.")===
0)e="aria.widgets.CfgBeans";aria.utils.Array.contains(c,e)||c.push(e)}else aria.utils.Array.contains(d,e)||d.push(e)}}},__extractMainRoles:function(a,d){var c=[],b=null;if(a.templateClasspath){c.push({value:a.templateClasspath,type:"TPL",role:"Template"});d.push(a.templateClasspath);if(b=Aria.nspace(a.templateClasspath,false))b=b.classDefinition;else this.$logError("Can't find the classdefinition for "+a.templateClasspath);if(b.$dependencies&&aria.utils.Array.contains(b.$dependencies,a.templateClasspath+
"Script")){c.push({value:a.templateClasspath+"Script",type:"JS",role:"Script"});d.push(a.templateClasspath+"Script")}}if(a.moduleCtrlClasspath){c.push({value:a.moduleCtrlClasspath,type:"JS",role:"ModuleCtrl"});d.push(a.moduleCtrlClasspath)}if(a.dataClasspath){c.push({value:a.dataClasspath,type:"JS",role:"Data"});d.push(a.dataClasspath)}if(b)if(b.$css){b=b.$css;for(var f=0,e=b.length;f<e;f++){c.push({value:b[f],type:"CSS",role:"CSS"});d.push(b[f])}}return c}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/sidebar/SidebarModule.js
//z9A2tcZCFD
Aria.classDefinition({$classpath:"apps.guide.main.sidebar.SidebarModule",$extends:"aria.templates.ModuleCtrl",$dependencies:["aria.utils.Dom","apps.guide.main.dataModel.SamplesUtils"],$constructor:function(){this.$ModuleCtrl.constructor.call(this);this.__samplesUtils=apps.guide.main.dataModel.SamplesUtils},$prototype:{SUFFIXES_MAP:{JS:".js",TPL:".tpl",RES:".js",CSS:".tpl.css",TML:".tml",TXT:".tpl.txt"},initializeSidebar:function(a){a={sourceFiles:{text:"Source Files",collapsed:false,items:a&&a.sourceFiles&&
a.sourceFiles.items?a.sourceFiles.items:[],type:"Source"},relatedSamples:{text:"Related Samples",collapsed:false,items:a&&a.relatedSamples&&a.relatedSamples.items?a.relatedSamples.items:[],type:"spl"},relatedDocs:{text:"Related Docs",collapsed:false,items:a&&a.relatedDocs&&a.relatedDocs.items?a.relatedDocs.items:[],type:"doc"},relatedApidocs:{text:"API Docs",collapsed:false,items:a&&a.relatedApidocs&&a.relatedApidocs.items?a.relatedApidocs.items:[],type:"APIdocs"}};this.__setMissingLabelsFromValues(a);
return a},select:function(a){var b=a.type?a.type:"",c=a.value?a.value:"";if(b)this.$raiseEvent({name:"selectedItemChanged",type:b,path:c,sourceFileType:a.sourceFileType?a.sourceFileType:null})},formatRelatedContent:function(a,b,c,d){switch(b){case "Source":b=a.split(".");b=c?b[b.length-1]+this.SUFFIXES_MAP[c]:b[b.length-1];b=this.__applyEllipsis(b,35,"c");return{label:b,value:a,type:c?c:null,role:d?d:null};case "APIdocs":b=this.__applyEllipsis(a,35,"l");return{label:b,value:a};case "doc":b=a.replace(/#.*$/g,
"");b=b.replace(/_/g," ");return{label:b,value:a};case "spl":b=a.replace(/\./g,"-");return{label:this.__applyEllipsis(b,35,"c"),value:a};default:return{label:a,value:a}}},getPackageNameFromTemplate:function(a){return this.__samplesUtils.getPackageName(a)},__setMissingLabelsFromValues:function(a){for(var b in a)if(a.hasOwnProperty(b))for(var c=a[b].items,d=0,f=c.length;d<f;d++){var e=c[d];if(!e.label){var g=a[b].type=="spl"?this.getPackageNameFromTemplate(e.value):e.value;c[d]=this.formatRelatedContent(g,
a[b].type,e.type,e.role)}}},setSidebarFillingHeight:function(){var a=aria.utils.Dom,b=a.getElementById("sidebarFilling");if(b){var c=a.calculatePosition(b),d=a.getElementById("at-main");a=a.getGeometry(d);b.style.height=Math.max(a.height,d.scrollHeight)-c.top-5+"px"}},__applyEllipsis:function(a,b,c){if(b<3)return"";if(a.length<=b)return a;switch(c){case "r":return a.slice(0,b-3)+"...";case "l":return"..."+a.slice(a.length-b+3);default:c=Math.floor(b/2)-1;return a.slice(0,c)+"..."+a.slice(a.length-
b+c+3)}}}});
//z9A2tcZCFD
//LOGICAL-PATH:apps/guide/main/sidebar/SidebarTemplateScript.js
//z9A2tcZCFD
Aria.tplScriptDefinition({$classpath:"apps.guide.main.sidebar.SidebarTemplateScript",$prototype:{$afterRefresh:function(){this.moduleCtrl.setSidebarFillingHeight()},triggerBlockDisplay:function(a,b){aria.utils.Json.setValue(b,"collapsed",!b.collapsed)},select:function(a,b){this.moduleCtrl.select(b)},getRoleColor:function(a){switch(a){case "Template":return"#aaaaaa";case "Script":return"#a5ca39";case "CSS":return"#e79a55";case "ModuleCtrl":return"#9a678c";case "Data":return"#379fd0"}},getSourceFilesRoles:function(){var a=
this.data.sidebar.sourceFiles.items,b=[],c;for(c in a)a[c].role&&b.push(a[c].role);return b},splitMainAndSecondarySourceFiles:function(a){for(var b={main:[],secondary:[]},c=0,d=a.length;c<d;c++)a[c].role?b.main.push(a[c]):b.secondary.push(a[c]);return b}}});