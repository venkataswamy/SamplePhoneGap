/*
 * Copyright Amadeus
 */
aria.core.DownloadMgr.updateUrlMap({"apps": {"apidocs":     {
        "utils": {"*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js"},
        "controller": {"*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js"},
        "modules":         {
            "resources": {"*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js"},
            "bean":             {
                "*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js",
                "view":                 {
                    "container": {"*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js"},
                    "item": {"*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js"},
                    "list": {"*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js"}
                }
            },
            "classDocumentor":             {
                "*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js",
                "view": {"*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js"}
            },
            "documents":             {
                "*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js",
                "view": {"*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js"}
            },
            "packageExplorer":             {
                "apidocsAutocomplete":                 {
                    "*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js",
                    "parsers": {"*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js"}
                },
                "*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js",
                "view": {"*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js"}
            }
        },
        "main":         {
            "*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js",
            "view": {"*": "apps/apidocs/apidocs_6d7c35ca67e4f7a09be78c2f8bf80546.js"}
        }
    }}});