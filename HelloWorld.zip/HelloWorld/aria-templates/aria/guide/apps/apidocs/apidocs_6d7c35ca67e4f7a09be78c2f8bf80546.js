/*
 * Copyright Amadeus
 */
//***MULTI-PART
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/main/view/Main.tpl
//NxFOn9Dh1D
// Main template of documentation center
{Template {
	$classpath : 'apps.apidocs.main.view.Main',
	$dependencies : [],
	$hasScript : true,
	$css : ["apps.apidocs.main.view.MainStyle"],
	$width : {"min" : 548},
	$height : {"min" : 300}
} }
	{macro main ( )}
		{call displayPackageExplorer()/}
		{if _hasDocuments()}
			{call displayDocuments()/}
		{else/}
			<div class="noDocument"></div>
		{/if}
	{/macro}
	{macro displayPackageExplorer()}
		<div class="layoutDiv">
			<div class="borderDiv" style="height:${$vdim(288,1)}px">
				{@aria:Template {
					width : 300,
					height : $vdim(288,1),
					defaultTemplate : 'apps.apidocs.modules.packageExplorer.view.PackageTreeDisplay',
					moduleCtrl : moduleCtrl.packages,
					margins : "0 0 0 0" }/}
			</div>
		</div>
	{/macro}
	{macro displayDocuments()}
		<div class="layoutDiv">
			<div class="borderDiv" style="height:${$vdim(288,1)}px">	
			{@aria:Template {
				width : $hdim(this._getContentWidth(),1),
				height : $vdim(290,1),
				defaultTemplate : 'apps.apidocs.modules.documents.view.DocumentsDisplay',
				moduleCtrl : moduleCtrl.documents
			}/}
			</div>
		</div>
	{/macro}
{/Template}
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/bean/view/container/BeanContainer.tpl
//NxFOn9Dh1D
// TODOC
{Template {
	$classpath : "apps.apidocs.modules.bean.view.container.BeanContainer",
	$hasScript : true,
	$css : [
		'apps.apidocs.modules.bean.view.container.BeanContainerStyle',
		'apps.apidocs.modules.documents.view.BaseDocumentorStyle'
	],
	$height : {min:298},
	$width : {min:298}
}}
	{macro main ( )}
		{call displayHeader()/}

		<div style="clear:both"></div>
		<div class="documentContainer" style="
			height:${$vdim(243,1)}px;
			width:${$hdim(298,1)}px;
			overflow:hidden;
			">
		{if (data.beans)}
			{call displayBeanList()/}
			{if aria.core.Browser.isChrome}
				<div style="position:absolute;top:0px;left:201px">
					{call displayBean()/}
				</div>
			{else/}
				{call displayBean()/}
			{/if}

		{else/}
			<div class="error" >
				This Bean is either empty or invalid.
			</div>
		{/if}
		</div>
	{/macro}

	{macro displayBeanList()}
		{@aria:Template {
			width:200,
			height:$vdim(243,1),
			defaultTemplate:"apps.apidocs.modules.bean.view.list.BeanList"
		} /}
	{/macro}

	{macro displayBean()}
		{@aria:Template {
			height:$vdim(243,1),
			width:$hdim(98,1),
			defaultTemplate:"apps.apidocs.modules.bean.view.item.BeanItem"
		} /}
	{/macro}

	{macro displayHeader()}
		<h1>
			<span class="documentType">Beans </span>
			<span class="documentName">${data.classpath}</span>
			{section {
			  id : "expandCollapseAll",
			  macro: "expandCollapseMacro",
			  bindRefreshTo: [{
			    to: "view:action",
			    inside: data,
			    recursive: true
			  }]
			}/}

		</h1>
	{/macro}

	{macro expandCollapseMacro()}
	   <button {id "buttonAll" /} {if (data["view:action"] == "expandall")}
	                                 class="expandall" title="Expand all"
	                              {else/}
	                                 class="collapseall" title="Collapse all"
	                              {/if}
	                              {on click  {
                                        fn: _expandCollapse
                                  }/}>
       </button>
	{/macro}
{/Template}
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/bean/view/item/BeanItem.tpl
//NxFOn9Dh1D
{Template {
	$classpath : "apps.apidocs.modules.bean.view.item.BeanItem",
	$hasScript : true,
	$css : [
		'apps.apidocs.modules.documents.view.BaseDocumentorStyle',
		'apps.apidocs.modules.bean.view.item.BeanItemStyle'
	],
	$height : {min:420},
	$width : {min:98}
}}
	{macro main()}
		{var bean  = this._getSelectedBean()/}
		<div  {id "beanContainer"/} style="
			height:${$vdim(409,1)}px;
			width:${$hdim(98,1)}px;
			overflow:auto;
			position:absolute;
			padding : 1px 0 10px 0px;
			">
			{call displayBean(bean.value, bean.name, 0)/}
		</div>
	{/macro}

	{macro displayBean(bean , propertyName, depth, isLast)}
		{if _isBeanVisible(bean)}
			{var beanClassname = bean.$mandatory ? "mandatory" : "normal" /}
			{set beanClassname = isLast ? beanClassname + " last" : beanClassname /}
			{if this._isBeanBodyEmpty(bean)}
				 <div
	                style="margin-left:${-1*(20+0*20)}px;
	                    padding-left:${40+0*20}px;
	                "
	                class="bean ${beanClassname} singleprop">
            {else /}
				<div
					style="margin-left:${-1*(20+0*20)}px;
						padding-left:${40+0*20}px;
					"
					class="bean ${beanClassname}">
		    {/if}
				{call displayBeanHeader(bean, propertyName, depth)/}
				{if depth == 0 || this._isBeanBodyExpanded(bean)}
				    {if depth == 1}
				       <div class="entry">
				        {call displayBeanBody(bean, depth)/}
				       </div>
				    {else/}
					   {call displayBeanBody(bean, depth)/}
					{/if}
				{/if}
			</div>
		{/if}
	{/macro}

	{macro displayBeanHeader(bean, propertyName, depth)}
			{if this._isBeanBodyEmpty(bean)}
			    <h3>
				${ propertyName }
			{else/}
			    {if depth>0}
					{if this._isBeanBodyExpanded(bean)}
						<a class="minus" {on click  {
							fn: _onToggleBeanBodyClick,
							args: bean
						}/}></a>
						<h3>
						<a {on click  {
                            fn: _onToggleBeanBodyClick,
                            args: bean
                        }/}>
							${ propertyName }
						</a>
					{else/}
					    <a class="plus" {on click  {
	                        fn: _onToggleBeanBodyClick,
	                        args: bean
	                    }/}></a>
	                    <h3>
	                    <a {on click  {
                            fn: _onToggleBeanBodyClick,
                            args: bean
                        }/}>
	                        ${ propertyName }
	                    </a>
					{/if}
			    {else/}
                    <a {on click  {
                            fn: _onToggleBeanBodyClick,
                            args: bean
                    }/}></a>
                    <h3>
                    <a {on click  {
                            fn: _onToggleBeanBodyClick,
                            args: bean
                        }/}>${ propertyName }
                    </a>
                {/if}
			{/if}
			: {call displayBeanLink(bean.$type)/}
		</h3>
		{call displayDetail("", bean.$description)/}
		{call displayCode("Default value", bean.$default)/}
	{/macro}

	{macro displayBeanBody(bean, depth)}
		{call displayMultitypes(bean.$contentTypes, depth) /}
		{call displayCode("Sample", bean.$sample)/}
		{call displayEnumValues(bean.$enumValues)/}
		{call displayKeyType(bean.$keyType) /}
		{call displayContentType(bean.$contentType) /}
	    {call displayProperties(bean.$properties, depth) /}
	{/macro}

	{macro displayBeanLink(type)}
		{if ( type.indexOf(":")==-1 )}
			{var href="#"+this.getClasspathFromHash()+":"+type/}
		{else/}
			{var href="#"+this._getClasspathFromNamespace(type.substring(0, type.indexOf(":")))+":"+type.substring(type.indexOf(":")+1)/}
		{/if}
		<span class="type" style="font-weight:normal;">
			<a
				href="${href}"
				{on click {
					fn : this._onBeanClick,
					scope : this,
					args : type
				}/}
			>
				${type}
			</a>
		</span>
	{/macro}
	{macro displayDetail(name, textContent, isCode)}
		{if textContent}
			{var textContent = !!isCode ? _transformDetailContent(textContent) : textContent/}
			<div class="detail">
				{if name}
					<span class="title">${name} : ${textContent}</span>
				{else/}
					${textContent}
				{/if}

			</div>
		{/if}
	{/macro}

	{macro displayCode(name, textContent)}
		{call displayDetail(name, textContent, true)/}
	{/macro}

	{macro displayKeyType(keyType)}
		{if keyType}
		<div class="detail">
			<span class="title">Key Type</span> : {call displayBeanLink(keyType.$type)/}
			{call displayDetail("", keyType.$description)/}
		</div>
		{/if}
	{/macro}

	{macro displayContentType(contentType)}
		{if contentType}
		<div class="detail">
			<span class="title">Content Type</span> : {call displayBeanLink(contentType.$type)/}
			{call displayDetail("",contentType.$description)/}
		</div>
		{/if}
	{/macro}

	{macro displayEnumValues(enumValues)}
		{if enumValues}
		<div class="detail">
			<span class="title">Possible values</span> :
			{foreach value in enumValues}
				${this._transformDetailContent(value)}
				{if value_index != enumValues.length - 1}, {/if}
			{/foreach}
		</div>
		{/if}
	{/macro}

	{macro displayMultitypes(contentTypes, depth)}
		{if contentTypes}
		  {if depth>0}
             {var className = "detail nested properties"/}
          {else /}
             {var className = "detail nested"/}
          {/if}
			<div class="${className}">
				<span class="title">Content Types</span>
					{foreach contentType in contentTypes}
						{var isLast=apps.apidocs.utils.Common.isLastKey(contentTypes, contentType_index)/}
						{call displayBean ( contentType , contentType.$type, depth+1, isLast) /}
					{/foreach}
			</div>
		{/if}
	{/macro}

	{macro displayProperties(properties, depth)}
		{if properties}
		    {if depth>0}
			 {var className = "detail nested properties"/}
			{else /}
			 {var className = "detail nested"/}
			{/if}
			<div class="${className}">
				<span class="title">Properties</span>
					{var uniqueView = this._createUniqueView(properties)/}
					{foreach property inSortedView uniqueView}
						{var isLast=apps.apidocs.utils.Common.isLastKey(properties, property_info.initIndex)/}
						{call displayBean ( property , property_info.initIndex, depth+1, isLast) /}
					{/foreach}
			</div>
		{/if}
	{/macro}
{/Template}
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/bean/view/list/BeanList.tpl
//NxFOn9Dh1D
// TODOC
{Template {
	$classpath : "apps.apidocs.modules.bean.view.list.BeanList",
	$hasScript : true,
	$css : ['apps.apidocs.modules.bean.view.list.BeanListStyle'],
	$height : {min:420},
	$width : {value : 200}
}}
	{var height = 420/}
	{var width = 200/}
	{macro main()}
		{var beansArray = this.getBeansArrayFromMap(data.beans)/}
        {createView beansView on beansArray/}
        ${this._initView(beansView)}
		<div id="beanList" style="
			height:${$vdim(height)}px;
			width:${$hdim(width-1)}px;"
		>
        <ul>
			{foreach beanItem inSortedView beansView}
				{var bean = beanItem.value/}
				{var isSelected = !!bean["view:selected"]/}
				{var liClassname=isSelected ? "selected" : ""/}
				<li class="${liClassname}"
					//title="${beanItem.key}"
					{on click {
						fn : this.__onItemClick,
						scope : this,
						args : [this.getClasspathFromHash() + ":" + beanItem.key, beanItem.key]
					}/}
				>
					<a
						{id "_bean_hook_"+beanItem.key/}
						href="#${this.getClasspathFromHash()}:${beanItem.key}">
							${beanItem.key}
					</a>
				</li>
			{/foreach}
		</ul>
		</div>
	{/macro}
{/Template}
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/classDocumentor/view/ClassDocumentor.tpl
//NxFOn9Dh1D
// Main root template for the Command Page
{Template {
	$classpath : "apps.apidocs.modules.classDocumentor.view.ClassDocumentor",
	$hasScript : true,
	$extends : "apps.apidocs.modules.documents.view.BaseDocumentor",
	$css : [
		'apps.apidocs.modules.classDocumentor.view.ClassDocumentorStyle',
		'apps.apidocs.modules.documents.view.BaseDocumentorStyle',
		'apps.apidocs.modules.documents.view.MethodStyle'

	],
	$height : {min:150}
}}
	{macro main(type)}
		<div id="classDescription">
			{call displayDocumentHeader(type, data.classpath)/}
			<div style="height:${$vdim(95,1)}px;" {id "documentContainer"/} class="documentContainer">
				{if data.classDescription}
					<div class="extras">
						${data.classDescription}
					</div>
				{/if}

				{call displayExtraInfo(data.classExtends, 'Extends', 'ClassDefinition')/}
				{call displayExtraInfo(data.classImplements, 'Implements', 'InterfaceDefinition')/}
				{call displayExtraInfo(data.dependsOn, 'Depends on', 'ClassDefinition')/}
				{call displayExtraInfo(data.extendedBy, 'Extended by', 'ClassDefinition')/}
				{call displayExtraInfo(data.dependedBy, 'Used by', 'ClassDefinition')/}

				{call displayMethodSection(data.classMethods, "public")/}
				{call displayMethodSection(data.protectedMethods, "protected")/}
				{call displayMethodSection(data.privateMethods, "private")/}

				{call displayEventsSection(data.events)/}

				{call displayPropertySection(data.publicProperties, "public")/}
				{call displayPropertySection(data.protectedProperties, "protected")/}
				{call displayPropertySection(data.privateProperties, "private")/}
				<div class="last"></div>
			</div>
		</div>
	{/macro}

	{macro displayEventsSection(events)}
		{if !isObjectEmpty(events)}
			<div class="publicSection">
	        	<h2>Events</h2>
	        	<ul>
					{call displayEvents(events)/}
				</ul>
			</div>
		{/if}
	{/macro}

	{macro displayMethodSection(methods, visibility)}
		{if (!isObjectEmpty(methods) && apps.apidocs.utils.Common.isVisibilityLevelEnabled(visibility))}
			<div class="publicSection">
	        	<h2>${toCamelCase(visibility)} Methods</h2>
	        	<ul>
					{call displayMethods(methods)/}
				</ul>
			</div>
		{/if}
	{/macro}

	{macro displayPropertySection(properties, visibility)}
		{if (
			!isObjectEmpty(properties) &&
			apps.apidocs.utils.Common.isVisibilityLevelEnabled(visibility)
		)}
			<div class="publicSection">
	        	<h2>${toCamelCase(visibility)} Properties</h2>
	        	<ul>
					{call displayProperties(properties)/}
				</ul>
			</div>
		{/if}
	{/macro}

	{macro displayExtraInfo(array, label, type)}
		{var MAX_LIST = 3 /}
		{if array && array.length }
			<p class="extras"><label>${label}:</label><br/>
			<ul style="clear:both;">
				{var count = 0 /}
				{foreach item inArray array}
					{set count = count + 1 /}
					{if item_index < MAX_LIST || !data.showMore}
						<li>
							{if (isClasspathValid(item))}
								<a href='#${item}'
									{on click {
										fn:contentClick,
										args:{ classpath : item, type : type }
									}/}
									title="Navigate to ${item}"
								>${item}</a>
							{elseif (isAriaClasspath(item))/}
								<a
									class="externalItem"
									href="?#${item}"
									title="External documentation : open in new window"
									rel="external"
									target="_blank">${item}</a>
							{else/}
								<span
									class="invalidItem"
									title="Documentation for ${item} is unavailable in this package">
										${item}</span>
							{/if}
						</li>
					{/if}
				{/foreach}
				{if count > MAX_LIST && data.showMore}
					<li
						{on click { fn:showMore }/}
						class="showAll">
						show all
					</li>
				{/if}
			</ul>
		{/if}
	{/macro}
{/Template}
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/documents/view/BaseDocumentor.tpl
//NxFOn9Dh1D
// Main root template for the Command Page
{Template {
	$classpath : 'apps.apidocs.modules.documents.view.BaseDocumentor',
	$hasScript : true,
	$css : ['apps.apidocs.modules.documents.view.BaseDocumentorStyle']
}}
	{macro main()}{/macro}
	
	{macro displayMethods(methods)}
		<div {on click _onToggleItemClick/}>
		{foreach method in methods}
			{call displayMethod(method, method_index)/}
		{/foreach}
		</div>
	{/macro}
	
	{macro displayMethod(method, name)}
		{var type="method"/}
		{var isHighlighted = this.isItemHighlighted(name, type)/}
		{var isExpanded = this.isItemExpanded(name, type)/}
		{var containerClassname = isHighlighted ? "highlighted" : ""/}
		{var expandedClassname = isExpanded ? "expanded" : "collapsed"/}
		<li 
			class="aPublicMethod ${containerClassname} ${expandedClassname}" 
			id="_methodhook_${name}:${type}">
			{call displayToggle(name, type)/}
			{call displayMethodTitle(method, name)/}
			{call displayMethodDescription(method, name)/}
			{if isExpanded}
				{call displayMethodDetails(method, name)/}
			{/if}
		</li>
	{/macro}
	
	{macro displayToggle(itemName, itemType)}
		{var itemId = itemName + ":" + itemType/}
		<div class="toggleItem" _toggleItem="${itemId}">
			<div class="arrow" _toggleItem="${itemId}"></div>
		</div>
	{/macro}
	
	{macro displayMethodTitle(method, name)}
		{var classpath = this.getClasspathFromHash()/}
		<h3 class="methodTitle">
		<a class="methodLink" 
			href="#${classpath}:${name}:method">
			${name}
			<span>
				(
				{var parameterString=""/}
				{foreach parameter in method.commentParams}
					{separator}, {/separator}
					{var type = parameter.type ? parameter.type + " " : ""/}
					<span class="parameterType">${type}</span>
					<span class="parameterName">${parameter_index}</span>
				{/foreach}
				)
				{if method.commentReturn && method.commentReturn.type}
					: <span class="returnType">${method.commentReturn.type}</span>
				{/if}
			</span>
			</a>
		</h3>
	{/macro}
	
	{macro displayMethodDescription(method, name)}
		{if method.isStatic}
			<p class="jstag">@static</p>
		{/if}
		{if method.description}
			<div class="descriptionWrapper">
				<p class="description">${method.description}</p>
			</div>
		{/if}
	{/macro}
	
	{macro displayMethodDetails(method, name)}
		{if method.example}
			<div class="methodDetail">
				<span class="methodDetailTitle">Example :</span>
				<div class="methodDetailContent">
					<p class="description">${method.example}</p>
				</div>
			</div>
		{/if}
		{if hasParameters(method)}
			<div class="methodDetail">
				<span class="methodDetailTitle">Parameters</span>
				<ul class="parametersList methodDetailContent">
					{foreach parameter in method.commentParams}
						<li class="parameter">
							<span class="parameterName">${parameter_index}</span>
							{if parameter.type}
					    		<span class="parameterType">: ${parameter.type}</span>
					    	{/if}
						    {if parameter.desc != null}
						    	<p class="parameterDescription">${parameter.desc}</p>
						    {/if}
						</li>
					{/foreach}
				</ul>
			</div>
			{/if}
			{if method.commentReturn && method.commentReturn.type}
				<div class="methodDetail">
					<span class="methodDetailTitle">Returns <span class="returnType">: ${method.commentReturn.type}</span></span> 
					{if method.commentReturn.desc}
						<div class="methodDetailContent">
							<p>${method.commentReturn.desc}</p>
						</div>
					{/if}
				</div>
			{/if}
	{/macro}

	{macro displayProperties(properties)}
		{var classpath = this.getClasspathFromHash()/}
		{var type="property"/}
		{foreach property in properties}
			{var isHighlighted = this.isItemHighlighted(property_index, type)/}
			{var containerClassname = isHighlighted ? "highlighted" : ""/}
			<li class="aPublicMethod ${containerClassname}" id="_methodhook_${property_index}:${type}">
				<h3><a class="methodLink" href="#${classpath}:${property_index}:${type}">
				${property_index}
				{if property.returns.type} 
					<span> : ${property.returns.type}</span>
				{/if}
				</a>
				</h3>
				{if property.isStatic}
					<p class="jstag">@static</p>
				{/if}
				{if property.desc}
					<p class="description">${property.desc}</p>
				{/if}
			</li>
		{/foreach}
	{/macro}
	
	{macro displayEvents(events)}
		{var classpath = this.getClasspathFromHash()/}
		{var type="event"/}
		{foreach event in events}
			{var isHighlighted = this.isItemHighlighted(event_index, type)/}
			{var containerClassname = isHighlighted ? "highlighted" : ""/}
			<li class="aPublicMethod ${containerClassname}" id="_methodhook_${event_index}:${type}">
				<h3><a class="methodLink" href="#${classpath}:${event_index}:${type}">
				${event_index}
				</a>
				</h3>
				{if event.description}
					<p class="description">${event.description}</p>
			    {else/}
			    	<strong style="color: red;">Description Missing</strong>
			    {/if}
				{if event.properties}
				    <ul class="parameterDetails">
  						{foreach property in event.properties}
  							<li>
  							    <p class="paramNameAndType">
  							    	<strong>${property_index}</strong>
  							    	{if property.type}
  							    		: ${property.type}
  							    	{/if}
  							    </p>
  							    {if property.description}
  							    	<p>${property.description}</p>
  							    {else/}
  							    	<strong style="color: red;">Description Missing</strong>
  							    {/if}
  							</li>
  						{/foreach}
  					</ul>
				{/if}
			</li>
		{/foreach}
	{/macro}

	{macro displayDocumentHeader(type, classpath)}
		<h1>
			<span class="documentType">${type} </span>
			<span class="documentName">${classpath}</span> 
			<div
				class="optionContainer"
				{on click {
					fn : this._onShowInternalsClick,
					scope :this
				}/}
			>
				<div class="outerOption">
					<div class="innerOption ${_isInternalsOn()?'selected':'unselected'}"></div>
				</div>
				<span>
					Show internals
				</span>
			</div>
			{var types = ['methods', 'events', 'properties']/}
			<div class="quickcardContainer">
				{foreach type in types}
					{call displayQuickcard(type)/}					
				{/foreach}
			</div>			
		</h1>
	{/macro}
	
	{macro displayQuickcard(type)}
		{var items = this.__getQuickcardItems(type)/}
		{if items.length}
			{section {
				id: "quickcard_" + type,
	  			bindRefreshTo : [{
				   inside : data,
				   to : 'quickcard:selectedType'
	  			}],
	  			type:"div"
			}}
			{var isSelected = data['quickcard:selectedType'] == type/}
			{var className = "quickcard" + (isSelected ? " selected" : "")/}
			<div class="${className}" 
			{on mouseenter __onMouseEnter/}
			{on mouseleave __onMouseLeave/}
			_qcType="${type}">
				<span _qcType="${type}" style="float:left">
					${type}<sup _qcType="${type}">&nbsp;${items.length}</sup>
				</span>
				
				<div _qcType="${type}" class="downArrow"></div>
					{if isSelected}
					<div 
						_qcType="${type}"
						class="quickcardContent"
					>
						{call displayQuickcardContent (items, type)/}
					</div>
					{/if}
			</div>
			{/section}
		{/if}
	{/macro}
	
	{macro displayQuickcardContent(items, type)}
		{var classpath = this.getClasspathFromHash()/}
		<ul>
		{foreach item in items}
			<li>
				<a {on click _onQuickcardItemClick/}
					href="${_getElementHref(classpath, item, type)}"
					_href="${_getElementHref(classpath, item, type)}"
				>${item}</a>
			</li>
		{/foreach}
		</ul>
	{/macro}
{/Template}

//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/documents/view/DocumentsDisplay.tpl
//NxFOn9Dh1D
// TODOC
{Template {
	$classpath : "apps.apidocs.modules.documents.view.DocumentsDisplay",
	$hasScript : true,
	$width : {"min":200},
	$height : {"min":200},
	$css : ['apps.apidocs.modules.documents.view.DocumentsDisplayStyle']
}}
	{var initDone = initDefaultValues()/}

	{macro main()}
		// content of the documentation	
			{foreach document in data}
				{if (data[document_index]["view:selected"])}
					{var template = typesAssociation[document.type] /}
					{if template}
						{@aria:Template {
							defaultTemplate:template,
							data: data[document_index],
							margins:"0 0 0 0",
							height:$vdim(198,1),
							args : [typesDisplayName[document.type]],
							width:$hdim(200,1)						
						}/}
					{else/}
						${document.type} not supported...
					{/if}
				{/if}
			{/foreach}
	{/macro}

{/Template}
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/apidocsAutocomplete/ApidocsAutocompleteList.tpl
//NxFOn9Dh1D
{Template {
	$classpath : 'apps.apidocs.modules.packageExplorer.apidocsAutocomplete.ApidocsAutocompleteList',
	$extends:'aria.widgets.form.list.templates.ListTemplate',
	$css : [
		'apps.apidocs.modules.packageExplorer.apidocsAutocomplete.ApidocsAutocompleteListStyle',
		'apps.apidocs.modules.packageExplorer.view.PackageTreeDisplayStyle'
	],
	$hasScript:true
}}

	{macro main()}
		
		// The Div is used to wrap the items with good looking border.
		{@aria:Div {
				sclass: data.skin.divsclass,
				block: true,
				width: -1,
				height: -1,
					margins: "0 0 0 0"
			}}
				// FIXME: remove me, i'm a hack for minWidth 
				<div style="width: 250px; height:1px;"></div>
				{section 'Items'}
				<table
						{if !data.disabled}
							{on mouseup {fn: "itemClick"} /}
						{/if} 
						class="suggestionsContainer"
						cellpadding="0"
						cellspacing="0"
						style="width:100%"
				>
					<tbody {id "suggestionsRows" /}	>
						{for var i=0;i<data.items.length;i++}
							{call renderItem(data.items[i], i)/}
						{/for}
					</tbody>
				</table>
				{if this._isDisplayLimitReached()}
					<div 
						style="width:100%; height:17px; color:#BBB; text-align:center; padding-right:20px;"
					>Too many suggestions, please refine your search ...&nbsp;</div>
				{/if}
				{/section}
		{/@aria:Div}
	{/macro}

	{macro renderItem(item, itemIdx)}
		<tr class="${_getClassForItem(item)} suggestion"  _itemIdx="${itemIdx}">
			{var suggestion = this.highlightSuggestion(item.object.value, item.object.entry)/}
			<td 
				class="${item.value.type} icon"
			>
				${suggestion.name}
			</td>
			<td>
				${suggestion.path}
			</td>
		</tr>
	{/macro}
{/Template}

//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/view/PackageTreeDisplay.tpl
//NxFOn9Dh1D
// Display packages as a tree
{Template {
    $classpath : 'apps.apidocs.modules.packageExplorer.view.PackageTreeDisplay',
    $dependencies : [
        'apps.apidocs.modules.packageExplorer.apidocsAutocomplete.ApidocsResourcesHandler'
    ],
    $css : ['apps.apidocs.modules.packageExplorer.view.PackageTreeDisplayStyle'],
    $hasScript : true,
    $width : {"value":300},
    $height : {"min":200}
}}

    {var typesTable = [
        {value:'Class',     label:'Show Classes',     disabled:false},
        {value:'Interface', label:'Show Interfaces',  disabled:false},
        //{value:'Resources', label:'Show Resources',   disabled:false},
        {value:'Bean',      label:'Show Beans',       disabled:false},
        {value:'Singleton', label:'Show Singletons',  disabled:false},
        {value:'TplScript', label:'Show TplScripts',  disabled:false}
    ]/}

    {var objectsHandler
        = new apps.apidocs.modules.packageExplorer.apidocsAutocomplete.ApidocsResourcesHandler(this.data.packageTree) /}

    {macro main()}
        <div class="packageFilters">
            {@aria:AutoComplete {
                label:"Search:",
                labelPos:"left",
                labelAlign:"left",
                labelWidth:50,
                width:285,
                autoselect : true,
                resourcesHandler: objectsHandler,
                bind:{ "value" : {inside:data['view:search'],to:'value'} },
                onchange:{
                    fn: _onAutoCompleteChange,
                    scope: this
                }
            }/}
            {@aria:MultiSelect {
                label: "Types:",
                labelWidth:50,
                width:285,
                fieldDisplay: "code",
                fieldSeparator:',',
                valueOrderedByClick: true,
                displayOptions : {
                    flowOrientation:'vertical',
                    listDisplay: "label"
                },
                items:typesTable,
                bind:{value:{to:"view:displayedTypes", inside:data}}
            }/}
        </div>
        {var packageHeight=aria.core.Browser.isIE?101:105/}
        <div style="overflow-y:auto;height:${$vdim(packageHeight,1)}px" {id "packageContainer"/}>
            {section {
                id: "packagetree",
                bindRefreshTo : [{
                   inside : data,
                   to : "view:displayedTypes"
                },{
                   inside : data,
                   to : "view:selectedClasspath"
                }],
                type:"div"
            }}
                {foreach root in data.packageTree}
                    {if apps.apidocs.utils.Common.checkKey(data.packageTree, root_index)} // filter view data
                        {call displayPackage (root_index, root_index, root, 0)/}
                    {/if}
                {/foreach}
                <div class="legendContainer">
                    <div class="legendBorder">
                        <div class="ClassDefinition item">Class</div>
                        <div class="InterfaceDefinition item">Interface</div>
                        <div class="BeanDefinition item">Bean</div>
                        <div class="SingletonDefinition item">Singleton</div>
                        <div class="TplScriptDefinition item">TplScript</div>
                    </div>
                </div>
            {/section}
        </div>
    {/macro}

    {macro displayPackage (name, path, content, depth)}
        {var selectedClasspath = data['view:selectedClasspath'] || ""/}
        {var selectedPackage = selectedClasspath.replace(/\.[a-zA-Z]+?$/, "") /}
        {var isFolderValid = !this.isFolderEmpty(content)/}
        {var isString = aria.utils.Type.isString(content)/}
        {var isDisplayed = (isString && this.isInDisplayedTypes(content))/}
        {var isFolderClosed = !isString && !content["view:selected"]/}
        {var isSelectedParent = selectedClasspath.indexOf(path) == 0/}
        {var hasContent = isFolderValid || isDisplayed/}
        {if hasContent}
            {var style=this._getStyleForDepth(depth)/}
            {var classname="treeNode"/}
            {var selectedId=""/}
            {if selectedClasspath == path}
                {set classname+=" selected"/}
                {set selectedId="id='selectedObject'"/}
            {elseif isFolderClosed && isSelectedParent/}
                {set classname+=" containsSelection"/}
            {/if}
            <div class="${classname}" ${selectedId} style="${style}">
            {if isString}
                {if isDisplayed}
                    <a class="${content}" {on click {
                        fn:contentClick,
                        args:{ classpath : path, type : content }
                    }/}>${name}</a>
                {/if}
            {elseif isFolderValid/}
                {if (content["view:selected"])}
                    <a class="minus" {on click {
                        fn:packageClick,
                        args:content
                    }/}>${name}</a>
                    {foreach element in content}
                        {if apps.apidocs.utils.Common.checkKey(content, element_index)}
                            {call displayPackage(element_index, path + "." + element_index, element, depth+1)/}
                        {/if}
                    {/foreach}
                {else/}
                    <a class="plus" {on click {
                        fn:packageClick,
                        args:content
                    }/}>${name}</a>
                {/if}
            {/if}
            </div>
        {/if}
    {/macro}
{/Template}
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/resources/ResourcesDisplay.tpl
//NxFOn9Dh1D
// TODOC
{Template {
	$classpath : 'apps.apidocs.modules.resources.ResourcesDisplay',
	$hasScript : true,
	$css : ['apps.apidocs.modules.resources.ResourcesDisplayStyle']	
}}

	{var initDone = initDefaultValues()/}
	
	{macro main()}
	
		<div style="margin:5px">
	
			{foreach resource in this.data.resources} 
	
				<h3>${resource_index}</h3>
				<table class="resources" colspan="0" rowspan="0">
					<tr>
						<th>Key</th>
						<th>Value</th>
					</tr>
					{foreach value in resource} 
						{if (value_index)}
							<tr>
								<td>${value_index}</td>
								<td>${value}</td>
							</tr>
						{/if}					
					{/foreach}
				</table>
				
			{/foreach}		
				
		</div>	
	
	{/macro}
	

{/Template}
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/main/view/MainStyle.tpl.css
//NxFOn9Dh1D

{CSSTemplate {
	$classpath : 'apps.apidocs.main.view.MainStyle'
}}

{macro main()}
	.layoutDiv {
		font-family:arial,helvetica,sans-serif;
		font-size : 12px;
		margin:5px 0px 0px 5px;
		float:left;
		padding:0;
	}
	
	.borderDiv {
		margin:0;
		padding:0;
		border:solid 1px #D0D0D0;
		background:white;
	}
	
	.noDocument {
		margin:20px 5px 5px 5px;
		padding:0px;
		float:left;
		color:#D0D0D0;
		font-size: xx-large;
		text-transform: uppercase;
		_width: 0px; /* IE6 hack */
	}
{/macro}
{/CSSTemplate}

//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/bean/view/container/BeanContainerStyle.tpl.css
//NxFOn9Dh1D

{CSSTemplate {
	$classpath : 'apps.apidocs.modules.bean.view.container.BeanContainerStyle'
}}

{macro main()}
	h3 {
		font-size : 1.1em;
	}

	.bean {
		padding-bottom:10px;
	    margin-left: -20px;
	    padding-left: 40px;
		line-height : 20px;
		border-bottom : 1px Solid #bbb;
	}
	.bean .bean{
	    margin-left: -20px;
	    padding-left: 40px;
	}

	.bean.last {
		border-bottom : none;
	}
	.bean .bean.last {
		padding-bottom:0px;
	}

	.bean h3 {
		font-size : 20px;
		margin-top : 10px;
		font-weight : normal;
		margin-bottom : 10px;
	}

	.bean .bean h3 {
		font-size : 1em;
		margin-top : 3px;
		font-weight : bold;
		margin-bottom : 3px;
		display : inline;
	}

	.bean.mandatory {
		color : red;
	}

	div.detail {
		padding-left : 0px;
		color : #000;
	}

	div.detail .detail {
    	padding-left: 30px;
	}

	em.description {
		color : black;
		display : block;
		width : 600px;
	}

	.detail .title {
		font-weight:bold;

		background: none repeat scroll 0 0 #EEEEEE;
	    border-bottom: 1px solid #D0D0D0;
	    border-top: 1px solid #D0D0D0;
	    color: black;
	    display: block;
	    font-size: 16px;
	    margin : 5px 0;
	    padding : 5px 0;
	    margin-left: -20px;
	    padding-left: 35px;
	}

	.detail .detail .title {
		color:#888;
	    display: inline;
	    font-size: 1em;
	    margin : 0;
	    padding : 0;
	    border : none;
	    background : transparent;
	}

	.bean .type {
	}
	.info, .error {
		margin-top: 5px;
		padding: 5px;
		width: auto;
	}

  {var pathToImgFolder = this.cssFolderPath + "/../../../../style/img"/}

	.minus {
	  background: ${"url"}("${pathToImgFolder}/down-arrow.png") -3px 0px no-repeat;
		display: inline-block;
		width: 12px;
		height: 13px;
	}

  .plus {
     background: ${"url"}("${pathToImgFolder}/rt-arrow.png") -5px 0px no-repeat;
     display: inline-block;
     width: 12px;
     height: 13px;
  }

  .expandall {
    background: ${"url"}("${pathToImgFolder}/openall-g.png") 1px 1px no-repeat;
    width: 26px;
    height: 27px;
    display: inline;
    float: right;
    margin-top: 2px;
    cursor: pointer;
    -moz-border-radius: 4px;
    -webkit-border-radius: 4px;
    -ms-border-radius: 4px;
    border-radius: 4px;
  }

  .collapseall {
    background: ${"url"}("${pathToImgFolder}/closeall-g.png") 1px 1px no-repeat;
    width: 26px;
    height: 27px;
    display: inline;
    float: right;
    margin-top: 2px;
    cursor: pointer;
    -moz-border-radius: 4px;
    -webkit-border-radius: 4px;
    -ms-border-radius: 4px;
    border-radius: 4px;
  }

	.error{
		border : 1px Solid red;
		background-color : rgb(255,245,245);
	}
	.error, .error b{
		color : red;
	}

	.info{
		background-color: #FAFAFA;
		border: 1px solid #BBBBBB;
		color: #888;
	}
{/macro}

{macro textShadow(textContent)}
	-moz-text-shadow : ${textContent};
	-webkit-text-shadow : ${textContent};
	text-shadow : ${textContent};
{/macro}
{/CSSTemplate}

//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/bean/view/item/BeanItemStyle.tpl.css
//NxFOn9Dh1D

{CSSTemplate {
	$classpath : 'apps.apidocs.modules.bean.view.item.BeanItemStyle'
}}

{macro main()}
	ul {
		margin-top:0px;
	}
	.multiline {
		display:block;
		padding-left:10px;
	}
	.entry {
	  border-left: 20px solid #EEE;
	}
	.properties>div{
	 border: 0px;
	}
	.plus+h3>a {
	 color:black;
	}
	.minus+h3>a {
   color:black;
  }
  .entry .singleprop {
    border: 1px solid #D0D0D0;
    margin-right: 20px;
  }
{/macro}
{/CSSTemplate}

//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/bean/view/list/BeanListStyle.tpl.css
//NxFOn9Dh1D
{CSSTemplate {
	$classpath : 'apps.apidocs.modules.bean.view.list.BeanListStyle'
}}
{var fontColor = "#333333" /}
{var contrastColor = "#000" /}
{var backgroundColor = "#D0D0D0" /}
{macro main()}
	#beanList {
		position : absolute;
		top : 0px;
		left : 0px;

		height : 100%;
		width : 198px;
		background : #fafafa;
		overflow-x : hidden;

		border-right : Solid 1px ${backgroundColor};

		font-family : Arial, sans-serif;
		font-size:13px;
	}
	#beanList ul {
		margin : 0px 0 0 0;
		padding : 10px 0 10px 0;
	}

	#beanList li {
		color: ${fontColor};
		padding-top : 4px;
		padding-bottom : 4px;
		padding-left:20px;
		height:18px;
		cursor:pointer;
	}

	#beanList li:hover, #beanList .selected{
		height:18px;
		padding-top : 3px;
		padding-bottom : 3px;
		padding-left: 30px;
	}

	#beanList li:hover {
	  border-top: Solid 1px #DFDFDF;
	  border-bottom: Solid 1px #DFDFDF;

	}

	#beanList .selected {
		background-color : #CECECE;
		border-top : Solid 1px #f3f3f3;
    border-bottom : Solid 1px #dfdfdf;
		font-weight : bold;
		font-size: 105%;
	}

	#beanList a {
		color:#333;
		outline:none;
		display:block;
	}
	#beanList a:hover {
		text-decoration:none;
	}

	#beanList li div {
	}

	#beanList .title {
		color:${contrastColor};
		font-weight : bold;
		height:18px;
		margin-top : 10px;
		margin-bottom: 5px;
		padding-left : 10px;
	}
{/macro}

{macro textShadow(textContent)}
	-moz-text-shadow : ${textContent};
	-webkit-text-shadow : ${textContent};
	text-shadow : ${textContent};
{/macro}
{/CSSTemplate}

//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/classDocumentor/view/ClassDocumentorStyle.tpl.css
//NxFOn9Dh1D
{CSSTemplate {
	$classpath : 'apps.apidocs.modules.classDocumentor.view.ClassDocumentorStyle'
}}

{macro main()}
	.invalidItem {
		color : lightgrey;
	}
	{var pathToImgFolder = this.cssFolderPath + "/../../../style/img"/}
	.externalItem {
		color : #6365FF;
		background : ${"url"}("${pathToImgFolder}/external_link_8_8.png") left center;
		background-repeat : no-repeat;
		padding-left:12px;
	}
	
	.showAll {
		text-decoration:underline; 
		cursor:pointer;
	}	

	#classDescription div.extras {
	    margin: 10px;
	}
	
	#classDescription pre, #classDescription code {
		margin : 10px 0px;
	    padding: 10px;
		background: none repeat scroll 0 0 white;
		
	    border: 1px solid #AAAAAA;
	    border-radius: 5px 5px 5px 5px;
	    
	    color: #666666;
	    white-space: pre-wrap;
	    word-wrap: break-word;
	    
	    display:block;
	}
	
	#classDescription p.extras {
	    margin: 5px 13px;
	}
	
	#classDescription label {
		font-weight:bold;
		width:100px;
		float:left;
	}
{/macro}
{/CSSTemplate}

//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/documents/view/BaseDocumentorStyle.tpl.css
//NxFOn9Dh1D
{CSSTemplate {
	$classpath : 'apps.apidocs.modules.documents.view.BaseDocumentorStyle'
}}

{macro main()}
	{var greyBg="#EEEEEE"/}
	{var greyBorder="#D0D0D0"/}
	h1 {
    	background: ${greyBg};
   		border-bottom: 1px solid ${greyBorder};
    	height: 39px;
    	margin: 0;
    	padding: 5px 10px 10px;
    	font-size: 20px;
    	font-weight: normal;
    	position : relative;
    	z-index : 9000;
	}

	.documentType {
    	color: #aaa;
		{call textShadow("0 1px 0 #fafafa")/}
	}

	.documentContainer {
		z-index : 10;
		clear: both;
	}

	.documentName {
		color: #000;
		margin-top:1em;
	}

	.optionContainer {
		cursor:pointer;
		margin : 0px;
		font-size : 13px;
		font-weight : normal;
		position:absolute;
		top:30px;
		right:5px;
		width:112px;
	}
	.optionContainer span{
		color : #000;
		{call textShadow("0px 1px 0px white")/}
	}
	.sortOptionContainer:hover span{
		color : #777;
	}
	.outerOption{
		height:10px;
		width:10px;
		background:white;
		float:left;
		margin-right:5px;
		margin-top:3px;
	}
	.innerOption{
		height:6px;
		width:6px;
		margin : 2px;
		background:white;
	}

	.innerOption.selected{
		background:#000;
	}

	.quickcard {
		cursor: pointer;
	    float: left;
	    font-size: 13px;
	    font-weight: normal;
	    top : 2px;
		{if aria.core.Browser.isIE}
	   		height: 23px;
		{else/}
	    	height: 22px;
		{/if}
	    padding-left : 10px;
	    padding-right : 10px;
	    position: relative;

	    border-color: transparent;
	    border-style: solid;
	    border-width: 1px 1px medium;
	}

	//{var contentBg = "#B0B0B0"/}
	//{var fontColor = "white"/}
	{var contentBg = "#fff"/}
	{var fontColor = "black"/}
	.quickcard.selected {
	    border-color: ${greyBorder} ${greyBorder} ${contentBg};
	    background : ${contentBg};
	    color : ${fontColor};
	}

	.quickcardContent {
		position: absolute;
		{if aria.core.Browser.isIE}
			top: 24px;
		{else/}
			top: 23px;
		{/if}
		left : -1px;
		padding : 0 20px;

		background: ${contentBg};
		border: 1px solid ${greyBorder};
		border-top : none;

		z-index: 9000;
	}

	.quickcardContent ul{
		padding-left : 0px;
		margin-left : 0px;
		margin-top : 5px;
		padding-top : 0px;
		line-height : 20px;
	}

	li.aPublicMethod{
		position : relative;
	}

	.quickcardContent a {
		color : ${fontColor};
	}

	.downArrow {
	    position: relative;
	    float: left;

	    height: 0;
	    width: 0;
	    top: 10px;
	    margin-left: 3px;

	    border-color: #000 transparent transparent;
	    border-style: solid;
	    border-width: 3px;
	}

	.selected .downArrow {
		border-color: ${fontColor} transparent transparent;
	}

	sup {
		color : #000000;
	}

	.selected sup {
		color : ${fontColor};
	}


	.publicSection h2 {
	    margin: 0;
	    padding: 10px;

	    color : #000000;
	    background : #f0f0f0;
	    border-top: 1px solid #d0d0d0;

	    font-size : 20px;
	    font-weight : normal;
	}

	.publicSection ul {
	    margin: 0;
	    padding: 0;
	}

	.publicSection h4, h5, p,b {
	    color:#666;
	}

	.methodTitle .parameterType {
		font-weight : normal;
		color : #666;
	}

	.methodTitle .parameterName {
		font-weight : bold;
		color : #666;
	}

	.methodTitle .returnType {
		font-weight : normal;
		color : #666;
	}
{/macro}

{macro textShadow(textContent)}
	-moz-text-shadow : ${textContent};
	-webkit-text-shadow : ${textContent};
	text-shadow : ${textContent};
{/macro}
{/CSSTemplate}

//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/documents/view/DocumentsDisplayStyle.tpl.css
//NxFOn9Dh1D
{CSSTemplate {
	$classpath : 'apps.apidocs.modules.documents.view.DocumentsDisplayStyle'
}}
	{macro main()}
		.documentContainer {
			overflow : auto;
			position : relative;
		}
	{/macro}
{/CSSTemplate}
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/documents/view/MethodStyle.tpl.css
//NxFOn9Dh1D
{CSSTemplate {
	$classpath : 'apps.apidocs.modules.documents.view.MethodStyle'
}}
{macro main()}
	.aPublicMethod {
		padding: 15px;
		border-top:1px solid #D0D0D0;
		margin: 0;
	}

	.last{
		border-bottom:1px solid #D0D0D0;
	}

	.aPublicMethod h3 {
	    margin: 0;
	}

	.aPublicMethod .description {
	    margin-top: 5px;
	}

	.methodLink {
		color : #000;
	}

	.methodLink:hover {
		text-decoration:none;
	}

	.methodLink:focus {
		outline:none;
	}

	.jstag {
		font-weight: bold;
	    position: absolute;
	    right: 5px;
	    top: 5px;
	    color : #aaa;
	}

	.toggleItem {
		position:absolute;
		top : 0;
		left : 0;
		height:100%;
		width:11px;
		background : transparent;
		cursor : pointer;
	}

	.toggleItem:hover {
		background : #EEEEEE;
	}

	.toggleItem .arrow {
		display: block;
	    height: 0;
	    width: 0;
	    border-style: solid;
	    border-width: 3px;
	}

	.expanded .arrow{
	    border-color: #000000 transparent transparent;
	    margin-left: 2px;
    	margin-top: 22px;
	}

	.collapsed .arrow{
	    border-color: transparent transparent transparent #000000;
	    margin-left: 4px;
    	margin-top: 20px;
	}

	.collapsed .descriptionWrapper{
    	/*height : 20px;*//*Jakub: it looks ugly when page zoomed using CTRL++*/
    	overflow : hidden;
	}

	.highlighted {
		background-color : #FFFED1;
	}

	#publicMethods .highlighted .parameterDetails {
		background-color : white;
	}

	.aPublicMethod p {
		margin : 0;
	}

	.methodDetail {
	    margin-bottom: 5px;
	    margin-top: 10px;
	}

	.methodDetailTitle {
		font-size: 1.1em;
		font-weight : bold;
	}

	.publicSection .methodDetailContent {
		margin : 5px 10px 0px;
	}
	.publicSection .parametersList{
		margin-left : 25px;
	}

	.parametersList li{
		color: #BBBBBB;
    	list-style: square outside none;
	}

	.parametersList li *{
		color: #666;
	}

	.parameter {
		margin-bottom:5px;
	}

	.parameter .parameterName{
		font-weight : bold;
	}

	.methodDetail .returnType {
		font-weight : normal;
		color : #666;
	}
{/macro}
{/CSSTemplate}
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/apidocsAutocomplete/ApidocsAutocompleteListStyle.tpl.css
//NxFOn9Dh1D
{CSSTemplate {
	$classpath : 'apps.apidocs.modules.packageExplorer.apidocsAutocomplete.ApidocsAutocompleteListStyle'
}}
	{macro main()}
		.suggestionsContainer td {
			padding : 0 10px;
		}
		.suggestionsContainer {
			line-height : 20px;
		}
		.suggestionsContainer .icon{
			padding:0px; 
			padding-left:18px;
			border:none;
			background-position:0px 3px;
		}
		
		.suggestionsContainer .icon.SingletonDefinition{
			background-position:1px 4px;
		}
	{/macro}
{/CSSTemplate}
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/view/PackageTreeDisplayStyle.tpl.css
//NxFOn9Dh1D
{CSSTemplate {
	$classpath : 'apps.apidocs.modules.packageExplorer.view.PackageTreeDisplayStyle'
}}
	{macro main()}
		.packageContainer {
			background-color:white;
		}

		.treeNode{
			margin: 3px 0 3px 5px;
		}

		.treeNode .treeNode{
			padding-left:20px;
			margin: 3px 0 3px 0px;
		}

		.treeNode.selected {
			background-color: #EFEFEF;
			font-weight: bold;
		}

		.treeNode.containsSelection {
			background-color:#EFEFEF;
		}

		div.treeNode a {
			text-decoration: none;
			color: black;
			padding-left: 15px;
		}

		div.treeNode a:hover {
			color:grey;
			text-decoration: underline;
		}

		{var pathToImgFolder = this.cssFolderPath + "/../../../style/img"/}

		.ClassDefinition {
			background: ${"url"}("${pathToImgFolder}/class.gif") -3px -1px no-repeat;
		}

   	.TplScriptDefinition {
     		background: ${"url"}("${pathToImgFolder}/template-script.gif") -3px -1px no-repeat;
   	}

   	.ResourcesDefinition {
		    background: ${"url"}("${pathToImgFolder}/style/img/res.gif") -2px -1px no-repeat;
	  }

		.BeanDefinition {
			background: ${"url"}("${pathToImgFolder}/bean.gif") -3px -1px no-repeat;
		}

		.InterfaceDefinition {
			background: ${"url"}("${pathToImgFolder}/interface.gif") -3px -1px no-repeat;
		}

		.SingletonDefinition {
			background: ${"url"}("${pathToImgFolder}/singleton.gif") -2px -1px no-repeat;
		}

		.method {
			background: ${"url"}("${pathToImgFolder}/classMethod.gif") -3px -1px no-repeat;
		}

		.property {
			background: ${"url"}("${pathToImgFolder}/property.gif") -3px -1px no-repeat;
		}

		.event {
			background: ${"url"}("${pathToImgFolder}/event.gif") -3px -1px no-repeat;
		}

		.plus {
			background: ${"url"}("${pathToImgFolder}/plus.gif") -4px -2px no-repeat;
		}

		.minus {
			background: ${"url"}("${pathToImgFolder}/minus.gif") -4px -2px no-repeat;
		}

		.legendContainer {
			position: absolute;
			bottom : 0px;
			padding: 0 11px 5px;

			opacity : 0.3;
		    -webkit-transition : opacity 0.40s linear;
		    -moz-transition : opacity 0.40s linear;
		    -o-transition : opacity 0.40s linear;
		    transition : opacity 0.40s linear;

			float:left;
			text-align : center;
		}

		.legendContainer:hover {
			opacity : 1;
		}

		.legendContainer .item {
			padding-left : 15px;
			margin-right : 12px;
			float : left;
		}

		.legendBorder {
			border-top : 1px Solid #888;
			padding : 0px;
			padding-top:5px;
			padding-left:5px;
		}

		div.packageFilters {
			padding:5px;
			border-bottom:solid 1px #D0D0D0;
			background: #eee;
		}
	{/macro}
{/CSSTemplate}
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/resources/ResourcesDisplayStyle.tpl.css
//NxFOn9Dh1D
{CSSTemplate{
	$classpath : 'apps.apidocs.modules.resources.ResourcesDisplayStyle'
}}
{macro main()}

/* RESOURCES MODULE */
table.resources {
	border:solid 1px #EADBC8;
}
table.resources th {
	background:#EADBC8;
	borde:1px solid #FFFBF1;
}
table.resources td {
	border:1px solid #EADBC8;
}
{/macro}
{/CSSTemplate}
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/controller/FlowController.js
//NxFOn9Dh1D
Aria.classDefinition({$classpath:"apps.apidocs.controller.FlowController",$implements:["apps.apidocs.controller.IFlowController","apps.apidocs.controller.IPublicFlowController"],$extends:"aria.templates.FlowCtrl",$constructor:function(){this.$FlowCtrl.constructor.call(this)},$prototype:{$publicInterfaceName:"apps.apidocs.controller.IPublicFlowController",stateTransition:function(a,b){var c=this.__getFollowingState(a);if(c){var e=c.fn,d={fn:e,scope:this,args:b};this._currentState=c.state;e&&this.$callback(d)}},
__getFollowingState:function(a){for(var b=this._currentState,c=0,e=b.transitions.length;c<e;c+=1){var d=b.transitions[c];if(d.on===a){a=d.to;b=this._states[a];if(!b)return this.$logWarn("State "+a+" is not defined");return{state:b,fn:d.fn,name:a}}}this.$logWarn("Event "+a+" not supported")},onSubModuleEvent:function(a){this.stateTransition(a.name,a)}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/controller/IBaseModuleController.js
//NxFOn9Dh1D
Aria.interfaceDefinition({$classpath:"apps.apidocs.controller.IBaseModuleController",$extends:"aria.templates.IModuleCtrl",$events:{stateChange:"structure of application have been updated"},$interface:{loadDependenciesSubModules:{$type:"Function"}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/controller/IFlowController.js
//NxFOn9Dh1D
Aria.interfaceDefinition({$classpath:"apps.apidocs.controller.IFlowController",$extends:"aria.templates.IFlowCtrl",$interface:{_currentState:{$type:"Object"},_states:{$type:"Object"}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/controller/IPublicFlowController.js
//NxFOn9Dh1D
Aria.interfaceDefinition({$classpath:"apps.apidocs.controller.IPublicFlowController",$extends:"aria.templates.IFlowCtrl",$events:{stateChange:{description:"State of the flow controller changed",properties:{state:"{String} New state of the flow controller"}}},$interface:{stateTransition:{$type:"Function",$callbackParam:1}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/main/AppModule.js
//NxFOn9Dh1D
Aria.classDefinition({$classpath:"apps.apidocs.main.AppModule",$extends:"aria.templates.ModuleCtrl",$implements:["apps.apidocs.main.IAppModule"],$dependencies:["apps.apidocs.main.DataModel","apps.apidocs.main.AppModuleFlow","apps.apidocs.main.AppModuleServices","apps.apidocs.modules.packageExplorer.PackageExplorerModule","apps.apidocs.modules.documents.DocumentsModule","apps.apidocs.utils.Common","apps.apidocs.utils.HashHandler","apps.apidocs.main.Nyan","aria.touch.Event","aria.utils.ScriptLoader",
"aria.utils.QueryString"],$constructor:function(){this.$ModuleCtrl.constructor.call(this);var a=aria.utils.QueryString.getKeyValue("root");this._rootPackages=a?[a]:["aria"];this._packageServices=new apps.apidocs.main.AppModuleServices;this._dataBeanName="apps.apidocs.main.DataModel.Root"},$destructor:function(){this.__hashCallbackObject&&aria.utils.HashManager.removeCallback(this.__hashCallbackObject);this.$ModuleCtrl.$destructor.call(this)},$prototype:{$hasFlowCtrl:true,$publicInterfaceName:"apps.apidocs.main.IAppModule",
init:function(a,b){if(aria.touch.Event.touch){var c=aria.utils.QueryString.getKeyValue("weinre");c&&aria.utils.ScriptLoader.load(["http://debug.phonegap.com/target/target-script-min.js#guid:"+c])}this._packageServices.update(this._rootPackages,{fn:this.__serviceUpdateCallback,scope:this,args:{initCb:b}});this.__hashCallbackObject={fn:this.__onHashChange,scope:this};aria.utils.HashManager.addCallback(this.__hashCallbackObject)},simulateHashChange:function(){this.__onHashChange()},__onHashChange:function(){var a=
apps.apidocs.utils.HashHandler.getClasspathFromHash();if(this.isClasspathValid(a))a&&this.displayContent(a);else{a=this.getData().packages["view:selectedClasspath"];window.location.hash=a||this.__getDefaultClasspath()}},displayContent:function(a){var b=this.getClasspathType(a);apps.apidocs.utils.Common.setWindowTitle(a);this.packages&&this.packages.selectClasspath(a);this.documents&&this.documents.loadDocument({type:b,classpath:a})},__getDefaultClasspath:function(){for(var a=this.getData().packages.packageTree,
b=[];a&&aria.utils.Type.isObject(a);){var c=a;a=null;for(var d in c)if(apps.apidocs.utils.Common.checkKey(c,d)){a=c[d];b.push(d);break}}return classpath=b.join(".")},isClasspathValid:function(a){return!!this.getClasspathType(a)},getClasspathType:function(a){a=a.split(".");for(var b=this.getData().packages.packageTree,c=0;b&&c<a.length;c++)b=b[a[c]];return b},getRootPackages:function(){return this._rootPackages},__serviceUpdateCallback:function(a,b){this.setData(b.data);this.loadDependenciesSubModules([{refpath:"packages",
classpath:"apps.apidocs.modules.packageExplorer.PackageExplorerModule",initArgs:{rootPackages:this.getRootPackages()}},{refpath:"documents",classpath:"apps.apidocs.modules.documents.DocumentsModule",reload:true,initArgs:{content:this._data.content}}],aria.utils.Function.bind(this.__onInitEnd,this,b.initCb))},loadDependenciesSubModules:function(a,b){for(var c=[],d=0;d<a.length;d++){param=a[d];this[param.refpath]===undefined&&c.push(param)}this.loadSubModules(c,b)},__onInitEnd:function(a){this.$callback(a)},
notifyFlowController:function(){},notifyDocumentsChanged:function(){},onSubModuleEvent:function(a){if(a.name==="displayContent")this.__$interfaces[this.$publicInterfaceName].notifyFlowController(a);else a.name=="documentsChanged"&&this.__$interfaces[this.$publicInterfaceName].notifyDocumentsChanged(a)}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/main/AppModuleFlow.js
//NxFOn9Dh1D
Aria.classDefinition({$classpath:"apps.apidocs.main.AppModuleFlow",$extends:"apps.apidocs.controller.FlowController",$implements:["apps.apidocs.main.IAppModuleFlow","apps.apidocs.controller.IFlowController"],$constructor:function(){this._states={};this._states[this.STATES.NONE]={transitions:[{on:"doInit",to:this.STATES.WITH_DOCUMENTS}]};this._states[this.STATES.WITH_DOCUMENTS]={transitions:[{on:"displayContent",to:this.STATES.WITH_DOCUMENTS},{on:"documentsChanged",to:this.STATES.WITH_DOCUMENTS}]};
this._currentState=this._states[this.STATES.NONE];this.$FlowController.constructor.call(this)},$statics:{STATES:{NONE:"none",WITH_DOCUMENTS:"withDocuments"}},$destructor:function(){this.$FlowController.destructor.call(this);this._states=this._currentState=null},$prototype:{$publicInterfaceName:"apps.apidocs.main.IAppModuleFlow",oninitCallback:function(a){this.$FlowCtrl.oninitCallback.call(this,a);this.moduleCtrl.simulateHashChange();this.stateTransition("doInit")},showExplorer:function(){this.stateTransition("showExplorer")},
hideExplorer:function(){this.stateTransition("hideExplorer")},onnotifyFlowControllerCallEnd:function(a){this.stateTransition(a.args[0].name,{classpath:a.args[0].classpath,type:a.args[0].type})},onnotifyDocumentsChangedCallEnd:function(a){this.stateTransition(a.args[0].name,{select:a.args[0].select})},getCurrentStateName:function(){for(var a in this.STATES)if(this.STATES.hasOwnProperty(a)){var b=this.STATES[a];if(this._currentState==this._states[b])return b}}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/main/AppModuleServices.js
//NxFOn9Dh1D
Aria.classDefinition({$classpath:"apps.apidocs.main.AppModuleServices",$constructor:function(a){this._modCtrl=a;this.__updateCallback=this.__tmpData=null;this._waitingPackageContent=0;this.rootPackages=[]},$dependencies:["apps.apidocs.utils.SplashScreen"],$prototype:{update:function(a,b){this.$assert(62,this.__tmpData===null);this.__tmpData={};this.__updateCallback=b;this.rootPackages=a;for(var c=0,e=a.length;c<e;c+=1)this._loadPackageContent(a[c],this.__tmpData)},_loadPackageContent:function(a,b){this._waitingPackageContent++;
Aria.load({classes:[a+"._packageContent"],oncomplete:{fn:this.__onLoadPackageContentCompleted,scope:this,args:{rootPackage:a,data:b}},onerror:{override:true,fn:this.__onLoadPackageContentError,scope:this}})},__onLoadPackageContentCompleted:function(a){var b=a.data;a=Aria.getClassRef(a.rootPackage+"._packageContent");if(!b.content)b.content=[];b.content=b.content.concat(a.content);a=aria.core.Cache;for(var c=0,e=b.content.length;c<e;c++){var d=b.content[c];if(d.ariaType=="Bean"){var f=d.name.replace(/\./g,
"/")+".js";a.content.files[f]={status:aria.core.Cache.STATUS_AVAILABLE,value:d.definition};a.content.files[d.name]={status:aria.core.Cache.STATUS_AVAILABLE,type:"JS"}}}this._loadFinished()},_loadFinished:function(){this._waitingPackageContent-=1;if(!this._waitingPackageContent)if(this.__tmpData){this.$assert(135,this.__updateCallback);this.__updateCallback.args.data=this.__tmpData;this.$callback(this.__updateCallback);this.__tmpData=null}},__onLoadPackageContentError:function(){alert("Couldn't load content file for root package(s) : "+
this.rootPackages.join(", ")+"\nPlease verify your URL");apps.apidocs.utils.SplashScreen.setFailed()}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/main/DataModel.js
//NxFOn9Dh1D
Aria.beanDefinitions({$package:"apps.apidocs.main.DataModel",$description:"Definition of the Global data model for Documentation Center",$namespaces:{json:"aria.core.JsonTypes"},$beans:{Root:{$type:"json:Object",$description:"Root of the data model",$mandatory:true,$properties:{packages:{$type:"json:ObjectRef",$description:"Map of registered packages"},content:{$type:"json:ObjectRef",$description:"Map of registered content"},documents:{$type:"json:ObjectRef",$description:"Map of open documents"},
classes:{$type:"json:ObjectRef",$description:"Map of registered classes"}}}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/main/IAppModule.js
//NxFOn9Dh1D
Aria.interfaceDefinition({$classpath:"apps.apidocs.main.IAppModule",$extends:"apps.apidocs.controller.IBaseModuleController",$interface:{notifyFlowController:{$type:"Function"},notifyDocumentsChanged:{$type:"Function"},getRootPackages:{$type:"Function"},simulateHashChange:{$type:"Function"}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/main/IAppModuleFlow.js
//NxFOn9Dh1D
Aria.interfaceDefinition({$classpath:"apps.apidocs.main.IAppModuleFlow",$extends:"apps.apidocs.controller.IPublicFlowController",$events:{loadDocument:{description:"State of the flow controller changed",properties:{type:"{String} New state of the flow controller",classpath:""}}},$interface:{showExplorer:{$type:"Function"},hideExplorer:{$type:"Function"},STATES:{$type:"Object"},getCurrentStateName:{$type:"Function"}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/main/Nyan.js
//NxFOn9Dh1D
(function(){var a,d,e=["UP","UP","DOWN","DOWN","LEFT","RIGHT","LEFT","RIGHT","B","A","ENTER"];Aria.classDefinition({$classpath:"apps.apidocs.main.Nyan",$dependencies:["aria.utils.Event"],$singleton:true,$constructor:function(){this.__kcodeIndex=0;aria.utils.Event.addListener(document,"keyup",{fn:this.__onGlobalKeyup,scope:this})},$prototype:{__onGlobalKeyup:function(c){if(c.keyCode==aria.DomEvent["KC_"+e[this.__kcodeIndex]]){this.__kcodeIndex++;if(this.__kcodeIndex>=e.length){if(a){window.clearInterval(d);
document.body.removeChild(a)}else{this.__addNyan();a=document.createElement("IFRAME");a.src="http://nyan.cat/";a.style.cssText="top:-10000px; left:-10000px;width:0px;height:0px;position:fixed;z-index:13000";document.body.appendChild(a)}this.__kcodeIndex=0}}else this.__kcodeIndex=0},__addNyan:function(){var c=Math.ceil(Math.random()*50),b=document.createElement("div");document.body.appendChild(b);b.className="nyan";b.style.cssText="left : -700px;width:260px;height:182px;position:fixed;z-index:15000;-webkit-transition : left 20s linear;-moz-transition : left 20s linear;-o-transition : left 20s linear;transition : left 20s linear;background-repeat : none;background-image:url('style/img/nyancat.gif');top:"+
c+"%;";window.setTimeout(function(){b.style.left=Math.ceil(Math.random()*5E3)+3E3+"px"},1E3);window.setTimeout(function(){document.body.removeChild(b)},15E3);var f=this;d=window.setTimeout(function(){f.__addNyan()},Math.ceil(Math.random()*2500)+1E3)}}})})();
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/main/view/MainScript.js
//NxFOn9Dh1D
Aria.tplScriptDefinition({$classpath:"apps.apidocs.main.view.MainScript",$prototype:{onFlowEvent:function(a){if(a.name=="stateChange"){if(a.state)this.data["view:state"]=a.state;this.$refresh()}},__getViewState:function(){var a=this.data["view:state"];a||(a=this.data["view:state"]=this.flowCtrl.getCurrentStateName());return a},_hasDocuments:function(){var a=this.__getViewState(),b=this.flowCtrl.STATES;return a!=b.WITHOUT_DOCUMENTS&&a!=b.NONE},_getContentWidth:function(){var a=538;a-=309;return a}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/bean/BeanModule.js
//NxFOn9Dh1D
Aria.classDefinition({$classpath:"apps.apidocs.modules.bean.BeanModule",$extends:"aria.templates.ModuleCtrl",$implements:["apps.apidocs.modules.bean.IBeanModule"],$dependencies:[],$constructor:function(){this.$ModuleCtrl.constructor.call(this);this._isValid=false},$events:{},$prototype:{$publicInterfaceName:"apps.apidocs.modules.bean.IBeanModule",init:function(a,b){this._docs=a.docs;this.$callback(b)},setData:function(a,b){this.$ModuleCtrl.setData.apply(this,arguments);this._data.classpath&&Aria.load({classes:[this._data.classpath],
oncomplete:{fn:this.__onBeanLoadComplete,scope:this,args:b},onerror:{fn:this.__onBeanLoadError,scope:this,args:b}})},__onBeanLoadComplete:function(a){this._data.beans=aria.core.JsonValidator.__loadedBeans[this._data.classpath].$beans;this._data.rawBeansDefinition=this.__getRawBeansDefinition(this._docs.definition);this._isValid=true;a&&this.$callback(a)},__onBeanLoadError:function(a){var b=this.__getRawBeansDefinition(this._docs.definition);this._data.beans=b.$beans;this._data.rawBeansDefinition=
b;this._isValid=false;a&&this.$callback(a)},__getRawBeansDefinition:function(a){a=a.substring(20);return eval(a)},isValid:function(){return this._isValid},selectBean:function(a){var b=this.getData().beans,c;for(c in b)if(b.hasOwnProperty(c))b[c]["view:selected"]=a&&c==a?true:false}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/bean/IBeanModule.js
//NxFOn9Dh1D
Aria.interfaceDefinition({$classpath:"apps.apidocs.modules.bean.IBeanModule",$extends:"aria.templates.IModuleCtrl",$interface:{setData:{$type:"Function"},isValid:{$type:"Function"},selectBean:{$type:"Function"}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/bean/view/container/BeanContainerScript.js
//NxFOn9Dh1D
Aria.tplScriptDefinition({$classpath:"apps.apidocs.modules.bean.view.container.BeanContainerScript",$prototype:{$dataReady:function(){this.data["view:action"]||(this.data["view:action"]="expandall")},getItemFromHash:function(){var a=apps.apidocs.utils.HashHandler.getItemFromHash();if(a)if(a.indexOf(".")!=-1)a=a.substring(0,a.indexOf("."));return a},getClasspathFromHash:function(){return apps.apidocs.utils.HashHandler.getClasspathFromHash()},_getSelectedBean:function(){if(this.data.beans)for(var a in this.data.beans){bean=
this.data.beans[a];if(bean["view:selected"])return bean}},_expandCollapse:function(){if(this.data["view:action"]=="expandall"){this._onExpandCollapseAllClick(true);this.$json.setValue(this.data,"view:action","collapseall")}else if(this.data["view:action"]=="collapseall"){this._onExpandCollapseAllClick(false);this.$json.setValue(this.data,"view:action","expandall")}},_onExpandCollapseAllClick:function(a){var c=this._getSelectedBean(),d=this.getItemFromHash();this._recursive(c,d,a);this.$refresh()},
_recursive:function(a,c,d){if(a.$properties)for(var b in a.$properties)if(a.$properties.hasOwnProperty(b)&&!aria.utils.Json.isMetadata(b))if(!this._isBeanBodyEmpty(a.$properties[b])){if(!a.$properties[b].hasOwnProperty("__isBodyExpanded"))a.$properties[b].__isBodyExpanded={};a.$properties[b].__isBodyExpanded[c]=d;this._recursive(a.$properties[b],c,d)}if(a.$contentTypes)for(b=0;b<a.$contentTypes.length;b++)if(!this._isBeanBodyEmpty(a.$contentTypes[b])){if(!a.$contentTypes[b].hasOwnProperty("__isBodyExpanded"))a.$contentTypes[b].__isBodyExpanded=
{};a.$contentTypes[b].__isBodyExpanded[c]=d}},_isBeanBodyEmpty:function(a){if(a.$contentTypes)return false;if(a.$sample)return false;if(a.$enumValues)return false;if(a.$keyType)return false;if(a.$contentType)return false;if(a.$properties)return false;return true}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/bean/view/item/BeanItemScript.js
//NxFOn9Dh1D
Aria.tplScriptDefinition({$classpath:"apps.apidocs.modules.bean.view.item.BeanItemScript",$dependencies:["apps.apidocs.utils.Common","aria.templates.View"],$destructor:function(){this._backupScrollPosition()},$prototype:{$dataReady:function(){this.data["view:scrollPositions"]||(this.data["view:scrollPositions"]={})},$beforeRefresh:function(){this._backupScrollPosition()},$afterRefresh:function(){var a=this.$getElementById("beanContainer"),b=this.data["view:scrollPositions"].beanContainer;b&&a.setScroll(b)},
_backupScrollPosition:function(){var a=this.$getElementById("beanContainer");a&&this.$json.setValue(this.data["view:scrollPositions"],"beanContainer",a.getScroll())},getItemFromHash:function(){return apps.apidocs.utils.HashHandler.getItemFromHash()},getClasspathFromHash:function(){return apps.apidocs.utils.HashHandler.getClasspathFromHash()},_isBeanVisible:function(a){return a.$private!==true||apps.apidocs.utils.Common.isPrivateVisible()},_onBeanClick:function(a,b){this.moduleCtrl.selectBean(b)},
__initBeanCustomProperties:function(a){if(!a.hasOwnProperty("__isBodyExpanded"))a.__isBodyExpanded={}},_onToggleBeanBodyClick:function(a,b){this.__initBeanCustomProperties(b);var c=this.getItemFromHash();b.__isBodyExpanded[c]=!b.__isBodyExpanded[c];this.$refresh()},_isBeanBodyExpanded:function(a){this.__initBeanCustomProperties(a);var b=this.getItemFromHash();return a.__isBodyExpanded[b]||false},_isBeanBodyEmpty:function(a){if(a.$contentTypes)return false;if(a.$sample)return false;if(a.$enumValues)return false;
if(a.$keyType)return false;if(a.$contentType)return false;if(a.$properties)return false;return true},_getClasspathFromNamespace:function(a){var b=this.data.rawBeansDefinition.$namespaces;if(b.hasOwnProperty(a))return b[a]},initDefaultValues:function(){var a=false,b,c;if(this.data.beans){for(var d in this.data.beans){c=this.data.beans[d];b||(b=c);if(c["view:selected"]){a=true;break}}if(!a&&b)b["view:selected"]=true}},_getSelectedBean:function(){if(this.data.beans)for(var a in this.data.beans){bean=
this.data.beans[a];if(bean["view:selected"])return{value:bean,name:a}}},_transformDetailContent:function(a){if(!a)return"";a=this.__convertToJsonString(a);a=("<code>"+a+"</code>").replace(/\[\]/gi,"[ ]");return this.__formatNewLine(a)},__convertToJsonString:function(a){var b="";if(typeof JSON!="undefined"&&JSON.stringify){b=JSON.stringify(a,null,"_|_4514_|_");b=b.replace(/_\|_4514_\|_/g,"&nbsp;&nbsp;")}else b=aria.utils.Json.convertToJsonString(a);return b},__formatNewLine:function(a){a=a.indexOf("\n")!=
-1||a.indexOf("<br>")!=-1?"<span class='multiline'>"+a+"</span>":"<span>"+a+"</span>";return a.replace(/\n/gi,"<br>")},_createUniqueView:function(a){a=new aria.templates.View(a);a.setSort("A","SortByName",function(b){return b.initIndex});return a}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/bean/view/list/BeanListScript.js
//NxFOn9Dh1D
Aria.tplScriptDefinition({$classpath:"apps.apidocs.modules.bean.view.list.BeanListScript",$prototype:{$dataReady:function(){var a=this.getItemFromHash();a&&this.moduleCtrl.selectBean(a)},$afterRefresh:function(){var a=this.getItemFromHash();if(a)(a=this.$getElementById("_bean_hook_"+a))&&a.scrollIntoView()},getItemFromHash:function(){var a=apps.apidocs.utils.HashHandler.getItemFromHash();if(a)if(a.indexOf(".")!=-1)a=a.substring(0,a.indexOf("."));return a},getClasspathFromHash:function(){return apps.apidocs.utils.HashHandler.getClasspathFromHash()},
getBeansArrayFromMap:function(a){var b=[],c;for(c in a)!a.hasOwnProperty(c)||aria.utils.Json.isMetadata(c)||b.push({key:c,value:a[c]});return b},_onBeanClick:function(a,b){this.moduleCtrl.selectBean(b)},selectBean:function(a){for(var b in this.data.beans)if(this.data.beans.hasOwnProperty(b))this.data.beans[b]["view:selected"]=a&&b==a?true:false},_initView:function(a){a.setSort("A","SortByName",function(b){return b.value.key});this.initDefaultValues(a.items);return""},initDefaultValues:function(a){var b=
false,c,d;if(a){c=a[0].value.key;for(var e=0;e<a.length;e++){d=a[e].value.value;if(d["view:selected"]){b=true;break}}!b&&c&&this.selectBean(c)}},__onItemClick:function(a,b){var c=b[0],d=b[1];if(a.target.tagName.toLowerCase()!="a")document.location.hash=c;this.$json.setValue(this.data,"view:action","expandall");this._recursive(this.data.beans[d],d,false)},_recursive:function(a,b,c){for(var d in a.$properties)if(a.$properties.hasOwnProperty(d)&&!aria.utils.Json.isMetadata(d))if(!this._isBeanBodyEmpty(a.$properties[d])){if(!a.$properties[d].hasOwnProperty("__isBodyExpanded"))a.$properties[d].__isBodyExpanded=
{};a.$properties[d].__isBodyExpanded[b]=c;this._recursive(a.$properties[d],b,c)}},_isBeanBodyEmpty:function(a){if(a.$contentTypes)return false;if(a.$sample)return false;if(a.$enumValues)return false;if(a.$keyType)return false;if(a.$contentType)return false;if(a.$properties)return false;return true}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/classDocumentor/ClassDocumentorModule.js
//NxFOn9Dh1D
Aria.classDefinition({$classpath:"apps.apidocs.modules.classDocumentor.ClassDocumentorModule",$extends:"aria.templates.ModuleCtrl",$implements:["apps.apidocs.modules.classDocumentor.IClassDocumentorModule"],$dependencies:["aria.utils.Json","apps.apidocs.utils.Common","apps.apidocs.utils.PackageContent"],$constructor:function(){this.$ModuleCtrl.constructor.call(this)},$statics:{},$prototype:{$publicInterfaceName:"apps.apidocs.modules.classDocumentor.IClassDocumentorModule",init:function(a,b){this._docs=
a.docs;this._parentModule=a.parentModule;this.$callback(b)},getValidClasspathsMap:function(){return this._parentModule.getValidClasspathsMap()},setData:function(){this.$ModuleCtrl.setData.apply(this,arguments);this._data.classDescription=this._docs.desc;this._data.isSingleton=this._docs.ariaType=="Singleton";this._data.classImplements=this._docs["implements"];this._data.classExtends=this._docs["extends"]?[this._docs["extends"]]:[];this._data.extendedBy=this._docs.extendedBy;this._data.dependsOn=this._docs.dependsOn;
this._data.dependedBy=this._docs.dependedBy;var a=this._docs.methods.concat(this._docs.staticMethods),b=apps.apidocs.utils.PackageContent;this._data.classMethods=b.filterMethods(a,"public");this._data.protectedMethods=b.filterMethods(a,"protected");this._data.privateMethods=b.filterMethods(a,"private");a=this._docs.properties.concat(this._docs.staticProperties);this._data.publicProperties=b.filterProperties(a,"public");this._data.protectedProperties=b.filterProperties(a,"protected");this._data.privateProperties=
b.filterProperties(a,"private");this._data.events=this._docs.events;this.$raiseEvent("classLoaded")},displayContent:function(a){document.location.hash="#"+a;apps.apidocs.utils.Common.setWindowTitle(a)}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/classDocumentor/IClassDocumentorModule.js
//NxFOn9Dh1D
Aria.interfaceDefinition({$classpath:"apps.apidocs.modules.classDocumentor.IClassDocumentorModule",$extends:"aria.templates.IModuleCtrl",$events:{classLoaded:"raised when the class has been loaded and the data model is ready"},$interface:{setData:{$type:"Function"},displayContent:{$type:"Function",$callbackParam:2},getValidClasspathsMap:{$type:"Function"}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/classDocumentor/view/ClassDocumentorScript.js
//NxFOn9Dh1D
Aria.tplScriptDefinition({$classpath:"apps.apidocs.modules.classDocumentor.view.ClassDocumentorScript",$dependencies:["aria.utils.HashManager","apps.apidocs.utils.Common"],$prototype:{$dataReady:function(){this.$BaseDocumentorScript.$dataReady.call(this);this.data.showMore=true},onModuleEvent:function(a){a.name=="classLoaded"&&this.$refresh()},contentClick:function(a,b){this.moduleCtrl.displayContent(b.classpath,b.type)},showMore:function(){this.data.showMore=false;this.$refresh()},isClasspathValid:function(a){return this.moduleCtrl.getValidClasspathsMap()[a]===
true},isAriaClasspath:function(a){return a.indexOf("aria.")==0},toCamelCase:function(a){return a.substring(0,1).toUpperCase()+a.substring(1)},isObjectEmpty:function(a){return apps.apidocs.utils.Common.isObjectEmpty(a)}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/documents/DocumentsModule.js
//NxFOn9Dh1D
Aria.classDefinition({$classpath:"apps.apidocs.modules.documents.DocumentsModule",$extends:"aria.templates.ModuleCtrl",$implements:["apps.apidocs.modules.documents.IDocumentsModule"],$dependencies:["apps.apidocs.main.DataModel","apps.apidocs.utils.Common","apps.apidocs.utils.ResourceProvider"],$constructor:function(){this.$ModuleCtrl.constructor.call(this);this.documentsReady={};this.typesAssociation={BeanDefinition:"apps.apidocs.modules.bean.BeanModule",ResourcesDefinition:"apps.apidocs.modules.resources.ResourcesModule",
ClassDefinition:"apps.apidocs.modules.classDocumentor.ClassDocumentorModule",InterfaceDefinition:"apps.apidocs.modules.classDocumentor.ClassDocumentorModule",SingletonDefinition:"apps.apidocs.modules.classDocumentor.ClassDocumentorModule",TplScriptDefinition:"apps.apidocs.modules.classDocumentor.ClassDocumentorModule"};this._hasDocuments=false},$prototype:{$hasFlowCtrl:true,$publicInterfaceName:"apps.apidocs.modules.documents.IDocumentsModule",init:function(b,a){this._data.content=b.content;apps.apidocs.utils.ResourceProvider.setPackageContent(this._data.content);
this.$callback(a)},loadDocument:function(b){if(b.type=="ResourcesDefinition")alert("Resources not supported yet.");else this.__isDocReady(b)?this._classReady(null,b):this._classLoaded(b)},__isDocReady:function(b){return!!this.documentsReady[b.classpath]},__createValidClasspathsMap:function(){for(var b=this.getData().content,a={},c=0,d=b.length;c<d;c++)a[b[c].name]=true;this.__validClasspaths=a},getValidClasspathsMap:function(){this.__validClasspaths||this.__createValidClasspathsMap();return this.__validClasspaths},
isClasspathValid:function(b){return this.getValidClasspathsMap()[b]===true},_classLoaded:function(b){var a=b.classpath.replace(/\./g,"/"),c=this.getData()[a];if(c)this._modCtrl.$raiseEvent({name:"documentsChanged",select:c});else{b.subModuleName=a;if(c=this.typesAssociation[b.type]){this.$assert(92,!!c);for(var d,e=0;e<this._data.content.length;e++)if(this._data.content[e].name==b.classpath){d=this._data.content[e];break}this.$assert(102,!!d);this.loadSubModules([{refpath:a,classpath:c,initArgs:{docs:d,
parentModule:this}}],{fn:this._classReady,scope:this,args:b})}}},_classReady:function(b,a){if(this.documentsReady[a.classpath]){a=this.documentsReady[a.classpath];if(this._data[a.subModuleName]===undefined)this._data[a.subModuleName]=this[a.subModuleName].getData()}else this.documentsReady[a.classpath]=a;this[a.subModuleName].setData(a,{fn:this.__onDocumentLoadComplete,scope:this,args:a});this[a.subModuleName].$classpath.indexOf("beans.IBeanModule")==-1&&this.__onDocumentLoadComplete(null,a)},__onDocumentLoadComplete:function(b,
a){this._hasDocuments=true;this.$raiseEvent({name:"documentsChanged",select:this[a.subModuleName].getData()})},unloadDocument:function(b){var a="";delete this._data[b.subModuleName];b=this.getData();for(var c in b)if(b.hasOwnProperty(c)&&!this.json.isMetadata(c)){a=c;break}if(a)this.$raiseEvent({name:"documentsChanged",select:this[a].getData()});else this._hasDocuments=false},loadDependenciesSubModules:function(b,a){this.loadSubModules(b,a)},hasDocuments:function(){return this._hasDocuments}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/documents/DocumentsModuleFlow.js
//NxFOn9Dh1D
Aria.classDefinition({$classpath:"apps.apidocs.modules.documents.DocumentsModuleFlow",$extends:"apps.apidocs.controller.FlowController",$implements:["apps.apidocs.modules.documents.IDocumentsModuleFlow","apps.apidocs.controller.IFlowController"],$constructor:function(){this.$FlowController.constructor.call(this);this._states={none:{dependencies:[],transitions:[{on:"doInit",to:"initialised"}]},initialised:{dependencies:[],transitions:[{on:"loadDocument",to:"withDocuments",fn:"loadDocument"}]},withDocuments:{dependencies:[],
transitions:[{on:"loadDocument",to:"withDocuments",fn:"loadDocument"},{on:"unloadDocument",to:"withDocuments"}]}};this._currentState=this._states.none},$destructor:function(){this.$FlowController.destructor.call(this);this._states=this._currentState=null},$prototype:{$publicInterfaceName:"apps.apidocs.modules.documents.IDocumentsModuleFlow",oninitCallback:function(){this.stateTransition("doInit")}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/documents/IDocumentsModule.js
//NxFOn9Dh1D
Aria.interfaceDefinition({$classpath:"apps.apidocs.modules.documents.IDocumentsModule",$extends:"apps.apidocs.controller.IBaseModuleController",$events:{documentsChanged:"raise when a document is added or removed"},$interface:{loadDocument:{$type:"Function"},unloadDocument:{$type:"Function"},loadDependenciesSubModules:{$type:"Function"},hasDocuments:{$type:"Function"},isClasspathValid:{$type:"Function"},getValidClasspathsMap:{$type:"Function"}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/documents/IDocumentsModuleFlow.js
//NxFOn9Dh1D
Aria.interfaceDefinition({$classpath:"apps.apidocs.modules.documents.IDocumentsModuleFlow",$extends:"apps.apidocs.controller.IPublicFlowController",$events:{},$interface:{}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/documents/view/BaseDocumentorScript.js
//NxFOn9Dh1D
(function(){var e,d;Aria.tplScriptDefinition({$classpath:"apps.apidocs.modules.documents.view.BaseDocumentorScript",$dependencies:["apps.apidocs.utils.Common","apps.apidocs.utils.HashHandler"],$constructor:function(){e=apps.apidocs.utils.HashHandler;d=apps.apidocs.utils.Common},$destructor:function(){this._backupScrollPosition()},$prototype:{$dataReady:function(){this.data["view:scrollPositions"]||(this.data["view:scrollPositions"]={});this.data["view:expandedItems"]||(this.data["view:expandedItems"]=
{});var a=this.getItemFromHash();if(a&&this.data["view:lastSelectedMethod"]!=a)this.data["view:expandedItems"][a]=true},$beforeRefresh:function(){this._backupScrollPosition()},$afterRefresh:function(){var a=this.$getElementById("documentContainer"),b=this.data["view:scrollPositions"].documentContainer;b&&a.setScroll(b);if((a=this.getItemFromHash())&&this.data["view:lastSelectedMethod"]!=a)(b=document.getElementById("_methodhook_"+a))&&aria.utils.Dom.scrollIntoView(b);this.data["view:lastSelectedMethod"]=
a},_backupScrollPosition:function(){var a=this.$getElementById("documentContainer");a&&this.$json.setValue(this.data["view:scrollPositions"],"documentContainer",a.getScroll())},getItemFromHash:function(){return e.getItemFromHash()},getClasspathFromHash:function(){return e.getClasspathFromHash()},hasParameters:function(a){return!d.isObjectEmpty(a.commentParams)},isItemHighlighted:function(a,b){return a+":"+b==this.getItemFromHash()},isItemExpanded:function(a,b){return this.data["view:expandedItems"][a+
":"+b]},_onShowInternalsClick:function(){var a,b=apps.apidocs.utils.Common;a=b.isPrivateVisible()?b.VISIBILITY.PUBLIC:b.VISIBILITY.PRIVATE;b.setVisibilityLevel(a,true)},_isInternalsOn:function(){return apps.apidocs.utils.Common.isPrivateVisible()},__onMouseEnter:function(a){a=a.target.getExpando("qcType");if(a==this.data["quickcard:selectedType"])this.__cancelLeaveCallback();else a&&this.$json.setValue(this.data,"quickcard:selectedType",a)},__onMouseLeave:function(a){a.target.getExpando("qcType");
this.__leaveCallback&&aria.core.Timer.cancelCallback(this.__leaveCallback);this.__cancelLeaveCallback();this.__leaveCallback=aria.core.Timer.addCallback({fn:function(){this.$json.setValue(this.data,"quickcard:selectedType",null)},scope:this,delay:500})},__cancelLeaveCallback:function(){this.__leaveCallback&&aria.core.Timer.cancelCallback(this.__leaveCallback)},__getQuickcardItems:function(a){var b=[],c=this.data;if(a=="methods"){b=b.concat(d.getKeys(c.classMethods));if(d.isProtectedVisible())b=b.concat(d.getKeys(c.protectedMethods));
if(d.isPrivateVisible())b=b.concat(d.getKeys(c.privateMethods))}else if(a=="events")b=b.concat(d.getKeys(c.events));else if(a=="properties"){b=b.concat(d.getKeys(c.publicProperties));if(d.isProtectedVisible())b=b.concat(d.getKeys(c.protectedProperties));if(d.isPrivateVisible())b=b.concat(d.getKeys(c.privateProperties))}return b},_getElementHref:function(a,b,c){if(c=="methods")c="method";else if(c=="events")c="event";else if(c=="properties")c="property";return"#"+[a,b,c].join(":")},_onQuickcardItemClick:function(a){a.stopPropagation();
a.preventDefault();a=a.target.getExpando("href");this.__cancelLeaveCallback();this.$json.setValue(this.data,"quickcard:selectedType",null);document.location.hash=a.substring(1);return false},_shortenDescription:function(a){var b=a.toLowerCase();if(b.indexOf("<br")!=-1)a="<pre>"+a.substring(0,b.indexOf("<br"))+"...</pre>";return a.length>100?"<pre>"+a.substring(0,100)+"...</pre>":a},_onToggleItemClick:function(a){a=a.target;if(a=a.getExpando("toggleItem")||a.getParentWithName("div").getExpando("toggleItem")){this.data["view:expandedItems"][a]=
!this.data["view:expandedItems"][a];this.$refresh()}}}})})();
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/documents/view/DocumentsDisplayScript.js
//NxFOn9Dh1D
Aria.tplScriptDefinition({$classpath:"apps.apidocs.modules.documents.view.DocumentsDisplayScript",$dependencies:["apps.apidocs.utils.SplashScreen"],$constructor:function(){this.typesAssociation={BeanDefinition:"apps.apidocs.modules.bean.view.container.BeanContainer",ResourcesDefinition:"apps.apidocs.modules.resources.ResourcesDisplay",ClassDefinition:"apps.apidocs.modules.classDocumentor.view.ClassDocumentor",InterfaceDefinition:"apps.apidocs.modules.classDocumentor.view.ClassDocumentor",SingletonDefinition:"apps.apidocs.modules.classDocumentor.view.ClassDocumentor",
TplScriptDefinition:"apps.apidocs.modules.classDocumentor.view.ClassDocumentor"};this.typesDisplayName={BeanDefinition:"Bean",ResourcesDefinition:"Resources",ClassDefinition:"Class",InterfaceDefinition:"Interface",SingletonDefinition:"Singleton",TplScriptDefinition:"Template Script"}},$prototype:{initDefaultValues:function(){var a,b;for(b in this.data)if(this.data.hasOwnProperty(b)&&!this.$json.isMetadata(b)){a=this.data[b];if(a["view:selected"])break}if(a)a["view:selected"]=true;else this.$logWarn("initDefaultValues: Document is null")},
onModuleEvent:function(a){if(a.name==="documentsChanged")a.select?this.selectDocument(null,a.select):this.deselectAllDocuments()},onFlowEvent:function(a){a.name==="stateChange"&&this.$refresh()},selectDocument:function(a,b){var d,c;for(c in this.data)if(this.data.hasOwnProperty(c)&&!this.$json.isMetadata(c)){d=this.data[c];d["view:selected"]=d===b?true:false}this.$refresh()},deselectAllDocuments:function(){for(var a in this.data)if(this.data.hasOwnProperty(a)&&!this.$json.isMetadata(a))this.data[a]["view:selected"]=
false;this.$refresh()},closeDocument:function(a,b){this.moduleCtrl.unloadDocument(b)}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/apidocsAutocomplete/ApidocsAutocompleteListScript.js
//NxFOn9Dh1D
Aria.tplScriptDefinition({$classpath:"apps.apidocs.modules.packageExplorer.apidocsAutocomplete.ApidocsAutocompleteListScript",$constructor:function(){this._refContainer="suggestionsRows";this._itemShift=0},$prototype:{itemClick:function(a){if(!this.data.disabled)(a=a.target.getExpando("itemIdx",true))&&this.moduleCtrl.itemClick(a)},_getClassForType:function(a){return a=="method"?"Method":a},_isDisplayLimitReached:function(){return this.data.items.length>=apps.apidocs.modules.packageExplorer.apidocsAutocomplete.ApidocsResourcesHandler.MAX_RESULTS},
highlight:function(a,d){var b=a.toLowerCase(),c=d.toLowerCase(),e=b.indexOf(c);if(e!=-1){b=a.substring(0,e);c=a.substring(e,e+d.length);e=a.substring(e+d.length);return[b,"<b>"+c+"</b>",e].join("")}return a},highlightSuggestion:function(a,d){var b={};b.path=this.highlight(a.path,d);if(b.path.indexOf("<b>")!=0){b.path=a.path;var c=d.match(/\.[a-z_\$0-9]+$/i);c=c?c[0].substring(1):d;b.name=this.highlight(a.name,c)}else b.name=a.name;return b}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/apidocsAutocomplete/ApidocsResourcesHandler.js
//NxFOn9Dh1D
(function(){var g,k,l,m,n,o,p=typeof _dt_addMark!="undefined";Aria.classDefinition({$classpath:"apps.apidocs.modules.packageExplorer.apidocsAutocomplete.ApidocsResourcesHandler",$dependencies:["apps.apidocs.modules.packageExplorer.apidocsAutocomplete.ApidocsResourcesHandlerBean","apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.PackageParser","apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.MethodsParser","apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.EventsParser",
"apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.PropertiesParser","apps.apidocs.utils.Common","apps.apidocs.utils.ResourceProvider"],$constructor:function(){l=Aria.getClassRef("apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.PackageParser");m=Aria.getClassRef("apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.MethodsParser");o=Aria.getClassRef("apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.PropertiesParser");n=Aria.getClassRef("apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.EventsParser");
k=this.SORTED_TYPES},$statics:{THRESHOLD:3,SUGGESTION_BEAN:"apps.apidocs.modules.packageExplorer.apidocsAutocomplete.ApidocsResourcesHandlerBean.Suggestion",VALID_ENTRY_REGEXP:/^[\._\$a-z]+$/i,SORTED_TYPES:{ClassDefinition:"A",SingletonDefinition:"B",InterfaceDefinition:"C",BeanDefinition:"D",TplScriptDefinition:"E",method:"G",property:"H",event:"I",ResourcesDefinition:"Z",undefinedDefinition:"ZZ"},MAX_RESULTS:30},$prototype:{getSuggestions:function(b,d){if((g=b)&&this.VALID_ENTRY_REGEXP.test(b)&&
b.length>=this.THRESHOLD){p&&_dt_addMark("START_SEARCH : "+b);var a=l.getMatches(b);a=a.concat(m.getMatches(b));a=a.concat(o.getMatches(b));a=a.concat(n.getMatches(b));a=a.slice(0,this.MAX_RESULTS);a.sort(this.__sortFunction);p&&_dt_addMark("END_SEARCH : "+b);this.$callback(d,a)}else this.$callback(d,null)},__sortFunction:function(b,d){var a=k,c=a[b.type];a=a[d.type];if(!c||!a)aria.core.JsObject.prototype.$logError("No key found for "+b.type+" or "+d.type);if(c<a)return-1;if(c>a)return 1;c=g.toLowerCase();
a=b.name.toLowerCase();var h=d.name.toLowerCase(),e=a.indexOf(c),f=h.indexOf(c);if(f!=-1&&e==-1||e>f)return 1;if(e!=-1&&f==-1||e<f)return-1;var i=b.path.toLowerCase(),j=d.path.toLowerCase();e=i.indexOf(c);f=j.indexOf(c);if(e==0&&f==0){if(i<j)return-1;if(i>j)return 1}if(a<h)return-1;if(a>h)return 1;return 0},getDefaultTemplate:function(){return"apps.apidocs.modules.packageExplorer.apidocsAutocomplete.ApidocsAutocompleteList"},suggestionToLabel:function(){return g}}})})();
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/apidocsAutocomplete/ApidocsResourcesHandlerBean.js
//NxFOn9Dh1D
Aria.beanDefinitions({$package:"apps.apidocs.modules.packageExplorer.apidocsAutocomplete.ApidocsResourcesHandlerBean",$description:"Definition of the suggestions used in the DocCenter resource handler",$namespaces:{base:"aria.widgets.form.AutoCompleteBean",json:"aria.core.JsonTypes"},$beans:{Suggestion:{$type:"base:Suggestion",$description:"...",$properties:{path:{$type:"json:String",$description:"Full package path to Object",$sample:"apps.apidocs.modules.packageExplorer.apidocsAutocomplete",$mandatory:true},
name:{$type:"json:String",$description:"Name of the object",$sample:"ApidocsResourcesHandlerBean"},type:{$type:"json:String",$description:"Type of the object",$sample:"BeanDefinition"}}}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/apidocsAutocomplete/parsers/EventsParser.js
//NxFOn9Dh1D
(function(){var g;Aria.classDefinition({$classpath:"apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.EventsParser",$dependencies:["apps.apidocs.utils.Common"],$implements:["apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.ParserInterface"],$singleton:true,$dependencies:[],$constructor:function(){g=apps.apidocs.utils.Common;this.__eventsData=null},$prototype:{getMatches:function(a){var b=[];a=this.__getFilteredKeys(a);for(var d=this.__getEventsData().events,c=0;c<a.length;c++)for(var e=
a[c],f=d[e],j=e.substring(0,e.indexOf(":")),h=0;h<f.length;h++){var i=f[h];b.push({path:i,name:j,hash:i+":"+e,type:"event"})}return b},__getFilteredKeys:function(a){var b=this.__getEventsData().keys,d=[];a=a.toLowerCase();for(var c=0,e=b.length;c<e;c++)b[c].toLowerCase().indexOf(a)==0&&d.push(b[c]);return d},__getEventsData:function(){if(this.__eventsData!==null)return this.__eventsData;var a={},b=this.__createEventsMap(),d=g.getKeys(b);a.events=b;a.keys=d;return this.__eventsData=a},__createEventsMap:function(){for(var a=
{},b=Provider.getPackageContent(),d=0;d<b.length;d++){var c=b[d],e=c.events,f;for(f in e)if(g.checkKey(e,f)){f+=":event";a[f]||(a[f]=[]);a[f].push(c.name)}}return a}}})})();
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/apidocsAutocomplete/parsers/MethodsParser.js
//NxFOn9Dh1D
(function(){Aria.classDefinition({$classpath:"apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.MethodsParser",$implements:["apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.ParserInterface"],$dependencies:["apps.apidocs.utils.Common","apps.apidocs.utils.ResourceProvider"],$statics:{ITEM_TYPE:"method"},$extends:"apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.VisibilityItemsParser",$singleton:true,$prototype:{_getItemsInClassObject:function(a){return a.methods.concat(a.staticMethods)},
_getItemType:function(){return"method"}}})})();
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/apidocsAutocomplete/parsers/PackageParser.js
//NxFOn9Dh1D
(function(){var g,h;Aria.classDefinition({$classpath:"apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.PackageParser",$implements:["apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.ParserInterface"],$dependencies:["apps.apidocs.utils.ResourceProvider","apps.apidocs.utils.Common"],$singleton:true,$constructor:function(){g=apps.apidocs.utils.ResourceProvider;h=apps.apidocs.utils.Common;this.__flatTree=null;this.__packagesStack=[]},$prototype:{getMatches:function(a){return this.__searchFlatTree(this.__getFlatTree(g.getPackageTree()),
a)},__searchFlatTree:function(a,d){for(var c=[],b=0,e=a.length;b<e;b++){var f=a[b];if(f.hash.toLowerCase().indexOf(d.toLowerCase())==0||f.name.toLowerCase().indexOf(d.toLowerCase())>=0)c.push(f)}return c},__getFlatTree:function(a){if(this.__flatTree!==null)return this.__flatTree;return this.__flatTree=a=this.__createFlatTree(a)},__createFlatTree:function(a,d){var c=[],b;for(b in a)if(h.checkKey(a,b)&&b!==undefined){var e=d?d+"."+b:b;if(aria.utils.Type.isString(a[b]))c.push({path:d,name:b,hash:e,type:a[b]});
else{e=this.__createFlatTree(a[b],e);c=c.concat(e)}}return c}}})})();
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/apidocsAutocomplete/parsers/ParserInterface.js
//NxFOn9Dh1D
Aria.interfaceDefinition({$classpath:"apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.ParserInterface",$interface:{getMatches:{$type:"Function"}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/apidocsAutocomplete/parsers/PropertiesParser.js
//NxFOn9Dh1D
(function(){Aria.classDefinition({$classpath:"apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.PropertiesParser",$implements:["apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.ParserInterface"],$dependencies:["apps.apidocs.utils.Common","apps.apidocs.utils.ResourceProvider"],$extends:"apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.VisibilityItemsParser",$singleton:true,$prototype:{_getItemsInClassObject:function(a){return a.properties.concat(a.staticProperties)},
_getItemType:function(){return"property"}}})})();
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/apidocsAutocomplete/parsers/VisibilityItemsParser.js
//NxFOn9Dh1D
(function(){Aria.classDefinition({$classpath:"apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.VisibilityItemsParser",$implements:["apps.apidocs.modules.packageExplorer.apidocsAutocomplete.parsers.ParserInterface"],$dependencies:["apps.apidocs.utils.Common","apps.apidocs.utils.ResourceProvider"],$statics:{ITEM_TYPE:"__to_override__"},$constructor:function(){this.__itemData=null;Provider=apps.apidocs.utils.ResourceProvider;Common=apps.apidocs.utils.Common},$prototype:{getMatches:function(a){var b=
this.__searchItemsByVisibility(a,"public");if(apps.apidocs.utils.Common.isProtectedVisible())b=b.concat(this.__searchItemsByVisibility(a,"protected"));if(apps.apidocs.utils.Common.isPrivateVisible())b=b.concat(this.__searchItemsByVisibility(a,"private"));return b},__searchItemsByVisibility:function(a,b){for(var c=[],f=this.__getFilteredKeys(a,b),g=this.__getItemsData().items[b],i=this._getItemType(),e=0;e<f.length;e++)for(var d=f[e],j=d.substring(0,d.indexOf(":")),h=g[d],k=0;k<h.length;k++){var l=
h[k];c.push({path:l,name:j,hash:l+":"+d,type:i})}return c},__getFilteredKeys:function(a,b){for(var c=this.__getItemsData().keys[b],f=[],g=a.toLowerCase(),i=a.indexOf("$")!=-1,e=a.indexOf("_")!=-1,d=0,j=c.length;d<j;d++){var h=c[d].toLowerCase();if(h.indexOf(g)==0)f.push(c[d]);else{!i&&h.indexOf("$")==0&&h.indexOf("$"+g)==0&&f.push(c[d]);if(!e&&h.indexOf("_")==0&&(h.indexOf("_"+g)==0||h.indexOf("__"+g)==0))f.push(c[d])}}return f},__getItemsData:function(){if(this.__itemData!==null)return this.__itemData;
var a={},b=this.__createItems(),c={};c["public"]=Common.getKeys(b["public"]);c["private"]=Common.getKeys(b["private"]);c["protected"]=Common.getKeys(b["protected"]);a.items=b;a.keys=c;return this.__itemData=a},__createItems:function(){for(var a={"private":{},"protected":{},"public":{}},b=Provider.getPackageContent(),c=0;c<b.length;c++)for(var f=b[c],g=this._getItemsInClassObject(f),i=0;i<g.length;i++){var e=g[i],d=e.shortName+":"+this._getItemType();e=a[e.visibility];e[d]||(e[d]=[]);e[d].push(f.name)}return a},
_getItemsInClassObject:function(a){return a.items.concat(a.staticItems)},_getItemType:function(){return"item"}}})})();
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/DataModel.js
//NxFOn9Dh1D
Aria.beanDefinitions({$package:"apps.apidocs.modules.packageExplorer.DataModel",$description:"Definition of the package explorer data model for Documentation Center",$namespaces:{json:"aria.core.JsonTypes"},$beans:{Packages:{$type:"json:Map",$description:"Map of registered packages",$default:{},$contentType:{$type:"Package",$description:"A registered package"}},Package:{$type:"json:Map",$description:"Doc Center package",$contentType:{$type:"json:MultiTypes",$description:"Content of a package, can be either packages or class definition",
$contentTypes:[{$type:"ContentDefinition"},{$type:"Package"}]}},ContentDefinition:{$type:"json:Enum",$description:"Type of content",$enumValues:["ClassDefinition","InterfaceDefinition","BeanDefinition","ResourcesDefinition","SingletonDefinition","TplScriptDefinition"]}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/IPackageExplorerModule.js
//NxFOn9Dh1D
Aria.interfaceDefinition({$classpath:"apps.apidocs.modules.packageExplorer.IPackageExplorerModule",$extends:"apps.apidocs.controller.IBaseModuleController",$events:{displayContent:"raised when a content is selected in the package explorer"},$interface:{getClasspathFromHash:{$type:"Function"},selectClasspath:{$type:"Function"}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/IPackageExplorerModuleFlow.js
//NxFOn9Dh1D
Aria.interfaceDefinition({$classpath:"apps.apidocs.modules.packageExplorer.IPackageExplorerModuleFlow",$extends:"apps.apidocs.controller.IPublicFlowController",$events:{packageUpdated:"raised when the package structure as changed",displayContent:"raised when a content is selected in the package explorer"}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/PackageExplorerModule.js
//NxFOn9Dh1D
(function(){var e,c;Aria.classDefinition({$classpath:"apps.apidocs.modules.packageExplorer.PackageExplorerModule",$extends:"aria.templates.ModuleCtrl",$implements:["apps.apidocs.modules.packageExplorer.IPackageExplorerModule"],$dependencies:["apps.apidocs.modules.packageExplorer.DataModel","apps.apidocs.modules.packageExplorer.PackageModuleServices","aria.utils.HashManager","apps.apidocs.utils.HashHandler","apps.apidocs.utils.Common","apps.apidocs.utils.ResourceProvider"],$constructor:function(){this._dataBeanName=
"apps.apidocs.modules.packageExplorer.DataModel.Packages";this._packageServices=new apps.apidocs.modules.packageExplorer.PackageModuleServices;e=apps.apidocs.utils.ResourceProvider;c=apps.apidocs.utils.Common;aria.utils.QueryString.getKeyValue("internals")=="true"&&c.setVisibilityLevel(c.VISIBILITY.PRIVATE);this.$ModuleCtrl.constructor.call(this)},$prototype:{$publicInterfaceName:"apps.apidocs.modules.packageExplorer.IPackageExplorerModule",init:function(b,a){this._rootPackages=b.rootPackages;this._packageServices.update(this._rootPackages,
{fn:this.__onServiceUpdateCompleted,scope:this,args:{initCb:a}})},getClasspathFromHash:function(){return apps.apidocs.utils.HashHandler.getClasspathFromHash()},__onServiceUpdateCompleted:function(b,a){this.setData(a.data);e.setPackageTree(this.getData().packageTree);this.$callback(a.initCb)},selectClasspath:function(b){var a=this.getData();aria.utils.Json.setValue(a,"view:selectedClasspath",b);this.__expandClasspath(b)},__expandClasspath:function(b){b=b.split(".");for(var a=this.getData().packageTree,
d=0;a&&d<b.length;d++){a["view:selected"]=true;a=a[b[d]]}},loadDependenciesSubModules:function(b,a){this.loadSubModules(b,a)}}})})();
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/PackageExplorerModuleFlow.js
//NxFOn9Dh1D
Aria.classDefinition({$classpath:"apps.apidocs.modules.packageExplorer.PackageExplorerModuleFlow",$extends:"apps.apidocs.controller.FlowController",$implements:["apps.apidocs.modules.packageExplorer.IPackageExplorerModuleFlow","apps.apidocs.controller.IFlowController"],$constructor:function(){this.$FlowController.constructor.call(this);this._states={none:{dependencies:[],transitions:[{on:"doInit",to:"initialised"}]},initialised:{dependencies:[],transitions:[{on:"displayContent",to:"initialised"}]}};
this._currentState=this._states.none},$destructor:function(){this._states=this._currentState=null;this.$FlowController.destructor.call(this)},$prototype:{$publicInterfaceName:"apps.apidocs.modules.packageExplorer.IPackageExplorerModuleFlow",oninitCallback:function(){this.stateTransition("doInit")},ondisplayContentCallBegin:function(a){a=a.args;this.stateTransition("displayContent",{classpath:a[0],type:a[1]})}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/PackageModuleServices.js
//NxFOn9Dh1D
Aria.classDefinition({$classpath:"apps.apidocs.modules.packageExplorer.PackageModuleServices",$constructor:function(a){this._modCtrl=a;this.__updateCallback=this.__tmpData=null;this._waitingPackageDescription=0},$prototype:{_loadPackageDescription:function(a,b,c){this._waitingPackageDescription++;Aria.load({classes:[a+b+"._packageTree"],oncomplete:{fn:this._loadPackageSuccess,scope:this,args:{nspace:a,packageName:b,data:c}},onerror:{override:true,fn:this._loadFinished,scope:this}})},update:function(a,
b){this.$assert(62,this.__tmpData===null);this.__tmpData={};this.__updateCallback=b;for(var c=0,f=a.length;c<f;c+=1)this._loadPackageDescription("",a[c],this.__tmpData)},_loadPackageSuccess:function(a){var b=a.data;a=Aria.getClassRef(a.nspace+a.packageName+"._packageTree");if(!b.packageTree)b.packageTree={};for(var c in a.tree)b.packageTree[c]=a.tree[c];b.packageTree=this.__createSortedTree(b.packageTree);this._loadFinished()},__createSortedTree:function(a){if(typeof a=="string")return a;var b=[],
c;for(c in a)a.hasOwnProperty(c)&&b.push(c);b=b.sort(function(d,e){if(typeof a[d]!="string")d="aaa"+d;d=d.toLowerCase();if(typeof a[e]!="string")e="aaa"+e;e=e.toLowerCase();return d<e?-1:d>e?1:0});var f={};for(c=0;c<b.length;c++){var g=b[c];f[g]=this.__createSortedTree(a[g])}return f},_loadFinished:function(){this._waitingPackageDescription-=1;if(!this._waitingPackageDescription)if(this.__tmpData){this.$assert(135,this.__updateCallback);this.__updateCallback.args.data=this.__tmpData;this.$callback(this.__updateCallback);
this.__tmpData=null}}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/packageExplorer/view/PackageTreeDisplayScript.js
//NxFOn9Dh1D
Aria.tplScriptDefinition({$classpath:"apps.apidocs.modules.packageExplorer.view.PackageTreeDisplayScript",$dependencies:["aria.utils.Type","apps.apidocs.utils.Common"],$prototype:{$dataReady:function(){if(!this.data["view:initialized"]){for(var a in this.data)if(apps.apidocs.utils.Common.checkKey(this.data,a))this.data[a]["view:selected"]=true;this.data["view:initialized"]=true;this.data["view:displayedTypes"]=["Class","Interface","Bean","Singleton","TplScript"];this.data["view:search"]={value:{path:"",
name:"",type:""}};this.data["view:scrollPositions"]={}}},$beforeRefresh:function(){this._backupScrollPosition()},$afterRefresh:function(){if(!this.$afterRefresh.__doOnce){this.$afterRefresh.__doOnce=true;apps.apidocs.utils.SplashScreen.remove()}var a=this.$getElementById("packageContainer"),b=this.data["view:scrollPositions"].packageContainer;b&&a.setScroll(b);if(this.data["view:packageClicked"])this.data["view:packageClicked"]=false;else(a=document.getElementById("selectedObject"))&&aria.utils.Dom.scrollIntoView(a)},
_backupScrollPosition:function(){var a=this.$getElementById("packageContainer");a&&this.$json.setValue(this.data["view:scrollPositions"],"packageContainer",a.getScroll())},onModuleEvent:function(a){a.name=="displayContent"&&this.$refresh()},packageClick:function(a,b){b["view:selected"]=!b["view:selected"];this.data["view:packageClicked"]=true;this.$refresh()},contentClick:function(a,b){document.location.hash=b.classpath},isFolderEmpty:function(a){var b=true;if(aria.utils.Type.isString(a))return b;
for(var d in a)if(apps.apidocs.utils.Common.checkKey(a,d)){var c=a[d];if(aria.utils.Type.isString(c)){if(this.isInDisplayedTypes(c)){b=false;break}}else if(!this.isFolderEmpty(c)){b=false;break}}return b},isInDisplayedTypes:function(a){a=a.replace(/Definition$/,"");return aria.utils.Array.contains(this.data["view:displayedTypes"],a)},_getStyleForDepth:function(a){return"padding-left:"+(10+a*20)+"px;margin-left:"+Math.min(0,-(a-1)*20-10)+"px;"},_onAutoCompleteChange:function(){var a=this.data["view:search"].value;
if(aria.utils.Type.isObject(a))document.location.hash=a.hash}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/resources/IResourcesModule.js
//NxFOn9Dh1D
Aria.interfaceDefinition({$classpath:"apps.apidocs.modules.resources.IResourcesModule",$extends:"aria.templates.IModuleCtrl",$interface:{setData:{$type:"Function"}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/resources/ResourcesDisplayScript.js
//NxFOn9Dh1D
Aria.tplScriptDefinition({$classpath:"apps.apidocs.modules.resources.ResourcesDisplayScript",$prototype:{initDefaultValues:function(){}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/modules/resources/ResourcesModule.js
//NxFOn9Dh1D
Aria.classDefinition({$classpath:"apps.apidocs.modules.resources.ResourcesModule",$extends:"aria.templates.ModuleCtrl",$implements:["apps.apidocs.modules.resources.IResourcesModule"],$dependencies:["aria.utils.Type"],$constructor:function(){this.$ModuleCtrl.constructor.call(this)},$events:{},$prototype:{$publicInterfaceName:"apps.apidocs.modules.resources.IResourcesModule",setData:function(){this.$ModuleCtrl.setData.apply(this,arguments);if(this._data.classpath){this._data.resources={};var b=Aria.getClassRef(this._data.classpath),
a;for(a in b)if(a.substring(0,1)!="$"&&a!="classDefinition"&&a!="constructor")if(aria.utils.Type.isObject(b[a]))this._data.resources[a]=b[a]}}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/utils/Common.js
//NxFOn9Dh1D
(function(){Aria.classDefinition({$classpath:"apps.apidocs.utils.Common",$singleton:true,$dependencies:["aria.utils.Json"],$statics:{APP_TITLE:"Aria Templates API Docs",VISIBILITY:{PUBLIC:0,PROTECTED:1,PRIVATE:2}},$constructor:function(){this.setVisibilityLevel(0)},$prototype:{setWindowTitle:function(a){window.document.title=a+" - "+apps.apidocs.utils.Common.APP_TITLE},isPrivateVisible:function(){return this.__visibilityLevel>=this.VISIBILITY.PRIVATE},isProtectedVisible:function(){return this.__visibilityLevel>=
this.VISIBILITY.PROTECTED},setVisibilityLevel:function(a,b){if(aria.utils.Type.isNumber(a)&&this.__visibilityLevel!=a){this.__visibilityLevel=a;b&&Aria.rootTemplates[0].$refresh()}else this.$logError("Expected number as parameter for apps.apidocs.utils.Common:setVisibilityLevel")},isVisibilityLevelEnabled:function(a){if(aria.utils.Type.isString(a)&&typeof this.VISIBILITY[a.toUpperCase()]!="undefined")return this.__visibilityLevel>=this.VISIBILITY[a.toUpperCase()]},checkKey:function(a,b){var c=a.hasOwnProperty(b);
return c=(c=c&&!aria.utils.Json.isMetadata(b))&&b.indexOf("view:")!=0},getKeys:function(a){var b=[],c;for(c in a)this.checkKey(a,c)&&b.push(c);return b},isObjectEmpty:function(a){return this.getKeys(a).length===0},isLastKey:function(a,b){return b===this.getLastKey(a)},getLastKey:function(a){var b=null,c;for(c in a)if(this.checkKey(a,c))b=c;return b}}})})();
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/utils/HashHandler.js
//NxFOn9Dh1D
(function(){Aria.classDefinition({$classpath:"apps.apidocs.utils.HashHandler",$singleton:true,$dependencies:["aria.utils.HashManager"],$constructor:function(){},$prototype:{getClasspathFromHash:function(){var a=document.location.hash;return a.indexOf(":")!=-1?a.substring(1,a.indexOf(":")):a.substring(1)},getItemFromHash:function(){var a=document.location.hash.substring(1),b=null;if(a.indexOf(":")!=-1)b=a.substring(a.indexOf(":")+1);return b}}})})();
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/utils/PackageContent.js
//NxFOn9Dh1D
Aria.classDefinition({$classpath:"apps.apidocs.utils.PackageContent",$singleton:true,$constructor:function(){},$prototype:{filterProperties:function(b,e){for(var c={},d=0,a=0;a<b.length;a++)if(b[a]&&b[a].visibility==e){c[b[a].shortName]=b[a];d++}return d>0?c:null},filterMethods:function(b,e){for(var c={},d=0,a=0;a<b.length;a++)if(b[a]&&"$destructor"!=b[a].shortName&&b[a].visibility==e){for(var h={},f=0;f<b[a].parameters.length;f++){var g=b[a].parameters[f];h[g.name]={desc:g.desc,type:g.type}}c[b[a].shortName]=
{description:b[a].desc,example:b[a].example,commentReturn:{desc:b[a].returns.name,type:b[a].returns.type},commentParams:h,isStatic:b[a].isStatic};d++}return d>0?c:null}}});
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/utils/ResourceProvider.js
//NxFOn9Dh1D
(function(){Aria.classDefinition({$classpath:"apps.apidocs.utils.ResourceProvider",$singleton:true,$events:{packageContentChanged:"Event fired when the PackageContent data has changed (or has been set for the first time)",packageTreeChanged:"Event fired when the PackageTree data has changed (or has been set for the first time)"},$dependencies:[],$constructor:function(){this._packageTree=this._packageContent=null},$destructor:function(){},$prototype:{setPackageContent:function(a){if(a!=this._packageContent){this._packageContent=
a;this.$raiseEvent("packageContentChanged")}},setPackageTree:function(a){if(a!=this._packageTree){this._packageTree=a;this.$raiseEvent("packageTreeChanged")}},isPackageContentAvailable:function(){return this._packageContent!=null},isPackageTreeAvailable:function(){return this._packageTree!=null},getPackageContent:function(){return this._packageContent},getPackageTree:function(){return this._packageTree}}})})();
//NxFOn9Dh1D
//LOGICAL-PATH:apps/apidocs/utils/SplashScreen.js
//NxFOn9Dh1D
(function(){Aria.classDefinition({$classpath:"apps.apidocs.utils.SplashScreen",$singleton:true,$constructor:function(){this.constructor.superclass.constructor.apply(this,arguments);this.isInFailedMode=false},$destructor:function(){this._splashScreenContainer=this._splashScreenElement=null;this.constructor.superclass.$destructor.apply(this,arguments)},$prototype:{getSplashScreen:function(){if(!this._splashScreenElement)this._splashScreenElement=document.getElementById("splashScreen");return this._splashScreenElement},
getContainer:function(){if(!this._splashScreenContainer)this._splashScreenContainer=document.getElementById("splashScreenContainer");return this._splashScreenContainer},remove:function(){var a=this.getContainer();if(a){window.setTimeout(function(){a.className+=" invisible"},500);window.setTimeout(function(){window.clearInterval(window.__splashUpdate);a.parentNode.removeChild(a)},1E3)}},setFailed:function(){if(!this.isInFailedMode){var a=this.getSplashScreen();this.isInFailedMode=true;if(a){window.clearInterval(window.__splashUpdate);
a.innerHTML="Apidocs loading<br/>failed";a.style.color="#D55";a.style.textShadow="0 -1px 1px #800"}}}}})})();