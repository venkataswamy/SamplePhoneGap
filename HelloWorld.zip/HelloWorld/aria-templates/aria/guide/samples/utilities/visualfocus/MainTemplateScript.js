/*
 * Copyright Amadeus
 */
/**
 * TODOC
 * @class samples.templates.focushandling.MainTemplateScript
 */
Aria.tplScriptDefinition({
	$classpath:  'samples.utilities.visualfocus.MainTemplateScript',
	$prototype:{
		setVisualFocus : function () {
			aria.core.AppEnvironment.setEnvironment({
				appOutlineStyle : this.outlineStyle.style
			}, null, true);
		},
		resetVisualFocus : function () {
			aria.core.AppEnvironment.setEnvironment({
				appOutlineStyle : null
			}, null, true);
		}
	}
});