/*
 * Copyright Amadeus
 */
Aria.classDefinition({
	$classpath : "samples.utilities.jsonp.Data",
	$constructor : function () {}, 
	$prototype : {
		data : {
			url : "samples/utilities/jsonp/sampleResponse.jsonp",
			response : ""
		}
	}
})