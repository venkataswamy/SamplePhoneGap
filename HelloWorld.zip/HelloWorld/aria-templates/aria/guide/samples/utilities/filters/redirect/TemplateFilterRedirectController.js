/*
 * Copyright Amadeus
 */
/**
 * This is the module controller for the filter redirect sample.
 */
Aria.classDefinition({
	$classpath : 'samples.utilities.filters.redirect.TemplateFilterRedirectController',
	$extends : 'aria.templates.ModuleCtrl',
	$implements : ['samples.utilities.filters.redirect.ITemplateFilterRedirectController'],
	$dependencies : ['aria.utils.Data'],
	$constructor : function () {
		this.$ModuleCtrl.constructor.call(this);
		this.setData({
			simpleRequestUrl : (aria.core.DownloadMgr.resolveURL(this.$package.replace(/\./g, "/")
					+ "/files/simpleTargetFile.txt", true)),
			jsonpUrl : "http://search.twitter.com/search.json?q=ariatemplates&rpp=20"
		});
	},
	$prototype : {
		$publicInterfaceName : "samples.utilities.filters.redirect.ITemplateFilterRedirectController",

		/**
		 * Send a request with aria.core.IO.asyncRequest.
		 */
		sendSimpleRequest : function () {
			aria.core.IO.asyncRequest({
				sender : {
					classpath : this.$classpath
				},
				url : this.getData().simpleRequestUrl,
				method : "GET",
				callback : {
					scope : this,
					fn : this._simpleRequestCallback
				}
			});
		},

		/**
		 * Callback called when the response to the request done in sendSimpleRequest is received.
		 * @param {aria.core.CfgBeans.IOAsyncRequestResponseCfg} res
		 * @private
		 */
		_simpleRequestCallback : function (res) {
			var data = this.getData();
			this.json.setValue(data, "simpleRequestResult", res.responseText);
			this.$raiseEvent("responseReceived");
		},

		/**
		 * Send a request through the RequestMgr.
		 */
		sendRequestThroughRequestMgr : function () {
			this.submitJsonRequest("myRequest", {}, this._requestThroughRequestMgrCallback);
		},

		/**
		 * Callback called when the response to the request sent in sendRequestThroughRequestMgr is received.
		 * @private
		 */
		_requestThroughRequestMgrCallback : function (res) {
			var data = this.getData();
			this.json.setValue(data, "requestMgrRequestResult", res.response ? res.response.serverMessage : null);
			if (res.errorData) {
				// change the type of the error so that the icon is well displayed
				var messageBean = res.errorData.messageBean;
				if (messageBean.type == "HTTPERROR") {
					messageBean.type = aria.utils.Data.TYPE_ERROR;
				}
			}
			this.json.setValue(data, "requestMgrRequestErrors", res.errorData ? [res.errorData.messageBean] : null);
			this.$raiseEvent("responseReceived");
		},

		/**
		 * Send a request with aria.core.IO.jsonp.
		 */
		sendJsonpRequest : function () {
			aria.core.IO.jsonp({
				sender : {
					classpath : this.$classpath
				},
				url : this.getData().jsonpUrl,
				callback : {
					scope : this,
					fn : this._jsonpRequestCallback
				}
			});
		},

		/**
		 * Callback called when the response to the request done in sendJsonpRequest is received.
		 * @param {aria.core.CfgBeans.IOAsyncRequestResponseCfg} res
		 * @private
		 */
		_jsonpRequestCallback : function (res) {
			var data = this.getData();
			var text = this.json.convertToJsonString(res.responseJSON, {
				indent : "\t"
			});
			this.json.setValue(data, "jsonpResult", text);
			this.$raiseEvent("responseReceived");
		}

	}
});