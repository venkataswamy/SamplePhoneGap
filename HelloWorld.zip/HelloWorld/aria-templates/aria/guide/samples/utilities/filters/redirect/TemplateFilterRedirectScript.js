/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.utilities.filters.redirect.TemplateFilterRedirectScript',
	$statics : {
		FILTER_CLASSPATH : "samples.utilities.filters.redirect.SampleRedirectFilter"
	},
	$constructor : function () {
		this.baseDirectory = aria.core.DownloadMgr.resolveURL(this.$package.replace(/\./g, "/"), true);
	},
	$prototype : {

		onModuleEvent : function (evt) {
			if (evt.name == "responseReceived") {
				this.$refresh();
			}
		},

		isFilterEnabled : function () {
			return aria.core.IOFiltersMgr.isFilterPresent(this.FILTER_CLASSPATH);
		},

		enableFilter : function () {
			if (!this.isFilterEnabled()) {
				aria.core.IOFiltersMgr.addFilter(this.FILTER_CLASSPATH);
				this.$refresh();
			}
		},

		disableFilter : function () {
			if (aria.core.IOFiltersMgr.removeFilter(this.FILTER_CLASSPATH)) {
				this.$refresh();
			}
		}

	}
});