/*
 * Copyright Amadeus
 */
/**
 * Public interface for the TemplateFilterRedirectController.
 */
Aria.interfaceDefinition({
	$classpath : 'samples.utilities.filters.redirect.ITemplateFilterRedirectController',
	$extends : 'aria.templates.IModuleCtrl',
	$events : {
		"responseReceived" : "Raised when a response is received from the server."
	},
	$interface : {

		sendSimpleRequest : "Function",
		
		sendRequestThroughRequestMgr: "Function",
		
		sendJsonpRequest : "Function"
	}
});
