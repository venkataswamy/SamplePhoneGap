/*
 * Copyright Amadeus
 */
/**
 * Sample filter used to redirect requests.
 */
Aria.classDefinition({
	$classpath : 'samples.utilities.filters.redirect.SampleRedirectFilter',
	$extends : 'aria.core.IOFilter',
	$constructor : function (args) {
		this.$IOFilter.constructor.call(this, args);
		this.baseDirectory = this.$package.replace(/\./g, "/");
	},
	$prototype : {
		/**
		 * Method called before a request is sent to get a chance to change its arguments
		 * @param {aria.core.CfgBeans.IOAsyncRequestCfg} request
		 */
		onRequest : function (req) {
			var sender = req.sender;

			// first case: request through aria.core.IO.asyncRequest:
			if (sender && sender.classpath == "samples.utilities.filters.redirect.TemplateFilterRedirectController"
					&& /simpleTargetFile\.txt$/.test(req.url)) {
				var redirectedFile = this.baseDirectory + "/files/simpleRedirectedFile.txt";
				this.redirectToFile(req, redirectedFile);
			}

			// second case: request through aria.modules.RequestMgr:
			if (sender && sender.classpath == "aria.modules.RequestMgr") {
				var requestObject = sender.requestObject;
				if (requestObject.moduleName == "samples.utilities.filters.redirect"
						&& requestObject.actionName == "myRequest") {
					// note that we could redirect to different files depending on actionName
					// or even request data (in sender.requestData)
					var redirectedFile = this.baseDirectory + "/files/requestMgrRedirectedResponse.xml";
					this.redirectToFile(req, redirectedFile);
				}
			}

			// third case: request through aria.core.IO.jsonp:
			if (sender && sender.classpath == "samples.utilities.filters.redirect.TemplateFilterRedirectController"
					&& req.jsonp != null) {
				var redirectedFile = this.baseDirectory + "/files/jsonpRedirectedFile.txt";
				this.redirectToFile(req, redirectedFile);
			}

		}
	}
});