/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.utilities.loadingoverlay.LoadingOverlayTemplateScript',
	$dependencies : ['aria.utils.DomOverlay'],
	$constructor : function () {
		this.counter = 0;
	},
	$destructor : function () {
		if (this.process) {
			aria.core.Timer.cancelCallback(this.process);
		}
	},
	$prototype : {
		blipping : 0,
		blippingSection : 0,
		clickMe : function (arg) {
			var next = (this.blipping + 1) % 2;
			var thisDiv = this.$getElementById("overlay" + this.blipping);
			var nextDiv = this.$getElementById("overlay" + next);

			thisDiv.setProcessingIndicator(true);
			nextDiv.setProcessingIndicator(false);

			this.blipping = next;
		},

		triggerRefresh : function () {
			this.stopIndicator();
			this.$refresh();
		},

		playSection : function () {
			var next = (this.blippingSection + 1) % 2;
			var thisSection = this.$getElementById("section" + this.blippingSection);
			var nextSection = this.$getElementById("section" + next);

			// Refresh the section
			thisSection.setProcessingIndicator(true, "Text on the overlay");
			nextSection.setProcessingIndicator(false);

			this.blippingSection = next;
		},

		toggle : function () {
			this.$json.setValue(this.data, "automatic", !this.data.automatic);
		},

		wholePage : function () {
			aria.utils.DomOverlay.create(Aria.$window.document.body, "Text on the overlay");

			setTimeout(function () {
				aria.utils.DomOverlay.detachFrom(Aria.$window.document.body);
			}, 4000);
		},
		processIndicator : function (menuItem) {
			if (this.data && this.data[menuItem].loaded === false) {
				var maxDots = 3, dots = this.counter % maxDots + 2, timer = aria.core.Timer;
				this.process = timer.addCallback({
					fn : function (menuItem) {

						this.displayDots = "";

						for (var i = 0; i < dots; i++) {
							this.t2 = timer.addCallback({
								fn : function (menuItem) {
									if (!this.data || this.data[menuItem].loaded === true) {
										return;
									}
									this.$json.setValue(this.data[menuItem], 'loading', this.displayDots);
									this.displayDots += '.';
								},
								scope : this,
								delay : 500,
								args : menuItem
							});
						}
						this.counter++;
						this.processIndicator(menuItem);
					},
					scope : this,
					delay : 600,
					args : menuItem
				});
			}
		},
		startIndicator : function (e, menuItem) {
			this.stopIndicator();
			this.playSection();
			this.data[menuItem].loaded = false;
			this.processIndicator(menuItem);
		},
		stopIndicator : function () {
			if (this.process) {
				aria.core.Timer.cancelCallback(this.process);
				aria.core.Timer.cancelCallback(this.t2);
			}

			this.$json.setValue(this.data["accommodation"], 'loaded', true)
			this.$json.setValue(this.data["hotels"], 'loaded', true)
			this.$json.setValue(this.data["flights"], 'loaded', true)
			this.$json.setValue(this.data["accommodation"], 'loading', "")
			this.$json.setValue(this.data["hotels"], 'loading', "")
			this.$json.setValue(this.data["flights"], 'loading', "")
		}
	}
});