/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
    $classpath: "samples.printpage.PrintTestPageScript",
    $prototype: {
  
        toggleDisplay : function (e,args) {
        	this.display = (this.display != "visible") ? "visible" : "hidden";
        	this.$refresh(args);	
        }
    }
});