/*
 * Copyright Amadeus
 */
/**
 * Public interface for the template controller.
 * @class samples.widgetLibs.html.template.ISimpleTemplateController
 */
Aria.interfaceDefinition({
	$classpath : 'samples.widgetLibs.html.template.ISimpleTemplateController',
	$extends : "aria.templates.IModuleCtrl",
	$events : {

}	,
	$interface : {

}
});
