/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : "samples.widgetLibs.html.autocomplete.InputWidgetScript",
	$dependencies : ["samples.widgetLibs.html.autocomplete.Resources", "aria.html.controllers.Suggestions"],
	$prototype : {
		$dataReady : function () {
			this.suggestionsController = Aria.getClassInstance("aria.html.controllers.Suggestions");

			this.suggestionsController.setResourcesHandler(Aria.getClassInstance("samples.widgetLibs.html.autocomplete.Resources"));
		},

		select : function (evt, suggestion) {
			evt.preventDefault(true);

			this.suggestionsController.setSelected(suggestion);

			this.$json.setValue(this.data, "value", suggestion.label);
		},

		closeSuggestions : function (evt) {
			evt.preventDefault(true);

			this.suggestionsController.empty();
		},

		cancelValue : function (evt) {
			evt.preventDefault(true);

			this.suggestionsController.setSelected(null);

			this.$json.setValue(this.data, "value", "");
		}
	}
});