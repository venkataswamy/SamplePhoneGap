/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : "samples.widgetLibs.gallery.ImageGalleryScript",
	$prototype : {
		setVisible : function (evt, index) {
			this.$json.setValue(this.data, "visible", index);
		}
	}
});