/*
 * Copyright Amadeus
 */
Aria.classDefinition({
        $classpath : "samples.widgetLibs.gallery.ImageLibrary",
        $extends : "aria.widgetLibs.WidgetLib",
        $singleton : true,
        $prototype : {
                widgets : {
                        "Gallery" : "samples.widgetLibs.gallery.GalleryWidget"
                }
        }
});