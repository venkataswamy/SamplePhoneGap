/*
 * Copyright Amadeus
 */
Aria.classDefinition({
	$classpath : "samples.widgetLibs.gallery.DataModel",
	$statics : {
		data : {
			images : [{
						url : "one.jpg",
						desc : "Aria Templates Custom Widget Library"
					}, {
						url : "three.jpg",
						desc : "aria.widgetLibs.BaseWidget is the base class for all widgets"
					}, {
						url : "two.jpg",
						desc : "aria.widgetLibs.BindableWidget gives you a convenient way to bind properties in the datamodel"
					}, {
						url : "four.jpg",
						desc : "aria.html.Element makes event listeners simple to use"
					}, {
						url : "five.jpg",
						desc : "Check the code of GalleryWidget..."
					}, {
						url : "six.jpg",
						desc : "... you'll see how easly you can create a widget!"
					}, {
						url : "seven.jpg",
						desc : "Have fun with Aria Templates"
					}],

			visible : 0
		}
	}
});