/*
 * Copyright Amadeus
 */
/**
 * Sample custom module interface.
 * @class samples.customization.samplecustommodule1.IModule
 */
Aria.interfaceDefinition({
	$classpath : 'samples.customization.samplecustommodule1.IModule',
	$extends : 'aria.templates.IModuleCtrl',
	$interface : {
		myCustomModule1Function : function () {}
	}
});
