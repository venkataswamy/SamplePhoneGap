/*
 * Copyright Amadeus
 */
/**
 * TODOC
 * @class samples.templates.focushandling.ATemplateScript
 */
Aria.tplScriptDefinition({
	$classpath:  'samples.templates.focushandling.ATemplateScript',
	$prototype:{
		$focusFromParent : function () {
			this.$focus("checkbox2");
		}
	}
});