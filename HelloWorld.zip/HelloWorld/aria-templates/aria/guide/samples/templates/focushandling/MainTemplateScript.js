/*
 * Copyright Amadeus
 */
/**
 * TODOC
 * @class samples.templates.focushandling.MainTemplateScript
 */
Aria.tplScriptDefinition({
	$classpath:  'samples.templates.focushandling.MainTemplateScript',
	$prototype:{
		giveFocusToA : function () {
			this.$focus("A")
		},
		giveFocusToB : function () {
			this.$focus("B")
		}
	}
});