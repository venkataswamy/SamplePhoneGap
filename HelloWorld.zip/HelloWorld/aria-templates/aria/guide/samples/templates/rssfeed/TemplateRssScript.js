/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.templates.rssfeed.TemplateRssScript',
	$dependencies : ['aria.utils.Xml','aria.modules.RequestMgr'],
	$prototype : {
		getRssFeedClick : function () {
			// FIXME: baseURL is not available aria.modules.RequestMgr starting from Aria Templates 1.0-34
			var url = aria.modules.RequestMgr.baseURL + "/samples/templates/rssfeed/AmadeusRSSFeed.xml";
			aria.core.IO.asyncRequest({				
//				url : "http://localhost/AriaTemplates/samples/widgets/container/templates/RSSSample.xml",
				url : url,
				callback: {
					fn: this._onRssReceive,
					scope: this
				}
			})			
		},
		
		_onRssReceive : function(asyncRes){
			var json = aria.utils.Xml.convertXmlToJson(asyncRes.responseText);			
			this.$json.setValue(this.data,"rssTitle",json.rss.channel.title);
			this.$json.setValue(this.data,"rssItemTitle",json.rss.channel.item[0].title);
			this.$json.setValue(this.data,"rssItemDesc",json.rss.channel.item[0].description);
			this.$refresh();
		}		
	}
});