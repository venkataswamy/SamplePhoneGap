/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath:  'samples.templates.csstemplate.SampleTemplateScript',
	$prototype:{
		getRowClass : function (index) {
			return (index%2 == 0) ? "evenRow" : "oddRow";
		}
	}
});