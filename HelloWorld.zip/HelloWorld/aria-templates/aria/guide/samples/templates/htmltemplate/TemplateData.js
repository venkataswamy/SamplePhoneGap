/*
 * Copyright Amadeus
 */
Aria.classDefinition({
	$classpath : 'samples.templates.htmltemplate.TemplateData',
	$constructor : function () {},
	$prototype : {

		data : {
			people : [{
						name : 'John',
						age : 19,
						livesIn : "Europe"
					}, {
						name : 'Francis',
						age : 25,
						livesIn : "Europe"
					}, {
						name : 'Mary',
						age : 70,
						livesIn : "North America"
					}, {
						name : 'Pedro',
						age : 35,
						livesIn : "South America"
					}, {
						name : 'Lucia',
						age : 2,
						livesIn : "Asia"
					}, {
						name : 'Mariko',
						age : 22,
						livesIn : "Asia"
					}]
		}

	}
});