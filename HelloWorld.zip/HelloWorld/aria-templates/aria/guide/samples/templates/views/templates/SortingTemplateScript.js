/*
 * Copyright Amadeus
 */
/**
 * @class samples.templates.views.templates.SortingTemplateScript
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.templates.views.templates.SortingTemplateScript',
	$prototype : {
		sortByName : function (o) {
			//console.log(o.value.name)
			return o.value.name;
		},
		
		toggleSort : function () {
			//console.log()
			this.hdetails.toggleSortOrder('SortByName',this.sortByName);
			this.$refresh();
			return false;
		}
	}
});