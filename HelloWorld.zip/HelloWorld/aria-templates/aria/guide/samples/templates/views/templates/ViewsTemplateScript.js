/*
 * Copyright Amadeus
 */
/**
 * TODOC
 * @class samples.templates.views.templates.FilteringTemplateScript
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.templates.views.templates.ViewsTemplateScript',
	$prototype : {
		initView : function () {
			if (!this.data['view:TemplateView']) {
				this.data['view:TemplateView'] = "Basic";
			}
			if (!this.data["viewInputType"]) {
				this.data["viewInputType"] = "array";
				this.data.hotels = this.data.hotelsArray;
			}
		},

		setTemplate : function (evt, viewTemplate) {
			this.data['view:TemplateView'] = viewTemplate;
			this.$refresh();
		},
		onRadioChange : function () {
			if (this.data["viewInputType"] == "array") {
				this.data.hotels = this.data.hotelsArray;
			} else if (this.data["viewInputType"] == "map") {
				this.data.hotels = this.data.hotelsMap;
			}
			this.$refresh();

		}
	}
});