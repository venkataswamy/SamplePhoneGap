/*
 * Copyright Amadeus
 */
/**
 * @class samples.templates.views.ViewData
 */
Aria.classDefinition({
	$classpath : 'samples.templates.views.ViewData',
	$constructor : function () {},
	$prototype : {

		data : {
			hotelsArray : [{
						code : "BWPAR599",
						name : "Royal Saint Michel",
						company : "Best Western",
						city : "Paris",
						category : "L",
						minPrice : "199",
						maxPrice : "320",
						facilities : ["RES", "PAR", "PET"],
						currency : "EUR",
						description : "Some description..."
					}, {
						code : "EUPAR406",
						name : "Exclusive Albe Saint Michel",
						company : "Exclusive Hotels",
						city : "Paris",
						category : "S",
						minPrice : "152",
						maxPrice : "260",
						currency : "EUR",
						description : "",
						facilities : []
					}, {
						code : "EPPARREL",
						name : "Relais Hotel Vieux Paris",
						company : "Epoque Hotels",
						city : "Paris",
						category : "F",
						minPrice : "223",
						maxPrice : "350",
						currency : "EUR",
						description : "",
						facilities : ["RES", "PAR"]
					}, {
						code : "XXXX",
						name : "Another Hotel in Paris",
						company : "Epoque Hotels",
						city : "Paris",
						category : "F",
						minPrice : "201",
						maxPrice : "582",
						currency : "EUR",
						description : ""
					}, {
						code : "AAAA",
						name : "Exclusive AAAA Saint Michel",
						company : "Exclusive Hotels",
						city : "Paris",
						category : "S",
						minPrice : "152",
						maxPrice : "260",
						currency : "EUR",
						description : "",
						facilities : []
					}, {
						code : "BBBB",
						name : "Relais BBBB Vieux Paris",
						company : "Epoque Hotels",
						city : "Paris",
						category : "F",
						minPrice : "223",
						maxPrice : "350",
						currency : "EUR",
						description : "",
						facilities : ["RES", "PAR"]
					}, {
						code : "CCCC",
						name : "CCCC Hotel in Paris",
						company : "Epoque Hotels",
						city : "Paris",
						category : "F",
						minPrice : "201",
						maxPrice : "582",
						currency : "EUR",
						description : ""
					}, {
						code : "DDDD",
						name : "Exclusive DDDD Saint Michel",
						company : "Exclusive Hotels",
						city : "Paris",
						category : "S",
						minPrice : "152",
						maxPrice : "260",
						currency : "EUR",
						description : "",
						facilities : []
					}, {
						code : "EEEE",
						name : "Relais EEEE Paris",
						company : "Epoque Hotels",
						city : "Paris",
						category : "F",
						minPrice : "223",
						maxPrice : "350",
						currency : "EUR",
						description : "",
						facilities : ["RES", "PAR"]
					}],
			hotelsMap : {
				"first" : {
					code : "BWPAR599",
					name : "Royal Saint Michel",
					company : "Best Western",
					city : "Paris",
					category : "L",
					minPrice : "199",
					maxPrice : "320",
					facilities : ["RES", "PAR", "PET"],
					currency : "EUR",
					description : "Some description..."
				},
				"second" : {
					code : "EUPAR406",
					name : "Exclusive Albe Saint Michel",
					company : "Exclusive Hotels",
					city : "Paris",
					category : "S",
					minPrice : "152",
					maxPrice : "260",
					currency : "EUR",
					description : "",
					facilities : []
				},
				"third" : {
					code : "EPPARREL",
					name : "Relais Hotel Vieux Paris",
					company : "Epoque Hotels",
					city : "Paris",
					category : "F",
					minPrice : "223",
					maxPrice : "350",
					currency : "EUR",
					description : "",
					facilities : ["RES", "PAR"]
				},
				"fourth" : {
					code : "XXXX",
					name : "Another Hotel in Paris",
					company : "Epoque Hotels",
					city : "Paris",
					category : "F",
					minPrice : "201",
					maxPrice : "582",
					currency : "EUR",
					description : ""
				},
				"fifth" : {
					code : "AAAA",
					name : "Exclusive AAAA Saint Michel",
					company : "Exclusive Hotels",
					city : "Paris",
					category : "S",
					minPrice : "152",
					maxPrice : "260",
					currency : "EUR",
					description : "",
					facilities : []
				},
				"sixth" : {
					code : "BBBB",
					name : "Relais BBBB Vieux Paris",
					company : "Epoque Hotels",
					city : "Paris",
					category : "F",
					minPrice : "223",
					maxPrice : "350",
					currency : "EUR",
					description : "",
					facilities : ["RES", "PAR"]
				},
				"seventh" : {
					code : "CCCC",
					name : "CCCC Hotel in Paris",
					company : "Epoque Hotels",
					city : "Paris",
					category : "F",
					minPrice : "201",
					maxPrice : "582",
					currency : "EUR",
					description : ""
				},
				"eighth" : {
					code : "DDDD",
					name : "Exclusive DDDD Saint Michel",
					company : "Exclusive Hotels",
					city : "Paris",
					category : "S",
					minPrice : "152",
					maxPrice : "260",
					currency : "EUR",
					description : "",
					facilities : []
				},
				"ninth" : {
					code : "EEEE",
					name : "Relais EEEE Paris",
					company : "Epoque Hotels",
					city : "Paris",
					category : "F",
					minPrice : "223",
					maxPrice : "350",
					currency : "EUR",
					description : "",
					facilities : ["RES", "PAR"]
				}
			},
			dictionary : {
				facilities : {
					'RES' : 'Restaurant',
					'PAR' : 'Parking',
					'SWI' : 'Swimming pool',
					'PET' : 'Pets accepted'
				},
				categories : {
					'T' : 'Tourist',
					'S' : 'Standard',
					'F' : 'First Class',
					'L' : 'Luxury'
				}
			}
		}

	}
});