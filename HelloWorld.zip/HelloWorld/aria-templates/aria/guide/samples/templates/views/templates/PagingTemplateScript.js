/*
 * Copyright Amadeus
 */
/**
 * TODOC
 * @class samples.templates.views.templates.PagingTemplateScript
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.templates.views.templates.PagingTemplateScript',
	$prototype : {

		initView : function () {
			var hdetails = this.hdetails;
			if (hdetails.pageSize < 0) {
				hdetails.setPageSize(3);
			}
		},

		showPage : function (ec, pageIdx) {
			var hdetails = this.hdetails;
			hdetails.currentPageIndex = pageIdx;
			this.$refresh({
				outputSection : 'pageSelectorSection',
				macro : "pageSelector"
			});
			this.$refresh({
				outputSection : 'hotelListSection',
				macro : "hotelList"
			});
			return false; // to prevent the anchor to generate a page navigation
		},

		setPageSize : function (evt, pageSize) {
			this.hdetails.setPageSize(pageSize);
			this.$refresh({
				outputSection : 'hotelListSection',
				macro : "hotelList"
			});
			this.$refresh({
				outputSection : 'pageSelectorSection',
				macro : "pageSelector"
			});
			return false; // to prevent the anchor to generate a page navigation
		},
		toggleSort : function () {
			this.hdetails.toggleSortOrder('SortByName', function (o) {
				return o.value.name;
			});
			this.$refresh({
				outputSection : 'sortStateHeader',
				macro : "sortState"
			});
			this.$refresh({
				outputSection : 'hotelListSection',
				macro : "hotelList"
			});

			return false;
		},

		filter : function (evt, selectMode) {
			var hdetails = this.hdetails;
			if (selectMode == 'all') {
				hdetails.allFilteredIn();
			} else if (selectMode == 'none') {
				hdetails.allFilteredOut();
			} else if (selectMode == 'paris') {
				hdetails.filterIn(hdetails.FILTER_SET, function (o) {
					return (o.value.name.match(/paris/i) != null);
				});
			}
			this.$refresh({
				outputSection : 'hotelListSection',
				macro : "hotelList"
			});
			this.$refresh({
				outputSection : 'pageSelectorSection',
				macro : "pageSelector"
			});
			this.$refresh({
				outputSection : 'filteredInCountSection',
				macro : "filteredInCount"
			});
		}
	}
});