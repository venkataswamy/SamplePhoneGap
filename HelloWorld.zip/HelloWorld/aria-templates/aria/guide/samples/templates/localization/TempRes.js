/*
 * Copyright Amadeus
 */
// Sample resources for localization
Aria.resourcesDefinition({
	$classpath: 'samples.templates.localization.TempRes',
	$resources: {
		"common":{
			"label":{
				"ok":"OK"
			}
		},
		"hello": {
			"label":{
				"locTempRes": "Localized local template resources",
				"locModRes": "Localized module resources provided dynamically from the server",
				"welcome":"Welcome to this localized example.",
				"testlocMod": "It is also possible to specify custom local module resources"
			},
			"link":{
				"ariaTemplatesDoc":"http://topspot/index.php/Aria_Templates"
			}
		}
	}
});