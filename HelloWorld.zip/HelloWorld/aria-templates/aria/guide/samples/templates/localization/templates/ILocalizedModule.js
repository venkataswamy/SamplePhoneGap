/*
 * Copyright Amadeus
 */
Aria.interfaceDefinition({
	$classpath : "samples.templates.localization.templates.ILocalizedModule",
	$extends : "aria.templates.IModuleCtrl",
	$interface : {
		"newLocaleLoaded" : "Function"
	}
});