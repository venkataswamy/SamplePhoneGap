/*
 * Copyright Amadeus
 */
// Sample resources for localization
Aria.resourcesDefinition({
	$classpath: 'samples.templates.localization.TempRes',
	$resources: {
		"common":{
			"label":{
				"ok":"OK"
			}
		},
		"hello": {
			"label":{
				"locTempRes": "Ressources localisées de template statiques",
				"locModRes": "Ressources localisées de module fournies dynamiquement par le serveur.",
				"welcome":"Bienvenue dans cet exemple localisé.",
				"testlocMod": "Il est aussi possible de définir des ressources personnalisées de module statiques (appuyez sur n'importe lequel de ces boutons pour voir un exemple)"
		},
			"link":{
				"ariaTemplatesDoc":"http://topspot/index.php/Aria_Templates"
			}
		}
	}
});