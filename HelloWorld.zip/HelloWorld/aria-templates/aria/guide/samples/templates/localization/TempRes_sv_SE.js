/*
 * Copyright Amadeus
 */
// Sample resources for localization
Aria.resourcesDefinition({
	$classpath: 'samples.templates.localization.TempRes',
	$resources: {
		"common":{
			"label":{
				"ok":"OK"
			}
		},
		"hello": {
			"label":{
				"locTempRes": "Lokaliserade lokala template-resurser",
				"locModRes": "Lokaliserade modul-resurser tillhandahållna dynamiskt från servern",
				"welcome":"Välkommen till detta lokaliserade exempel.",
				"testlocMod": "Det är också möjligt att specificera anpassade lokala modul-resurser (klicka på någon av knapparna för att se ett exempel)"
			},
			"link":{
				"ariaTemplatesDoc":"http://topspot/index.php/Aria_Templates"
			}
		}
	}
});