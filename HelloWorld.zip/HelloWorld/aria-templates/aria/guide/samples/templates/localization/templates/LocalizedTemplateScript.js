/*
 * Copyright Amadeus
 */
/**
 * Sample template script for localization
 * @class samples.templates.localization.templates.LocalizedTemplateScript
 */
Aria.tplScriptDefinition({
	$classpath:  'samples.templates.localization.templates.LocalizedTemplateScript',
	$prototype:{
			clickOK: function(){
				alert(this.res.hello.label.clickOK);
			},
			selectBoxChanged: function(){
				aria.core.environment.Environment.setLanguage(this.data.selectedLocale, {
					fn : this.moduleCtrl.newLocaleLoaded,
					scope : this.moduleCtrl
				});
			},
			buttonClicked: function(evt,arg){
				alert(arg);
			}
	}
});