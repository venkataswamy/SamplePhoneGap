/*
 * Copyright Amadeus
 */
// Sample resources for localization
Aria.resourcesDefinition({
	$classpath: 'samples.templates.localization.TempRes',
	$resources: {
		"common":{
			"label":{
				"ok":"OK"
			}
		},
		"hello": {
			"label":{
				"locTempRes": "Risorse localizzate del template locale",
				"locModRes": "Risorse localizzate del modulo fornite dinamicamente dal server",
				"welcome":"Benvenuto a questo esempio localizzato.",
				"testlocMod": "E' altresì possibile specificare risorse del modulo locale personalizzate (clicca su qualsiasi pulsante per vedere un esempio)"
			},
			"link":{
				"ariaTemplatesDoc":"http://topspot/index.php/Aria_Templates"
			}
		}
	}
});