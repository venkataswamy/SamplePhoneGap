/*
 * Copyright Amadeus
 */
Aria.classDefinition({
	$classpath : "samples.templates.localization.templates.LocalizedModule",
	$implements : ["samples.templates.localization.templates.ILocalizedModule"],
	$extends : "aria.templates.ModuleCtrl",
	$resources : {
		testRes : 'samples.resources.TestRes',
		res : 'samples.resources.Res'
	},
	$dependencies : ["samples.widgets.form.ListData"],
	$constructor : function () {
		this.$ModuleCtrl.constructor.call(this);
	},
	$prototype : {
		$publicInterfaceName : "samples.templates.localization.templates.ILocalizedModule",

		init : function (evt, cb) {
			var dataInstance = Aria.getClassInstance("samples.widgets.form.ListData");
			
			this.setData(dataInstance.data);
			
			this.$callback(cb);
		},
		
		newLocaleLoaded : function () {
			for (var i = 0; i < Aria.rootTemplates.length; i++) {
				Aria.rootTemplates[i].$refresh();
			}
		}
	}
});