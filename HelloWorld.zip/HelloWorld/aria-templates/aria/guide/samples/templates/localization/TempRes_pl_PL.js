/*
 * Copyright Amadeus
 */
// Sample resources for localization
Aria.resourcesDefinition({
	$classpath: 'samples.templates.localization.TempRes',
	$resources: {
		"common":{
			"label":{
				"ok":"OK"
			}
		},
		"hello": {
			"label":{
				"locTempRes": "Zlokalizowane statyczne zasoby szablonu",
				"locModRes": "Zlokalizowane zasoby modulu ladowane dynamicznie z serwera",				
				"welcome":"Witamy w zlokalizowanym przykladzie",
				"testlocMod": "Mozliwym jest takze zdefiniowanie wlasnych statycznych zasobow modulu (kliknij ktorykolwiek z przyciskow, aby zobaczyc przyklad)"
			},
			"link":{
				"ariaTemplatesDoc":"http://topspot/index.php/Aria_Templates"
			}
		}
	}
});