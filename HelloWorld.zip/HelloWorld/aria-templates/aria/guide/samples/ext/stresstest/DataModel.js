/*
 * Copyright Amadeus
 */
Aria.classDefinition({
	$classpath : "samples.ext.stresstest.DataModel",
	$prototype : {
		data : {
			repeat : 2,
			widget : "false",
			incremental : "false"
		}
	}
});