/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : "samples.ext.stresstest.MainTemplateScript",
	$dependencies : ["aria.ext.StressCss"],
	$prototype : {
		startTest : function () {
			aria.ext.StressCss.stressTest(this.$json.removeMetadata(this.data));
		}
	}
});