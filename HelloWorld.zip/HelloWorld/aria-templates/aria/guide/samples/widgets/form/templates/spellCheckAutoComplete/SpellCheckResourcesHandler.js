/*
 * Copyright Amadeus
 */
/**
 * The purpose of this class is to show how to use the spelling mistake underline state in the auto-complete. It does a
 * very basic spell check (with a list of common spelling mistakes).
 */
Aria.classDefinition({
	$classpath : 'samples.widgets.form.templates.spellCheckAutoComplete.SpellCheckResourcesHandler',
	$extends : 'aria.resources.handlers.AIRResourcesHandler',
	$constructor : function () {
		this.$AIRResourcesHandler.constructor.call(this);
	},
	$statics : {
		COMMON_SPELLINGMISTAKES : {
			"parr" : "PAR",
			"parri" : "Paris",
			"parris" : "Paris",
			"pparis" : "Paris",
			"paaris" : "Paris",
			"lonn" : "LON",
			"lonndon" : "London"
		}
	},
	$prototype : {

		/**
		 * Call the callback with an array of suggestions in its arguments. Suggestions that are exact match are marked
		 * with parameter exactMatch set to true.
		 * @param {String} textEntry
		 * @param {Function} callback
		 */
		getSuggestions : function (textEntry, callback) {
			var spellingMistake = this.COMMON_SPELLINGMISTAKES[textEntry.toLowerCase()];
			this.$AIRResourcesHandler.getSuggestions.call(this, spellingMistake != null ? spellingMistake : textEntry, {
				scope : this,
				fn : this._addSpellingMistakeParamCallback,
				args : {
					callback : callback,
					spellingMistake : spellingMistake != null
				}
			});
		},

		/**
		 * Post-process answers from the AIR resources handler to set the spelling mistake property.
		 * @param {Object|Array} res
		 * @param {Object} args
		 */
		_addSpellingMistakeParamCallback : function (res, args) {
			if (args.spellingMistake && res) {
				var suggestions;
				if ("suggestions" in res) {
					suggestions = suggestions;
				} else {
					suggestions = res;
					res = {
						suggestions : suggestions
					};
				}
				// this triggers the error state of the autocomplete:
				res.error = true;
				
				// normally, when reaching this point, suggestions should never be null (unless resources are not
				// available...)
				if (suggestions && suggestions.length >= 1) {
					// write on the first suggestion that there was a spelling mistake:
					suggestions[0]['view:spellingSuggestion'] = true;
					for (var i = 0, l = suggestions.length; i < l; i++) {
						// set the exactMatch property to false (as there was a spelling mistake)
						suggestions[i].exactMatch = false;
					}
				}
			}
			this.$callback(args.callback, res);
		},

		getDefaultTemplate : function () {
			return "samples.widgets.form.templates.spellCheckAutoComplete.SpellCheckAIRList";
		}

	}
});
