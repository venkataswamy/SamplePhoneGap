/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
 	$classpath : 'samples.widgets.form.templates.TemplateSelectScript',
 	$prototype : {
	 	toggleSkin : function () {
			var skin = (this.skin.skinType == "std") ? "simple" : "std";
			this.$json.setValue(this.skin, "skinType", skin);
			this.$refresh();	
	 	}
 	}
});