/*
 * Copyright Amadeus
 */
/**
 * @class samples.widgets.form.ListData
 */
Aria.classDefinition({
	$classpath : 'samples.widgets.form.ListData',
	$constructor : function () {},
	$prototype : {

		data : {
			selectDisabled1 : false,
			multipleSelect1 : false,
			selectDisabled2 : false,
			multipleSelect23 : false,
			selectDisabled3 : false,
			selectedLocale: aria.core.environment.Environment.getLanguage(),

			listItems1 : [{
						value : 0,
						label : 'Item1 with value 0'
					}, {
						value : 1,
						label : 'Item2 with value 1'
					}, {
						value : 2,
						label : 'Item3 with value 2'
					}],

			listItems2 : [{
						value : 2,
						label : 'Item1 with value 2'
					}, {
						value : 1,
						label : 'Item2 with value 1'
					}, {
						value : 0,
						label : 'Item3 with value 0'
					}],

			selectedValues : [0],
			countries : [{
				value : "FR",
				label : "France"
			}, {
				value : "CH",
				label : "Switzerland"
			},{
				value : "UK",
				label : "United Kingdom"
			},{
				value : "US",
				label : "United States"
			},{
				value : "ES",
				label : "Spain"
			},{
				value : "PL",
				label : "Poland"
			},{
				value : "SE",
				label : "Sweden"
			},{
				value : "USA",
				label : "United States of America"
			}],
			locales : [{
				value : "fr_FR",
				label : "French (fr_FR)"
			}, {
				value : "en_US",
				label : "English (en_US)"
			},{
				value : "sv_SE",
				label : "Swedish (sv_SE)"
			},{
				value : "pl_PL",
				label : "Polish (pl_PL)"
			},{
				value : "it_IT",
				label : "Italian (it_IT)"
			}]
		}
	}
});