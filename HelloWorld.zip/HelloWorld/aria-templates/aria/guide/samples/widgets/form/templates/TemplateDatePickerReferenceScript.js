/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.widgets.form.templates.TemplateDatePickerReferenceScript',
	$prototype : {
		initData : function () {
			this.data.itinerarySample = {
				itineraryArray : [{
							from : "NCE",
							to : "PAR"
						}, {
							from : "PAR",
							to : "SFO"
						}, {
							from : "SFO",
							to : "PAR"
						}, {
							from : "PAR",
							to : "NCE"
						}]
			}

			this.sampleData = this.data.itinerarySample;
		},

		$dataReady : function () {
			if (this.data.itinerarySample) {
				this.sampleData = this.data.itinerarySample
			} else {
				this.initData();
			}
		}
	}
})