/*
 * Copyright Amadeus
 */
/**
 * @class samples.widgets.form.ListData
 */
Aria.classDefinition({
	$classpath : 'samples.widgets.form.GaugeData',
	$constructor : function () {},
	$prototype : {
		data : {
			currentValue : 20,
			maxValue : 100,
			label : "",
			isCheckMe : true
		}
	}
});