/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : "samples.widgets.form.templates.TemplateTextFieldScript",
	$prototype : {	   
			showAlert : function() {},
			testLabel : function(){
				this.$json.setValue(this.labelData,"label",this.$json.getValue(this.labelData,"label") + "1");	
			}
	}
});