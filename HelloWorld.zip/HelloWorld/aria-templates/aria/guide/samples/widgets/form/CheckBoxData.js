/*
 * Copyright Amadeus
 */
/**
 * @class samples.widgets.form.CheckBoxData
 */
Aria.classDefinition({
	$classpath : 'samples.widgets.form.CheckBoxData',
	$constructor:function() {},
	$prototype : {
		
		data : {
			value: "text value",
			isCheckMe: true,
			enableAll: false,
			val1: "true",
			group1: "c"}
		
	}
});