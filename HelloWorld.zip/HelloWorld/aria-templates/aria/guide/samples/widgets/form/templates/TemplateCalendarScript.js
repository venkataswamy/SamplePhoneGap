/*
 * Copyright Amadeus
 */
/**
 * TODOC
 * @class samples.widgets.form.templates.TemplateCalendarScript
 */
Aria.tplScriptDefinition({
	$classpath:  'samples.widgets.form.templates.TemplateCalendarScript',
	$prototype:{
		dateSelectedInFirstCalendar: function(){
			alert('You selected the following date in the first calendar: '+this.data.value);
		},
		dateSelectedInSecondCalendar: function(){
			alert('You selected the following date in the second calendar: '+this.data.value);
		}
	}
});