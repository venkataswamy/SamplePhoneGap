/*
 * Copyright Amadeus
 */
Aria.resourcesDefinition({
	$classpath: 'samples.widgets.form.ErrorListRes',
	$resources: {		
		errors : {				
			/* 10xx Range is reserved for Custom errors */
			"1000_ERROR_FIRSTNAME_INVALID" : "FIRSTNAME INVALID MESSAGE HERE",
			"1001_ERROR_FIRSTNAME_BLANK" : "FIRSTNAME BLANK MESSAGE HERE",
			"1002_ERROR_LASTNAME_INVALID" : "LASTNAME INVALID MESSAGE HERE",
			"1003_ERROR_LASTNAME_BLANK" : "LASTNAME BLANK MESSAGE HERE",
			"1004_ERROR_PHONENUMBER_INVALID" : "PHONENUMBER INVALID MESSAGE HERE",
			"1005_ERROR_PHONENUMBER_BLANK" : "PHONENUMBER BLANK MESSAGE HERE",					
			"" : "" // empty entry to use commas at the end of each error description (!)
		}			
	}	
});
