/*
 * Copyright Amadeus
 */
/**
 * Script for the autocomplete sample
 * @class samples.widgets.form.templates.AutoCompleteSampleScript
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.widgets.form.templates.AutoCompleteSampleScript',
	$dependencies : ['aria.resources.handlers.LCResourcesHandler'],
	$constructor : function () {
		this.dateUtils = aria.utils.Date;
		this.airlinesHandler = new aria.resources.handlers.LCResourcesHandler();
		this.airlinesHandler.setSuggestions([{
					label : 'Air France',
					code : 'AF'
				}, {
					label : 'Air Canada',
					code : 'AC'
				}, {
					label : 'Finnair',
					code : 'XX'
				}, {
					label : 'Quantas',
					code : '--'
				}, {
					label : 'American Airlines',
					code : 'AA'
				}, {
					label : 'Emirates',
					code : 'EK'
				}]);
		this.airlinesHandler.codeExactMatch = true;
	},
	$prototype : {
		getAirLinesHandler : function () {
			return this.airlinesHandler;
		},

		toggleAutoSelect : function () {
			this.airlinesHandler.codeExactMatch = !this.airlinesHandler.codeExactMatch;
		}
	}
});