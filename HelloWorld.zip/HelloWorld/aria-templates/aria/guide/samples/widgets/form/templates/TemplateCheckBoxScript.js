/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath:'samples.widgets.form.templates.TemplateCheckBoxScript',
	$prototype:{
		initEventsContent: function () {
			if (this.data.eventsContent == null) {
				this.data.eventsContent = "";
			}
		},
		onchange: function(arg,arg2) {
			this.data.eventsContent += "CheckBox " + arg2.toString() + " selection changed. New value: " + this.data.isCheckMe.toString() + "<br/>";
		},							
		onRadioChange: function(arg,arg2) {			
			this.data.eventsContent += "Radio group " + arg2.radioGroup + " selection changed. New value: " + arg2.keyValue + "<br/>";
		},
		clearContent: function(){
			this.data.eventsContent = "";
		},
    toggleSkin : function(){
      var skin = (this.skin.skinType !="std") ? "std" : "simple";
      this.$json.setValue(this.skin, "skinType", skin);
      this.$refresh({
        filterSection: "form"
      });	
    }
	}
});
