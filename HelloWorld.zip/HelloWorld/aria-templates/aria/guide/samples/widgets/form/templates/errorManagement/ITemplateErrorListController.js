/*
 * Copyright Amadeus
 */
/**
 * Interface for the error list module.
 * @class samples.widgets.form.templates.errorManagement.ITemplateErrorListController
 */
Aria.interfaceDefinition({
	$classpath : 'samples.widgets.form.templates.errorManagement.ITemplateErrorListController',
	$extends : 'aria.templates.IModuleCtrl',
	$interface : {
		submit : function () {},
		removeValidator : function () {}
	}
});
