/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.widgets.action.templates.TemplateButtonScript',
	$prototype : {

		changeState : function () {
			if (this.data.disabledOKbutton) {
				aria.utils.Json.setValue(this.data, "disabledOKbutton", false);
			} else {
				aria.utils.Json.setValue(this.data, "disabledOKbutton", true);
			}
		},

		testFn : function () {
			alert("Here inside the testFn method that is called");
		},
		select : function () {

			alert("select");
		},
		normal : function () {
			alert("normal");
		},
		checkSkin : function () {
			return this.moduleCtrl.getCurrentSkin();
		}
	}
});
