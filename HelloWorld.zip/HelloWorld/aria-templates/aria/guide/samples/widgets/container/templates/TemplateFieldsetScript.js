/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.widgets.container.templates.TemplateFieldsetScript',
	$prototype : {
		fieldsetSubmit : function () {
			alert("onSubmit callback on the root fieldset.");
		},
		nestedFieldsetSubmit : function () {
			alert("onSubmit callback on the nested fieldset.");
		},
		nestedFieldsetSubmitReturnTrue : function () {
			alert("onSubmit callback returning true on the nested fieldset.");
			return true;
		},
    toggleSkin : function(){
      var skin = (this.skin.skinType == "std") ? "simple" : "std";
      this.$json.setValue(this.skin, "skinType", skin);
      this.$refresh({
        filterSection: "form"
      });	
    }		
	}
});