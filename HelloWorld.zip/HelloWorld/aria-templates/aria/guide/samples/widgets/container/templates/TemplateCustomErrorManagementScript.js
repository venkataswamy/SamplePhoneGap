/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.widgets.container.templates.TemplateCustomErrorManagementScript',
	$constructor : function() {
		this.data = {error2:[],error3:[],state2:false,state3:false,textValue:''};		
	},
	$prototype : {		
				
		onvalidate: function () {			
			if (this.data.textValue && this.data.textValue != 'abc') {
				this.data.error2[0] = "This textfield must have the value 'abc'";
				this.$json.setValue(this.data,"state2",true);										
			} else if (this.data.textValue && this.data.textValue === 'abc') {			
				this.data.error2 = [];
				this.$json.setValue(this.data,"state2",false);							
			}						
		},
		
		erroron: function () {									
			this.data.error3[0] = "A custom error message for a textfield";
			this.$json.setValue(this.data,"state3",true);				
		},
		
		erroroff: function () {			
			this.data.error3 = [];
			this.$json.setValue(this.data,"state3",false);				
			this.$refresh({filterSection: "customErrorTips3"});
		}		
	}
});


	