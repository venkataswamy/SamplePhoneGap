/*
 * Copyright Amadeus
 */
/**
 * @class samples.widgets.container.DialogData
 */
Aria.classDefinition({
	$classpath : 'samples.widgets.container.DialogData',
	$constructor:function() {},
	$prototype : {
		
		data : {
			dialogOpen: false,
			contentMacro: "defaultContent",
			visible: false
		}
		
	}
});