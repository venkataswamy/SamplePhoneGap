/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.widgets.container.templates.TemplateDirectEditScript',
	$prototype : {
		changeDirectEditMode : function (e) {
			this.directEditMode = (this.directEditMode == "display") ? "edit" : "display";
			this.switchMode();
		},
		
		switchMode : function () {
			//this.$refresh({filterSection:"directEdit"});
			//console.log("switch" + this.directEditMode)
		},
		dateSelectedInFirstCalendar: function(){
			alert('You selected the following date in the first calendar: '+this.data.value);
		},
		dateSelectedInSecondCalendar: function(){
			alert('You selected the following date in the second calendar: '+this.data.value);
		}		
	}
});