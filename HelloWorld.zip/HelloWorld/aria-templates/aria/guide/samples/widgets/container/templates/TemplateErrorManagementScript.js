/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.widgets.container.templates.TemplateErrorManagementScript',
	$constructor : function() {
		this.data = {error:[]};
	},
	$prototype : {
		onchange: function () {
			if (!this.data.error.length) {
				this.data = {error:[
					"The Number field only accepts numerical values"
				]};
			} else {
				this.data.error = [];
			}
			this.$refresh({filterSection: "errortips"});
		}
	}
});


	