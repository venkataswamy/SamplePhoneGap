/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.widgets.container.templates.TemplateTooltipScript',
	$prototype : {
		
		refreshSection : function (evt, args) {
			this.$refresh(args);
		}

	}
});