/*
 * Copyright Amadeus
 */
/**
 * Interface for the contextual module controller.
 * @class aria.tools.contextual.IContextualModule
 */
Aria.interfaceDefinition({
	$classpath : 'samples.custommode.IContextualModule',
	$extends : 'aria.templates.IModuleCtrl',
	$interface : {}
});
