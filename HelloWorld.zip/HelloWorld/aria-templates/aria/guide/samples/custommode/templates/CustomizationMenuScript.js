/*
 * Copyright Amadeus
 */
/**
 * Script associated to the contextual menu for debugging
 * @class samples.custommode.templates.CustomizationMenuScript
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.custommode.templates.CustomizationMenuScript',
	$prototype : {

		/**
		 * Call the bridge to notify that this template context has to be inspected, and start it if not opened yet
		 * @param {aria.DomEvent} event
		 */
		openDebug : function (event) {
			var driver = this.data.driver;
			driver.openTools();
		},

		/**
		 * Reload associated template context
		 * @param {aria.DomEvent} event
		 */
		reload : function (event) {
			this.data.templateCtxt.$reload();
			this.data.driver.close();
		}
	}
});