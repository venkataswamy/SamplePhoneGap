/*
 * Copyright Amadeus
 */
/**
 * @class samples.custommode.templates.CustomModeScript
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.custommode.templates.CustomModeScript',
	$prototype : {
		startCustomMode : function () {
			var title = "Demo site in customization mode";
			var url = location.protocol + "//" + location.host + location.pathname; // remove anything after ? or #
			// Note that in IE, there is a stupid check which prevents from loading a page in an iframe if it has the
			// same URL as the page containing the iframe
			// Adding a parameter allows to get around the problem:
			if (location.search) {
				url += location.search + "&date=" + (new Date().getTime());
			} else {
				url += "?date=" + (new Date().getTime());
			}
			var newWindow = window.open("");
			if (newWindow == null) {
				return;
			}
			var doc = newWindow.document;
			var html = [
					'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">',
					'<html xmlns="http://www.w3.org/1999/xhtml" lang="EN">',
					'<head>',
					'<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />',
					'<title>',
					title,
					'</title>',
					'<style type="text/css">',
					'html {overflow: auto;}',
					'html, body, div, iframe {margin: 0px; padding: 0px; height: 100%; border: none;}',
					'iframe {display: block; width: 100%; border: none; overflow-y: auto; overflow-x: hidden;}',
					'</style>',
					'<script type="text/JavaScript">',
					'var onFrameload = function() {',
					'try {',
					'var appEnv = window.frames[0].aria.core.AppEnvironment;',
					'} catch (e) { alert("Impossible to set the customization mode: "+e); return; }',
					'appEnv.setEnvironment({',
					'contextualMenu: {',
					'template: "samples.custommode.templates.CustomizationMenu",',
					'moduleCtrl: "samples.custommode.ContextualModule",',
					'enabled: true',
					'}',
					'},null, true);',
					'};',
					'</sc',
					'ript>',
					'</head>',
					'<body>',
					'<iframe src="',
					url,
					'" onload="onFrameload();" frameborder="0" marginheight="0" marginwidth="0" width="100%" height="100%" scrolling="auto"></iframe>',
					'</body>', '</html>'];
			doc.write(html.join(''));
			doc.close();
		}
	}
});