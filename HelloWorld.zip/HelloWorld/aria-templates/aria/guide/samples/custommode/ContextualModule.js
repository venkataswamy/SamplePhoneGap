/*
 * Copyright Amadeus
 */
/**
 * Module controller for contextual menu.
 * @class aria.tools.contextual.ContextualModuleCtrl
 */
Aria.classDefinition({
	$classpath : 'samples.custommode.ContextualModule',
	$extends : 'aria.templates.ModuleCtrl',
	$implements : ['samples.custommode.IContextualModule'],
	$constructor : function () {
		this.$ModuleCtrl.constructor.call(this);
	},
	$prototype : {
		$publicInterfaceName: 'samples.custommode.IContextualModule',
		
		init : function (args, cb) {
			this._data = args;
			this.$callback(cb);
		}
	}
});