/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.features.errorManagement.TemplateValidatorFiltersScript',
	$prototype : {
		onSampleTypeChange : function () {
			this.$refresh();
		}
	}
});
