/*
 * Copyright Amadeus
 */
/**
 * Interface for the error list module.
 * @class samples.features.errorManagement.ITemplateValidatorFiltersController
 */
Aria.interfaceDefinition({
	$classpath : 'samples.features.errorManagement.ITemplateValidatorFiltersController',
	$extends : 'aria.templates.IModuleCtrl',
	$interface : {
		submit : function () {}
	}
});
