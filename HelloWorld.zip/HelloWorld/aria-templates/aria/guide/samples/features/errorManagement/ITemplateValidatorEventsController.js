/*
 * Copyright Amadeus
 */
/**
 * Interface for the error list module.
 * @class samples.features.errorManagement.ITemplateValidatorEventsController
 */
Aria.interfaceDefinition({
	$classpath : 'samples.features.errorManagement.ITemplateValidatorEventsController',
	$extends : 'aria.templates.IModuleCtrl',
	$interface : {
		submit : function () {}
	}
});
