/*
 * Copyright Amadeus
 */
/**
 * @class apps.demo.main.resources.AppModuleRes Aria resource object
 */
Aria.resourcesDefinition({
	$classpath : 'samples.resources.AppModuleRes',
	$locale: '',
	$resources : {
		common:{
			label:{
				ok:"OK",
				_ok:"key_for_OK"
			}
		},
		airshopper: {
			search:{
				label:{
					Avail:"Availability",
					_Avail:"key_for_avail"
				}
			}
		}		
	}
});