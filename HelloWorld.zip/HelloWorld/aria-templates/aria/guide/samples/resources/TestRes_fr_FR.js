/*
 * Copyright Amadeus
 */
/**
 * @class apps.demo.main.resources.TestRes Aria resource object
 */
Aria.resourcesDefinition({
	$classpath : 'samples.resources.TestRes',
	$locale: 'fr_FR',
	$resources: {
		messages : {			
			"clickOK":"Vous avez cliqué sur le bouton OK.",
			"clickAvail":"Vous avez cliqué sur le bouton Disponibilité."
		}
	}
});