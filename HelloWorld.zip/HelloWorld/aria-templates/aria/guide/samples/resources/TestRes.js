/*
 * Copyright Amadeus
 */
/**
 * @class apps.demo.main.resources.TestRes Aria resource object
 */
Aria.resourcesDefinition({
	$classpath : 'samples.resources.TestRes',
	$locale: '',
	$resources: {
		messages : {
			"clickOK":"You clicked on the OK button.",
			"clickAvail":"You clicked on the Availability button."
		}
	}
});