/*
 * Copyright Amadeus
 */
/**
 * @class apps.demo.main.resources.TestRes Aria resource object
 */
Aria.resourcesDefinition({
	$classpath : 'samples.resources.TestRes',
	$locale: 'it_IT',
	$resources: {
		messages : {						
			"clickOK":"Hai cliccato OK.",
			"clickAvail":"Hai cliccato sul pulsante Disponibilita."
		}
	}
});