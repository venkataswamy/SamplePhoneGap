/*
 * Copyright Amadeus
 */
/**
 * @class apps.demo.main.resources.TestRes Aria resource object
 */
Aria.resourcesDefinition({
	$classpath : 'samples.resources.TestRes',
	$locale: 'en_US',
	$resources: {
		messages : {						
			"clickOK":"Du har klickat på OK-knappen.",
			"clickAvail":"Du har klickat på tillgänglighetsknappen."
		}
	}
});