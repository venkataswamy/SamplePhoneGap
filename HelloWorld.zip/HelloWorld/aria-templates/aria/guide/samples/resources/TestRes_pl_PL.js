/*
 * Copyright Amadeus
 */
/**
 * @class apps.demo.main.resources.TestRes Aria resource object
 */
Aria.resourcesDefinition({
	$classpath : 'samples.resources.TestRes',
	$locale: 'pl_PL',
	$resources: {
		messages : {			
			"clickOK":"Kliknales przycisk OK.",
			"clickAvail":"Kliknales przycisk Dostepnosc."
		}
	}
});