/*
 * Copyright Amadeus
 */
Aria.tplScriptDefinition({
	$classpath : 'samples.airshopper.templates.TemplateAllFaresBookingFormScript',
	$prototype : {
		$dataReady : function () {
			this.data = {
				errorDeparture : [],
				errorReturn : [],
				stateDeparture : false,
				stateReturn : false,
				departvalue : null,
				returnvalue : null,
				titleMessage : [],
				init : true
			};
		},

		validateSearch : function () {
			var errors;

			if (!this.data.stateDeparture && !this.data.stateReturn) {

				// custom validation: checks departure date is empty
				if (this.data.departvalue === null) {
					this.$json.setValue(this.data, "errorDeparture", ["Invalid departure date. The departure date is empty please enter a date of departure."]);
					this.data.titleMessage.push(this.data.errorDeparture[1]);
					this.$json.setValue(this.data, "stateDeparture", true);
					errors = true;
				}

				// custom validation: checks return date is empty
				if (this.data.returnvalue === null) {
					this.$json.setValue(this.data, "errorReturn", ["Invalid return date.  The return date is empty please enter a date of return."]);
					this.data.titleMessage.push(this.data.errorReturn[0]);
					this.$json.setValue(this.data, "stateReturn", true);
					errors = true;
				}

				// custom validation: checks invalid return date
				if (this.data.departvalue > this.data.returnvalue && this.data.returnvalue != null) {
					this.$json.setValue(this.data, "errorReturn", ["Invalid return date. The return date must be earlier than the departure date."]);
					this.data.titleMessage.push(this.data.errorReturn[0]);
					this.$json.setValue(this.data, "stateReturn", true);
					errors = true;
				}

				if (!errors) {
					this.$json.setValue(this.data, "errorDeparture", []);
					this.$json.setValue(this.data, "stateDeparture", false);
					this.$json.setValue(this.data, "errorReturn", []);
					this.$json.setValue(this.data, "stateReturn", false);
				}

				// custom validation: different error title messages
				if (this.data.titleMessage.length > 1) {
					this.$json.setValue(this, "titleMessage", "There are several errors in your search. Click the fields with red borders for more details. Please correct these errors and perform the search again.");
					this.data.titleMessage = [];
				} else {
					this.$json.setValue(this, "titleMessage", this.data.titleMessage[0]);
					this.data.titleMessage = [];
				}

				this.$refresh({
					filterSection : "customErrorTips"
				});

			}
		}

	}
});
