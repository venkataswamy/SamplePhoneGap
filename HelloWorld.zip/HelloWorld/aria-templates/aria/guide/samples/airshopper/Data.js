/*
 * Copyright Amadeus
 */
/**
 * @class tutorials.view.step3.ViewData
 */
Aria.classDefinition({
	$classpath : 'samples.airshopper.Data',
	$constructor : function () {},
	$prototype : {

		data : {
			errorDeparture : [],
			errorReturn : [],
			stateDeparture : false,
			stateReturn : false,
			departvalue : null,
			returnvalue : null,
			titleMessage : []
		}

	}
});