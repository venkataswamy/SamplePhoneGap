/*
 * Copyright Amadeus
 */
Aria.resourcesDefinition({
	$classpath: 'samples.airshopper.Res',
	$resources: {		
		errors : {				
			/* 10xx Range is reserved for Custom errors */
			"1000_ERROR_RETURN_INVALID" : "Invalid return date. The return date must be earlier than the departure date.",
			"1001_ERROR_DEPART_BLANK" : "Invalid departure date. The departure date is empty please enter a date of departure.",
			"1002_ERROR_RETURN_BLANK" : "Invalid return date.  The return date is empty please enter a date of return.",
			"1003_ERROR_TITLE_MULTIPLE" : "There are several errors in your search. Click the fields with red borders for more details. Please correct these errors and perform the search again.",
			"1004_ERROR" : "TESTING ERROR AND ERROR MESSAGES PROPERTIES",
			"1005_MCERROR" : "TESTING UIERROR AND UIERRORMESSAGES PROPERTIES",
			"" : "" // empty entry to use commas at the end of each error description (!)
		}			
	}	
});
