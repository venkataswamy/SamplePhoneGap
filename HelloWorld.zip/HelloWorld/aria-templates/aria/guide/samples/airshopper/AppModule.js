/*
 * Copyright Amadeus
 */
/**
 * TODOC
 * @class AppModule
 */
 Aria.classDefinition({
 	$classpath:'samples.airshopper.AppModule',
 	$extends:'aria.templates.ModuleCtrl',
 	$dependencies:[],
 	$events:{},
 	$constructor: function () {
 		this.$ModuleCtrl.constructor.call(this); 	 		
 	},
 	$prototype:{
 		init : function (arg,cb) { 			
 			this.$ModuleCtrl.init.call(this,arg,cb); 				 			
 		}
 	} 	
 });