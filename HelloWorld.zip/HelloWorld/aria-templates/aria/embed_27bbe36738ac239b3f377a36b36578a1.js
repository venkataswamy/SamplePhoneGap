/*
 * Copyright Amadeus
 */
//***MULTI-PART
//HEKmulelOe
//LOGICAL-PATH:aria/embed/CfgBeans.js
//HEKmulelOe
Aria.beanDefinitions({$package:"aria.embed.CfgBeans",$description:"Definition of the JSON beans used by the aria embed lib",$namespaces:{json:"aria.core.JsonTypes",html:"aria.templates.CfgBeans"},$beans:{ElementCfg:{$type:"json:Object",$description:"Embed element widget",$properties:{controller:{$type:"json:ObjectRef",$description:"Controller used to manage the embedded dom"},type:{$type:"json:String",$description:"DOM type for this section.",$default:"div"},attributes:{$type:"html:HtmlAttribute",
$description:"Parameters to apply to the DOM element of the section."},args:{$type:"json:MultiTypes",$description:"Argument given to the onEmbededElementCreate and onEmbededElementDispose functions of the provided embed controller"}}},PlaceholderCfg:{$type:"json:Object",$description:"Placeholder",$properties:{name:{$type:"json:String",$description:"Placeholder name",$mandatory:true},type:{$type:"json:String",$description:"DOM type for this section.",$default:"div"},attributes:{$type:"html:HtmlAttribute",
$description:"Parameters to apply to the DOM element of the section."}}},MapCfg:{$type:"json:Object",$description:"Map widget configuration",$properties:{id:{$type:"json:String",$description:"Id of the map",$mandatory:true},provider:{$type:"json:String",$description:"Map provider",$mandatory:true},initArgs:{$type:"json:MultiTypes",$description:"Map initialization arguments"},loadingIndicator:{$type:"json:Boolean",$description:"Add a loading overlay over the map while loading",$default:false},type:{$type:"json:String",
$description:"DOM type for this section.",$default:"div"},attributes:{$type:"html:HtmlAttribute",$description:"Parameters to apply to the DOM element of the section."}}}}});
//HEKmulelOe
//LOGICAL-PATH:aria/embed/Element.js
//HEKmulelOe
Aria.classDefinition({$classpath:"aria.embed.Element",$extends:"aria.widgetLibs.BaseWidget",$dependencies:["aria.embed.CfgBeans","aria.utils.Html","aria.core.JsonValidator","aria.core.Log","aria.utils.Dom"],$statics:{INVALID_CONFIGURATION:"%1Configuration for widget is not valid."},$constructor:function(d){this.$BaseWidget.constructor.apply(this,arguments);try{this._cfgOk=aria.core.JsonValidator.normalize({json:d,beanName:this._cfgBeanName},true)}catch(a){var b=aria.core.Log;if(b){for(var c,e=0,f=
a.errors.length;e<f;e++){c=a.errors[e];c.message=b.prepareLoggedMessage(c.msgId,c.msgArgs)}this.$logError(this.INVALID_CONFIGURATION,null,a)}}},$destructor:function(){if(this._domId)this._cfg.controller.onEmbededElementDispose(aria.utils.Dom.getElementById(this._domId),this._cfg.args);this.$BaseWidget.$destructor.apply(this,arguments)},$prototype:{_cfgBeanName:"aria.embed.CfgBeans.ElementCfg",writeMarkup:function(d){if(this._cfgOk){this._domId=this._createDynamicId();var a=this._cfg.type,b=["<",a,
' id="',this._domId,'"'];this._cfg.attributes&&b.push(" "+aria.utils.Html.buildAttributeList(this._cfg.attributes));b.push("></"+a+">");d.write(b.join(""))}},initWidget:function(){if(this._cfgOk)this._cfg.controller.onEmbededElementCreate(aria.utils.Dom.getElementById(this._domId),this._cfg.args)}}});
//HEKmulelOe
//LOGICAL-PATH:aria/embed/EmbedLib.js
//HEKmulelOe
Aria.classDefinition({$classpath:"aria.embed.EmbedLib",$extends:"aria.widgetLibs.WidgetLib",$singleton:true,$prototype:{widgets:{Element:"aria.embed.Element",Map:"aria.embed.Map",Placeholder:"aria.embed.Placeholder"}}});
//HEKmulelOe
//LOGICAL-PATH:aria/embed/IContentProvider.js
//HEKmulelOe
Aria.interfaceDefinition({$classpath:"aria.embed.IContentProvider",$interface:{getContent:function(){}}});
//HEKmulelOe
//LOGICAL-PATH:aria/embed/IEmbedController.js
//HEKmulelOe
Aria.interfaceDefinition({$classpath:"aria.embed.IEmbedController",$extends:"aria.templates.IModuleCtrl",$interface:{onEmbededElementCreate:function(){},onEmbededElementDispose:function(){}}});
//HEKmulelOe
//LOGICAL-PATH:aria/embed/Placeholder.js
//HEKmulelOe
Aria.classDefinition({$classpath:"aria.embed.Placeholder",$extends:"aria.widgetLibs.BaseWidget",$dependencies:["aria.embed.CfgBeans","aria.utils.Html","aria.core.JsonValidator","aria.core.Log","aria.utils.Dom","aria.html.Template","aria.html.HtmlLibrary","aria.embed.PlaceholderManager"],$statics:{INVALID_CONFIGURATION:"%1Configuration for widget is not valid."},$constructor:function(c,f){this.$BaseWidget.constructor.apply(this,arguments);try{this._cfgOk=aria.core.JsonValidator.normalize({json:c,beanName:this._cfgBeanName},
true)}catch(g){var b=aria.core.Log;if(b){for(var a,d=0,h=g.errors.length;d<h;d++){a=g.errors[d];a.message=b.prepareLoggedMessage(a.msgId,a.msgArgs)}this.$logError(this.INVALID_CONFIGURATION,null,g)}}b="";for(a=f;a;){if(a.placeholderPath){b=a.placeholderPath+".";break}a=a.parent}this._placeholderPath=b+this._cfg.name},$destructor:function(){this.$BaseWidget.$destructor.apply(this,arguments)},$prototype:{_cfgBeanName:"aria.embed.CfgBeans.PlaceholderCfg",writeMarkup:function(c){var f=aria.embed.PlaceholderManager;
if(this._cfgOk){var g=aria.utils.Type,b=this._cfg.type,a=["<",b];this._cfg.attributes&&a.push(" "+aria.utils.Html.buildAttributeList(this._cfg.attributes));a.push(">");c.write(a.join(""));a=this._placeholderPath;f=f.getContent(a);for(var d=0,h=f.length;d<h;d++){var e=f[d];if(g.isString(e))c.write(e);else{e=new aria.html.Template(e,this._context,this._lineNumber);e.subTplCtxt.placeholderPath=a;c.registerBehavior(e);e.writeMarkup(c)}}c.write("</"+b+">")}}}});
//HEKmulelOe
//LOGICAL-PATH:aria/embed/PlaceholderManager.js
//HEKmulelOe
Aria.classDefinition({$classpath:"aria.embed.PlaceholderManager",$dependencies:["aria.utils.Type"],$singleton:true,$constructor:function(){},$statics:{_providers:[],PLACEHOLDER_PATH_NOT_FOUND:"No content has been found for the placeholder path '%1'"},$prototype:{getContent:function(c){for(var a=[],b=aria.utils.Type,d=this._providers,f=0,h=d.length;f<h;f++){var e=d[f].getContent(c);if(e)if(b.isArray(e))for(var g=0,i=e.length;g<i;g++)a.push(e[g]);else a.push(e)}a.length==0&&this.$logWarn(this.PLACEHOLDER_PATH_NOT_FOUND,
[c]);return a},register:function(c){for(var a=this._providers,b=0,d=a.length;b<d;b++)if(a[b]===c)return;a.push(c)},unregister:function(c){for(var a=this._providers,b=0,d=a.length;b<d;b++)a[b]===c&&a.splice(b,b)}}});