/*
 * Copyright Amadeus
 */
Aria.interfaceDefinition({$classpath:"aria.storage.IStorage",$events:{change:{description:"Raised when the storage area changes because an item is set or removed, or the storage is cleared.",properties:{key:"Name of the key that changed",oldValue:"Old value of the key in question, null if the key is newly added",newValue:"New value being set",url:"Address of the document whose storage object was affected"}}},$interface:{getItem:function(){},setItem:function(){},removeItem:function(){},clear:function(){}}});