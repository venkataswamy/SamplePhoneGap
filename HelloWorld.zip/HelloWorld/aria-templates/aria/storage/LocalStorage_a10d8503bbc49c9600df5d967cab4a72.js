/*
 * Copyright Amadeus
 */
(function(){Aria.classDefinition({$classpath:"aria.storage.LocalStorage",$extends:"aria.storage.HTML5Storage",$dependencies:["aria.core.Browser","aria.storage.UserData"],$constructor:function(a){var b=aria.core.Browser.isIE7;this.$HTML5Storage.constructor.call(this,a,"localStorage",!b);if(!this.storage&&b){a=new aria.storage.UserData(a);this._get=a._get;this._set=a._set;this._remove=a._remove;this._clear=a._clear;this.storage=aria.storage.UserData._STORAGE;this.__keys=aria.storage.UserData._ALL_KEYS;
this._fallback=a}},$destructor:function(){if(this._fallback){this._fallback.$dispose();this._fallback=null}this.$HTML5Storage.$destructor.call(this)}})})();