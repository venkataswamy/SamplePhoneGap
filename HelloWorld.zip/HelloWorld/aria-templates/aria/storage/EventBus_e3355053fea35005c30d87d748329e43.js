/*
 * Copyright Amadeus
 */
Aria.classDefinition({$classpath:"aria.storage.EventBus",$singleton:true,$events:{change:"Raised when a change happens in any of the linked instances"},$prototype:{notifyChange:function(a,b,c,d,e){this.$raiseEvent({name:"change",location:a,namespace:e,key:b,newValue:c,oldValue:d,url:Aria.$window.location})}}});