/*
 * Copyright Amadeus
 */
Aria.classDefinition({$classpath:"aria.storage.SessionStorage",$extends:"aria.storage.HTML5Storage",$constructor:function(a){this.$HTML5Storage.constructor.call(this,a,"sessionStorage")}});